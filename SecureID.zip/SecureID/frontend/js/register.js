/* ============================================================
   SecureID — Registration flow logic
   ============================================================ */

(function () {
  const CODE_SECONDS = 165;   // 02:45
  const RESEND_DELAY = 25;    // 00:25
  const MAX_ATTEMPTS = 3;

  const brandSteps = document.querySelectorAll('#brandSteps .brand-step');
  const stepOrder = ['details', 'email-otp', 'mobile-otp', 'mfa-setup', 'success'];

  const pending = {
    fullName: '', email: '', mobile: '', countryCode: '+91', password: '',
    mfaMethod: 'authenticator', emailVerified: false, mobileVerified: false,
  };

  /* ---------------- Screen navigation ---------------- */
  function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
    updateBrandSteps(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function updateBrandSteps(screenId) {
    const map = {
      'screen-details': 'details',
      'screen-email-otp': 'email-otp',
      'screen-mobile-otp': 'mobile-otp',
      'screen-mfa-setup': 'mfa-setup',
      'screen-authenticator': 'mfa-setup',
      'screen-mfa-verify': 'mfa-setup',
      'screen-success': 'success',
    };
    const key = map[screenId];
    const idx = stepOrder.indexOf(key);
    brandSteps.forEach(el => {
      const stepKey = el.getAttribute('data-step');
      const stepIdx = stepOrder.indexOf(stepKey);
      el.classList.remove('done', 'current');
      if (stepIdx < idx) el.classList.add('done');
      else if (stepIdx === idx) el.classList.add('current');
    });
  }

  document.querySelectorAll('[data-back]').forEach(btn => {
    btn.addEventListener('click', () => showScreen(btn.getAttribute('data-back')));
  });

  /* ============================================================
     SCREEN 1 — Account details
     ============================================================ */
  const detailsForm = document.getElementById('detailsForm');
  const pwInput = document.getElementById('regPassword');
  const detailsAlert = document.getElementById('detailsAlert');

  pwInput.addEventListener('input', () => {
    const c = checkPassword(pwInput.value);
    Object.keys(c).forEach(rule => {
      const item = document.querySelector(`.pw-check-item[data-rule="${rule}"]`);
      item.classList.toggle('valid', c[rule]);
    });
  });

  function setFieldError(id, msg) {
    const input = document.getElementById(id);
    const err = document.getElementById('err-' + id);
    if (msg) {
      input.classList.add('error');
      err.textContent = msg;
      err.classList.add('show');
    } else {
      input.classList.remove('error');
      err.classList.remove('show');
    }
  }

  function showAlert(el, msg) {
    if (!msg) { el.classList.remove('show'); return; }
    el.innerHTML = `${Icons.alert}<span>${msg}</span>`;
    el.classList.add('show');
  }

  detailsForm.addEventListener('submit', (e) => {
    e.preventDefault();
    showAlert(detailsAlert, '');
    let valid = true;

    const fullName = document.getElementById('fullName').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const mobile = document.getElementById('regMobile').value.trim();
    const countryCode = document.getElementById('countryCode').value;
    const password = pwInput.value;
    const agreed = document.getElementById('agreeTerms').checked;

    if (!fullName) { setFieldError('fullName', 'Please enter your full name.'); valid = false; }
    else setFieldError('fullName', '');

    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    if (!emailOk) { setFieldError('regEmail', 'Enter a valid email address.'); valid = false; }
    else if (Store.findByEmail(email)) { setFieldError('regEmail', 'An account with this email already exists.'); valid = false; }
    else setFieldError('regEmail', '');

    const mobileDigits = mobile.replace(/\D/g, '');
    if (mobileDigits.length < 10) { setFieldError('regMobile', 'Enter a valid 10-digit mobile number.'); valid = false; }
    else setFieldError('regMobile', '');

    if (!passwordIsValid(password)) { valid = false; showAlert(detailsAlert, 'Your password does not meet all requirements yet.'); }

    if (!agreed) { valid = false; showAlert(detailsAlert, 'Please accept the Terms & Conditions and Privacy Policy to continue.'); }

    if (!valid) return;

    pending.fullName = fullName;
    pending.email = email;
    pending.mobile = mobileDigits;
    pending.countryCode = countryCode;
    pending.password = password;

    document.getElementById('emailTarget').textContent = email;
    setIcon(document.getElementById('emailOtpIcon'), 'mail');
    startEmailOtp();
    showScreen('screen-email-otp');
  });

  /* ---------------- Email OTP ----------------
     (uses shared `makeOtpFlow` from js/common.js) */
  const emailFlow = makeOtpFlow({
    boxesId: 'emailOtpBoxes', statusId: 'emailOtpStatus', timerId: 'emailOtpTimer',
    verifyBtnId: 'emailOtpVerifyBtn', resendBtnId: 'emailOtpResendBtn', resendTimerId: 'emailResendTimer',
    demoId: 'emailOtpDemo', verifyLabel: 'Verify Email',
    onSuccess: () => {
      pending.emailVerified = true;
      document.getElementById('mobileTarget').textContent = `${pending.countryCode} ${pending.mobile}`;
      setIcon(document.getElementById('mobileOtpIcon'), 'phone');
      mobileFlow.reset();
      showScreen('screen-mobile-otp');
    }
  });
  function startEmailOtp() { emailFlow.reset(); }

  /* ---------------- Mobile OTP ---------------- */
  const mobileFlow = makeOtpFlow({
    boxesId: 'mobileOtpBoxes', statusId: 'mobileOtpStatus', timerId: 'mobileOtpTimer',
    verifyBtnId: 'mobileOtpVerifyBtn', resendBtnId: 'mobileOtpResendBtn', resendTimerId: 'mobileResendTimer',
    demoId: 'mobileOtpDemo', verifyLabel: 'Verify Mobile',
    onSuccess: () => {
      pending.mobileVerified = true;
      showScreen('screen-mfa-setup');
    }
  });

  document.getElementById('mobileChangeBtn').addEventListener('click', () => {
    showScreen('screen-details');
    document.getElementById('regMobile').focus();
  });

  /* ============================================================
     SCREEN 4 — MFA method selection
     ============================================================ */
  document.querySelectorAll('#mfaMethodList .method-option').forEach(opt => {
    opt.addEventListener('click', () => {
      document.querySelectorAll('#mfaMethodList .method-option').forEach(o => o.classList.remove('selected'));
      opt.classList.add('selected');
      pending.mfaMethod = opt.getAttribute('data-method');
    });
  });

  document.getElementById('mfaContinueBtn').addEventListener('click', () => {
    if (pending.mfaMethod === 'authenticator') {
      const seed = pending.email + Date.now();
      const canvas = document.getElementById('qrCanvas');
      drawFakeQr(canvas, seed);
      document.getElementById('setupKeyValue').textContent = generateSetupKey();
      document.getElementById('setupKeyWrap').style.display = 'none';
      document.getElementById('toggleSetupKeyBtn').textContent = "Can't scan? Enter setup key";
      showScreen('screen-authenticator');
    } else {
      launchMfaVerify(pending.mfaMethod);
    }
  });

  document.getElementById('toggleSetupKeyBtn').addEventListener('click', () => {
    const wrap = document.getElementById('setupKeyWrap');
    const showing = wrap.style.display !== 'none';
    wrap.style.display = showing ? 'none' : 'block';
    document.getElementById('toggleSetupKeyBtn').textContent = showing ? "Can't scan? Enter setup key" : 'Hide setup key';
  });

  document.getElementById('authContinueBtn').addEventListener('click', () => {
    launchMfaVerify('authenticator');
  });

  /* ============================================================
     SCREEN 6 — MFA verification (adaptive by method)
     ============================================================ */
  let mfaFlow = null;

  function launchMfaVerify(method) {
    if (mfaFlow) mfaFlow.stop();
    const iconEl = document.getElementById('mfaVerifyIcon');
    const subEl = document.getElementById('mfaVerifySub');
    const linksEl = document.getElementById('mfaVerifyLinks');

    if (method === 'authenticator') {
      setIcon(iconEl, 'key');
      subEl.textContent = 'Enter the code from your authenticator app';
      linksEl.innerHTML = `<button class="link-action" id="mfaCantAccessBtn">Can't access your app?</button>`;
      document.getElementById('mfaCantAccessBtn').addEventListener('click', () => showScreen('screen-mfa-setup'));
    } else if (method === 'sms') {
      setIcon(iconEl, 'phone');
      subEl.innerHTML = `We sent a code to <strong>${pending.countryCode} ${pending.mobile}</strong>`;
      linksEl.innerHTML = `<button class="link-action" id="mfaResendBtn" disabled>Resend code (<span id="mfaResendTimer">00:25</span>)</button>`;
    } else {
      setIcon(iconEl, 'mail');
      subEl.innerHTML = `We sent a code to <strong>${pending.email}</strong>`;
      linksEl.innerHTML = `<button class="link-action" id="mfaResendBtn" disabled>Resend code (<span id="mfaResendTimer">00:25</span>)</button>`;
    }

    mfaFlow = makeOtpFlow({
      boxesId: 'mfaOtpBoxes', statusId: 'mfaOtpStatus', timerId: 'mfaOtpTimer',
      verifyBtnId: 'mfaVerifyBtn',
      resendBtnId: method === 'authenticator' ? null : 'mfaResendBtn',
      resendTimerId: method === 'authenticator' ? null : 'mfaResendTimer',
      demoId: 'mfaOtpDemo',
      verifyLabel: 'Verify & Finish',
      codeSeconds: method === 'authenticator' ? 30 : CODE_SECONDS,
      metaLabelId: 'mfaOtpMetaLabel',
      onSuccess: finishRegistration,
    });
    mfaFlow.reset();
    if (method === 'authenticator') {
      // authenticator codes auto-refresh; keep re-rolling on expiry instead of hard lock
    }
    showScreen('screen-mfa-verify');
  }

  function finishRegistration() {
    Store.upsert({
      fullName: pending.fullName,
      email: pending.email,
      mobile: pending.mobile,
      countryCode: pending.countryCode,
      password: pending.password,
      mfaMethod: pending.mfaMethod,
      mfaEnabled: true,
      createdAt: new Date().toISOString(),
    });
    showScreen('screen-success');
  }

})();