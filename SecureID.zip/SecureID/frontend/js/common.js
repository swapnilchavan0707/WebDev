/* ============================================================
   SecureID — shared utilities used by both login & register flows
   ============================================================ */

const Icons = {
  shield: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 4 5v6c0 5 3.4 9.4 8 11 4.6-1.6 8-6 8-11V5l-8-3Z"/></svg>`,
  mail: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/></svg>`,
  mailOpen: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m2 8 8.5 6a2 2 0 0 0 3 0L22 8"/><rect x="2" y="6" width="20" height="14" rx="2"/></svg>`,
  phone: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.7a2 2 0 0 1-.5 2.1L8 9.7a16 16 0 0 0 6.3 6.3l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.8.5 2.7.6a2 2 0 0 1 1.7 2Z"/></svg>`,
  key: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6M15.5 7.5l3 3L22 7l-3-3"/></svg>`,
  qr: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><path d="M14 14h3v3h-3zM18 18h3v3h-3zM14 21h3M21 14v3"/></svg>`,
  check: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>`,
  checkCircle: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>`,
  x: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>`,
  xCircle: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6M9 9l6 6"/></svg>`,
  eye: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>`,
  eyeOff: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9.9 4.24A9.1 9.1 0 0 1 12 4c6.5 0 10 7 10 7a17 17 0 0 1-2.3 3.3M6.3 6.3A17.3 17.3 0 0 0 2 11s3.5 7 10 7a9.2 9.2 0 0 0 4.5-1.2M1 1l22 22"/><path d="M14.1 14.1a3 3 0 1 1-4.2-4.2"/></svg>`,
  lock: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>`,
  user: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/></svg>`,
  arrowLeft: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>`,
  alert: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/></svg>`,
  info: `<svg width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>`,
  google: `<svg width="1em" height="1em" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.5 6.1 29.5 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.2-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.6 15.9 18.9 13 24 13c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.5 6.1 29.5 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.3 0 10.1-2 13.7-5.4l-6.3-5.3C29.4 35 26.8 36 24 36c-5.2 0-9.6-3.3-11.2-7.9l-6.5 5C9.6 39.6 16.3 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.3 4.2-4.2 5.6l6.3 5.3C40.9 36.5 44 30.9 44 24c0-1.2-.1-2.4-.4-3.5z"/></svg>`,
};

function icon(name, cls) {
  return `<span class="${cls || ''}">${Icons[name] || ''}</span>`;
}

function hydrateIcons(root = document) {
  root.querySelectorAll('[data-icon]').forEach(el => {
    const name = el.getAttribute('data-icon');
    if (Icons[name]) el.innerHTML = Icons[name];
  });
}

function setIcon(el, name) {
  if (el && Icons[name]) el.innerHTML = Icons[name];
}

/* Password visibility toggles: any button[data-toggle="inputId"] */
function wireVisibilityToggles(root = document) {
  root.querySelectorAll('.icon-toggle[data-toggle]').forEach(btn => {
    btn.innerHTML = Icons.eye;
    btn.addEventListener('click', () => {
      const input = document.getElementById(btn.getAttribute('data-toggle'));
      if (!input) return;
      const showing = input.type === 'text';
      input.type = showing ? 'password' : 'text';
      btn.innerHTML = showing ? Icons.eye : Icons.eyeOff;
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  hydrateIcons();
  wireVisibilityToggles();
});

/* ---------------- Toast ---------------- */
let toastTimer = null;
function showToast(msg, duration = 3200) {
  let el = document.getElementById('toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'toast';
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), duration);
}

/* ---------------- Storage (mock IAM user directory) ---------------- */
const Store = {
  KEY: 'secureid_users',
  all() {
    try { return JSON.parse(localStorage.getItem(this.KEY)) || []; }
    catch (e) { return []; }
  },
  save(users) { localStorage.setItem(this.KEY, JSON.stringify(users)); },
  findByEmail(email) {
    return this.all().find(u => u.email.toLowerCase() === String(email).toLowerCase());
  },
  upsert(user) {
    const users = this.all();
    const idx = users.findIndex(u => u.email.toLowerCase() === user.email.toLowerCase());
    if (idx >= 0) users[idx] = { ...users[idx], ...user };
    else users.push(user);
    this.save(users);
  }
};

/* ---------------- Password strength check ---------------- */
function checkPassword(pw) {
  return {
    length: pw.length >= 8,
    upper: /[A-Z]/.test(pw),
    number: /[0-9]/.test(pw),
    special: /[^A-Za-z0-9]/.test(pw),
  };
}
function passwordIsValid(pw) {
  const c = checkPassword(pw);
  return c.length && c.upper && c.number && c.special;
}

/* ---------------- OTP box group ---------------- */
function generateOtp() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function setupOtpGroup(container) {
  const boxes = Array.from(container.querySelectorAll('.otp-box'));
  boxes.forEach((box, i) => {
    box.addEventListener('input', (e) => {
      const val = e.target.value.replace(/[^0-9]/g, '').slice(-1);
      e.target.value = val;
      box.classList.toggle('filled', !!val);
      box.classList.remove('error', 'success');
      if (val && boxes[i + 1]) boxes[i + 1].focus();
      container.dispatchEvent(new CustomEvent('otp-change', { detail: getOtpValue(boxes) }));
    });
    box.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && !box.value && boxes[i - 1]) {
        boxes[i - 1].focus();
      }
    });
    box.addEventListener('paste', (e) => {
      e.preventDefault();
      const text = (e.clipboardData.getData('text') || '').replace(/[^0-9]/g, '');
      text.split('').slice(0, boxes.length).forEach((ch, idx) => {
        if (boxes[idx]) {
          boxes[idx].value = ch;
          boxes[idx].classList.add('filled');
        }
      });
      const next = boxes[Math.min(text.length, boxes.length - 1)];
      if (next) next.focus();
      container.dispatchEvent(new CustomEvent('otp-change', { detail: getOtpValue(boxes) }));
    });
  });
  return boxes;
}
function getOtpValue(boxes) { return boxes.map(b => b.value).join(''); }
function clearOtpGroup(boxes) {
  boxes.forEach(b => { b.value = ''; b.classList.remove('filled', 'error', 'success'); });
  if (boxes[0]) boxes[0].focus();
}
function markOtpGroup(boxes, state) {
  boxes.forEach(b => b.classList.add(state));
}

/* ---------------- Countdown timer ---------------- */
function formatTime(sec) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function createCountdown({ seconds, onTick, onDone }) {
  let remaining = seconds;
  let handle = null;
  function tick() {
    onTick(remaining);
    if (remaining <= 0) {
      clearInterval(handle);
      if (onDone) onDone();
      return;
    }
    remaining -= 1;
  }
  return {
    start() {
      remaining = seconds;
      tick();
      handle = setInterval(tick, 1000);
    },
    stop() { clearInterval(handle); },
    reset(newSeconds) {
      clearInterval(handle);
      remaining = newSeconds != null ? newSeconds : seconds;
      tick();
      handle = setInterval(tick, 1000);
    }
  };
}

/* ---------------- Fake QR code (visual only, deterministic) ---------------- */
function drawFakeQr(canvas, seedText) {
  const ctx = canvas.getContext('2d');
  const size = 168;
  const grid = 21;
  const cell = size / grid;
  canvas.width = size;
  canvas.height = size;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, size, size);
  ctx.fillStyle = '#16225c';

  // deterministic pseudo-random from seed
  let seed = 0;
  for (let i = 0; i < seedText.length; i++) seed = (seed * 31 + seedText.charCodeAt(i)) >>> 0;
  function rand() {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  }

  const isFinder = (r, c) => (r < 7 && c < 7) || (r < 7 && c >= grid - 7) || (r >= grid - 7 && c < 7);

  for (let r = 0; r < grid; r++) {
    for (let c = 0; c < grid; c++) {
      if (isFinder(r, c)) continue;
      if (rand() > 0.55) ctx.fillRect(c * cell, r * cell, cell - 1, cell - 1);
    }
  }

  // draw finder patterns (corners)
  function finder(ox, oy) {
    ctx.fillStyle = '#16225c';
    ctx.fillRect(ox, oy, cell * 7, cell * 7);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(ox + cell, oy + cell, cell * 5, cell * 5);
    ctx.fillStyle = '#16225c';
    ctx.fillRect(ox + cell * 2, oy + cell * 2, cell * 3, cell * 3);
  }
  finder(0, 0);
  finder((grid - 7) * cell, 0);
  finder(0, (grid - 7) * cell);
}

/* ---------------- Generic OTP flow controller ----------------
   Wires up a set of OTP boxes + timer + resend + verify button
   into a self-contained, reusable flow. Used by both the
   registration and login journeys.
------------------------------------------------------------- */
const OTP_DEFAULTS = { codeSeconds: 165, resendDelay: 25, maxAttempts: 3 };

function makeOtpFlow(cfg) {
  const boxesEl = document.getElementById(cfg.boxesId);
  const boxes = setupOtpGroup(boxesEl);
  const statusEl = document.getElementById(cfg.statusId);
  const timerEl = document.getElementById(cfg.timerId);
  const verifyBtn = document.getElementById(cfg.verifyBtnId);
  const resendBtn = cfg.resendBtnId ? document.getElementById(cfg.resendBtnId) : null;
  const resendTimerEl = cfg.resendTimerId ? document.getElementById(cfg.resendTimerId) : null;
  const demoEl = cfg.demoId ? document.getElementById(cfg.demoId) : null;
  const metaLabelEl = cfg.metaLabelId ? document.getElementById(cfg.metaLabelId) : null;
  const codeSeconds = cfg.codeSeconds || OTP_DEFAULTS.codeSeconds;
  const resendDelay = cfg.resendDelay || OTP_DEFAULTS.resendDelay;
  const maxAttempts = cfg.maxAttempts || OTP_DEFAULTS.maxAttempts;

  let code = '';
  let attempts = maxAttempts;
  let expired = false;
  let locked = false;

  const codeTimer = createCountdown({
    seconds: codeSeconds,
    onTick: (rem) => { if (timerEl) timerEl.textContent = formatTime(rem); },
    onDone: () => {
      expired = true;
      statusEl.textContent = 'This code has expired.';
      statusEl.className = 'otp-status error-text';
      boxes.forEach(b => b.disabled = true);
      verifyBtn.textContent = 'Resend New Code';
      verifyBtn.disabled = false;
      verifyBtn.dataset.mode = 'resend-expired';
    }
  });

  const resendTimer = cfg.resendTimerId ? createCountdown({
    seconds: resendDelay,
    onTick: (rem) => { if (resendTimerEl) resendTimerEl.textContent = formatTime(rem); },
    onDone: () => { if (resendBtn) resendBtn.disabled = false; }
  }) : null;

  function reset() {
    code = cfg.fixedCode || generateOtp();
    attempts = maxAttempts;
    expired = false;
    locked = false;
    clearOtpGroup(boxes);
    boxes.forEach(b => b.disabled = false);
    statusEl.textContent = '';
    statusEl.className = 'otp-status';
    verifyBtn.disabled = true;
    verifyBtn.textContent = cfg.verifyLabel;
    verifyBtn.dataset.mode = 'verify';
    if (resendBtn) resendBtn.disabled = true;
    if (demoEl) demoEl.textContent = `Demo mode — your code is ${code}`;
    codeTimer.reset(codeSeconds);
    if (resendTimer) resendTimer.reset(resendDelay);
    if (metaLabelEl) metaLabelEl.textContent = 'Code expires in';
    return code;
  }

  boxesEl.addEventListener('otp-change', (e) => {
    if (locked || expired) return;
    verifyBtn.disabled = e.detail.length !== 6;
  });

  verifyBtn.addEventListener('click', () => {
    if (verifyBtn.dataset.mode === 'resend-expired') { reset(); if (cfg.onResend) cfg.onResend(); return; }
    const entered = getOtpValue(boxes);
    if (entered.length !== 6) return;

    if (entered === code) {
      markOtpGroup(boxes, 'success');
      statusEl.textContent = 'Verified!';
      statusEl.className = 'otp-status';
      statusEl.style.color = 'var(--green-600)';
      codeTimer.stop();
      if (resendTimer) resendTimer.stop();
      verifyBtn.disabled = true;
      setTimeout(() => cfg.onSuccess(), 450);
    } else {
      attempts -= 1;
      markOtpGroup(boxes, 'error');
      if (attempts <= 0) {
        locked = true;
        boxes.forEach(b => b.disabled = true);
        statusEl.textContent = 'Maximum attempts reached. Please request a new code.';
        statusEl.className = 'otp-status error-text';
        verifyBtn.disabled = true;
        if (resendBtn) resendBtn.disabled = false;
      } else {
        statusEl.textContent = `Incorrect code. Please try again. You have ${attempts} attempt${attempts === 1 ? '' : 's'} left.`;
        statusEl.className = 'otp-status error-text';
        setTimeout(() => { clearOtpGroup(boxes); verifyBtn.disabled = true; }, 250);
      }
    }
  });

  if (resendBtn) {
    resendBtn.addEventListener('click', () => {
      if (resendBtn.disabled) return;
      reset();
      if (cfg.onResend) cfg.onResend();
      showToast('A new code has been sent.');
    });
  }

  return {
    reset,
    getCode: () => code,
    boxes,
    stop() { codeTimer.stop(); if (resendTimer) resendTimer.stop(); }
  };
}

/* ---------------- Small helpers ---------------- */
function maskEmail(email) {
  const [name, domain] = String(email).split('@');
  if (!domain) return email;
  const visible = name.slice(0, Math.min(2, name.length));
  return `${visible}${'*'.repeat(Math.max(1, name.length - visible.length))}@${domain}`;
}
function generateSetupKey() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ234567';
  let out = '';
  for (let i = 0; i < 16; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
    if (i % 4 === 3 && i !== 15) out += ' ';
  }
  return out;
}