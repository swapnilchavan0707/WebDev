/* ============================================================
   SecureID — Login flow logic
   ============================================================ */

(function () {
  const brandSteps = document.querySelectorAll('#brandSteps .brand-step');
  const stepOrder = ['login', 'method', 'otp', 'success'];

  const session = { user: null, method: null };

  function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
    updateBrandSteps(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function updateBrandSteps(screenId) {
    const map = {
      'screen-login': 'login',
      'screen-method': 'method',
      'screen-otp': 'otp',
      'screen-login-success': 'success',
    };
    const key = map[screenId];
    const idx = stepOrder.indexOf(key);
    brandSteps.forEach(el => {
      const stepKey = el.getAttribute('data-step');
      const stepIdx = stepOrder.indexOf(stepKey);
      el.classList.remove('done', 'current');
      if (stepIdx < idx) el.classList.add('done');
      else if (stepIdx === idx) el.classList.add('current');
    });
  }

  document.querySelectorAll('[data-back]').forEach(btn => {
    btn.addEventListener('click', () => showScreen(btn.getAttribute('data-back')));
  });

  /* ============================================================
     SCREEN 1 — Login credentials
     ============================================================ */
  const loginForm = document.getElementById('loginForm');
  const loginAlert = document.getElementById('loginAlert');
  const emailInput = document.getElementById('loginEmail');
  const pwField = document.getElementById('loginPassword');

  function showAlert(el, msg) {
    if (!msg) { el.classList.remove('show'); return; }
    el.innerHTML = `${Icons.alert}<span>${msg}</span>`;
    el.classList.add('show');
  }
  function clearFieldErrors() {
    emailInput.classList.remove('error');
    pwField.classList.remove('error');
  }

  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    showAlert(loginAlert, '');
    clearFieldErrors();

    const identifier = emailInput.value.trim();
    const password = pwField.value;

    if (!identifier || !password) {
      showAlert(loginAlert, 'Please enter both your email/username and password.');
      if (!identifier) emailInput.classList.add('error');
      if (!password) pwField.classList.add('error');
      return;
    }

    const user = Store.findByEmail(identifier);

    if (!user || user.password !== password) {
      showAlert(loginAlert, 'Invalid email or password. Please try again.');
      emailInput.classList.add('error');
      pwField.classList.add('error');
      return;
    }

    session.user = user;
    buildMethodList(user);
    showScreen('screen-method');
  });

  document.getElementById('forgotPwBtn').addEventListener('click', () => {
    showToast("Password reset isn't wired up in this demo — that's a nice next feature!");
  });

  document.getElementById('googleLoginBtn').addEventListener('click', () => {
    showToast('Google sign-in is not available in this demo.');
  });

  /* ============================================================
     SCREEN 2 — Choose MFA method
     ============================================================ */
  const methodMeta = {
    email: { icon: 'mail', title: 'Email OTP', sub: 'Receive a code on your email' },
    sms: { icon: 'phone', title: 'SMS OTP', sub: 'Receive a code on your mobile' },
    authenticator: { icon: 'key', title: 'Authenticator App', sub: 'Use code from authenticator app' },
  };

  function buildMethodList(user) {
    const list = document.getElementById('loginMethodList');
    list.innerHTML = '';
    const preferred = user.mfaMethod || 'email';
    const order = [preferred, ...Object.keys(methodMeta).filter(m => m !== preferred)];

    order.forEach((key, i) => {
      const m = methodMeta[key];
      const div = document.createElement('div');
      div.className = 'method-option' + (i === 0 ? ' selected' : '');
      div.setAttribute('data-method', key);
      div.innerHTML = `
        <div class="method-icon">${Icons[m.icon]}</div>
        <div class="method-text">
          <div class="m-title">${m.title}</div>
          <div class="m-sub">${m.sub}</div>
        </div>
        <div class="method-radio"></div>`;
      div.addEventListener('click', () => {
        list.querySelectorAll('.method-option').forEach(o => o.classList.remove('selected'));
        div.classList.add('selected');
        session.method = key;
      });
      list.appendChild(div);
    });
    session.method = order[0];
  }

  document.getElementById('methodContinueBtn').addEventListener('click', () => {
    launchOtp(session.method);
  });

  /* ============================================================
     SCREEN 3 — OTP verification (adaptive)
     ============================================================ */
  let otpFlow = null;

  function launchOtp(method) {
    if (otpFlow) otpFlow.stop();
    const user = session.user;
    const iconEl = document.getElementById('loginOtpIcon');
    const titleEl = document.getElementById('loginOtpTitle');
    const subEl = document.getElementById('loginOtpSub');
    const targetEl = document.getElementById('loginOtpTarget');

    if (method === 'sms') {
      setIcon(iconEl, 'phone');
      titleEl.textContent = 'Mobile Verification';
      targetEl.textContent = `${user.countryCode || '+91'} ${user.mobile}`;
    } else if (method === 'authenticator') {
      setIcon(iconEl, 'key');
      titleEl.textContent = 'Authenticator Verification';
      targetEl.textContent = 'your authenticator app';
    } else {
      setIcon(iconEl, 'mail');
      titleEl.textContent = 'Email Verification';
      targetEl.textContent = user.email;
    }
    subEl.innerHTML = method === 'authenticator'
      ? 'Enter the 6-digit code from your authenticator app'
      : `Enter the 6-digit code sent to<br><strong>${targetEl.textContent}</strong>`;

    otpFlow = makeOtpFlow({
      boxesId: 'loginOtpBoxes', statusId: 'loginOtpStatus', timerId: 'loginOtpTimer',
      verifyBtnId: 'loginOtpVerifyBtn',
      resendBtnId: 'loginOtpResendBtn', resendTimerId: 'loginResendTimer',
      demoId: 'loginOtpDemo', verifyLabel: 'Verify & Login',
      codeSeconds: method === 'authenticator' ? 30 : 165,
      onSuccess: () => {
        document.getElementById('welcomeName').textContent = `Welcome back, ${user.fullName.split(' ')[0]}!`;
        showScreen('screen-login-success');
      },
    });
    otpFlow.reset();
    showScreen('screen-otp');
  }

  /* Numpad (visible on mobile widths) mirrors keyboard entry into the focused OTP box */
  const numpad = document.getElementById('loginNumpad');
  numpad.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-key]');
    if (!btn || !otpFlow) return;
    const key = btn.getAttribute('data-key');
    const boxes = otpFlow.boxes;
    if (key === 'del') {
      for (let i = boxes.length - 1; i >= 0; i--) {
        if (boxes[i].value) { boxes[i].value = ''; boxes[i].classList.remove('filled'); boxes[i].focus(); break; }
      }
    } else {
      for (let i = 0; i < boxes.length; i++) {
        if (!boxes[i].value) {
          boxes[i].value = key;
          boxes[i].classList.add('filled');
          boxes[i].focus();
          boxes[i].dispatchEvent(new Event('input'));
          break;
        }
      }
    }
  });

  document.getElementById('logoutBtn').addEventListener('click', () => {
    session.user = null;
    session.method = null;
    loginForm.reset();
    showAlert(loginAlert, '');
    clearFieldErrors();
    showScreen('screen-login');
  });

  /* ---------------- Seed a demo account for quick testing ---------------- */
  (function seedDemoUser() {
    if (!Store.findByEmail('priya.sharma@email.com')) {
      Store.upsert({
        fullName: 'Priya Sharma',
        email: 'priya.sharma@email.com',
        mobile: '9876543210',
        countryCode: '+91',
        password: 'Demo@1234',
        mfaMethod: 'email',
        mfaEnabled: true,
        createdAt: new Date().toISOString(),
      });
    }
  })();
})();