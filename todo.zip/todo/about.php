<?php
session_start();
include "includes/header.php";
?>
<style>
/* ================= CUSTOM STYLING MATCHING DASHBOARD ================= */
* { font-family: "Playfair Display", serif !important; font-optical-sizing: auto; font-style: normal; }
body, div, h1, h2, h3, p, a, input, button, table, th, td { font-family: "Playfair Display", serif !important; font-weight: 600 !important; letter-spacing: 0.02em; }
h1, h2, h3 { font-weight: 800 !important; }
input, button, td, th { font-size: 16px !important; }
.fa, .fa-solid, .fa-regular, .fa-brands { font-family: "Font Awesome 6 Free", "Font Awesome 6 Brands" !important; font-weight: 900 !important; }
.glass { background: rgba(255, 255, 255, 0.92); backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px); }
.hide-scrollbar { scrollbar-width: none; -ms-overflow-style: none; }
.hide-scrollbar::-webkit-scrollbar { display: none; }
</style>

<!-- BACKGROUND AMBIENT GLOWS -->
<div class="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[450px] bg-gradient-to-tr from-violet-500/20 via-fuchsia-500/10 to-amber-500/15 rounded-full blur-3xl"></div>
    <div class="absolute inset-0 bg-gradient-to-br from-[#fffcf7] via-[#f1f4fd] to-[#fff1ea] opacity-80"></div>
</div>

<div class="max-w-7xl mx-auto px-6 py-6 text-slate-800">

<!-- UNIQUE MARQUEE CAROUSEL FOR ABOUT -->
<div class="relative max-w-7xl mx-auto mb-12">
<div class="relative rounded-[2.5rem] overflow-hidden border border-indigo-100 shadow-2xl bg-white/95 backdrop-blur-2xl p-4">
<div class="relative overflow-hidden w-full h-48">
<button id="marqueePrev" class="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/95 border border-indigo-100 shadow-xl grid place-items-center hover:bg-gradient-to-r hover:from-indigo-600 hover:to-purple-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-left text-sm"></i></button>
<button id="marqueeNext" class="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/95 border border-indigo-100 shadow-xl grid place-items-center hover:bg-gradient-to-r hover:from-indigo-600 hover:to-purple-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-right text-sm"></i></button>
<div class="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"></div>
<div class="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"></div>

<div id="marqueeWrapper" class="flex gap-4 overflow-x-auto hide-scrollbar scroll-smooth py-2 px-1 h-full items-center">
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1515187029135-18ee286d815b?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-indigo-500/40 grid place-items-center"><i class="fa-solid fa-handshake text-indigo-300"></i></div> Corporate Culture</div>
</div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1531403009284-440f080d1e12?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-purple-500/40 grid place-items-center"><i class="fa-solid fa-brain text-purple-300"></i></div> Creative Brainstorming</div>
</div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-emerald-500/40 grid place-items-center"><i class="fa-solid fa-people-group text-emerald-300"></i></div> Dedicated Team</div>
</div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-amber-500/40 grid place-items-center"><i class="fa-solid fa-building text-amber-300"></i></div> Modern Workspace</div>
</div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1542744094-3a31243324d0?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-rose-500/40 grid place-items-center"><i class="fa-solid fa-trophy text-rose-300"></i></div> Mission & Vision</div>
</div>
</div>
</div>
</div>
</div>

<script>
const wrapper = document.getElementById('marqueeWrapper');
const cardWidth = 336;
let autoScroll = setInterval(() => {
    wrapper.scrollBy({ left: 1.5, behavior: 'smooth' });
    if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) {
        wrapper.scrollTo({ left: 0, behavior: 'smooth' });
    }
}, 30);

document.getElementById('marqueePrev').onclick = () => wrapper.scrollBy({ left: -cardWidth, behavior: 'smooth' });
document.getElementById('marqueeNext').onclick = () => wrapper.scrollBy({ left: cardWidth, behavior: 'smooth' });

wrapper.addEventListener('mouseenter', () => clearInterval(autoScroll));
wrapper.addEventListener('mouseleave', () => {
    autoScroll = setInterval(() => {
        wrapper.scrollBy({ left: 1.5, behavior: 'smooth' });
        if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) {
            wrapper.scrollTo({ left: 0, behavior: 'smooth' });
        }
    }, 30);
});
</script>

<div class="py-4">
<div class="text-center max-w-3xl mx-auto mb-16">
<span class="px-4 py-2 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-sm font-bold shadow-sm inline-block mb-4">Our Story & Mission</span>
<h1 class="text-4xl font-extrabold text-slate-900">Empowering Productivity Worldwide</h1>
<p class="text-slate-600 text-lg mt-4 leading-relaxed">
Built by Nexora Technologies, FlowTrack was engineered out of a passion for clean design, robust organization, and absolute efficiency.
</p>
</div>

<div class="grid md:grid-cols-2 gap-12 items-center mb-20">
<div class="glass p-8 rounded-[2.5rem] shadow-xl border border-indigo-100 space-y-6">
<h2 class="text-2xl font-extrabold text-slate-900">Who We Are</h2>
<p class="text-slate-600 text-base leading-relaxed">
We are a collective group of creators, engineers, and visionaries dedicated to building software that simplifies life. Whether you are managing personal chores or corporate pipelines, FlowTrack adapts seamlessly to your tempo.
</p>
<div class="grid grid-cols-2 gap-4 pt-2">
<div class="flex items-center gap-3 bg-white/70 p-3 rounded-2xl border border-indigo-50 shadow-sm">
<div class="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-indigo-700 grid place-items-center text-white shadow-md"><i class="fa-solid fa-check"></i></div>
<span class="font-bold text-slate-800 text-base">User Centric</span>
</div>
<div class="flex items-center gap-3 bg-white/70 p-3 rounded-2xl border border-indigo-50 shadow-sm">
<div class="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 grid place-items-center text-white shadow-md"><i class="fa-solid fa-check"></i></div>
<span class="font-bold text-slate-800 text-base">Modern Tech</span>
</div>
</div>
</div>
<div class="relative">
<div class="absolute -inset-1.5 bg-gradient-to-r from-amber-500 to-orange-600 rounded-[2.5rem] blur-xl opacity-20"></div>
<img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=800&auto=format&fit=crop" class="relative w-full h-96 object-cover rounded-[2.5rem] shadow-2xl border border-indigo-100" alt="Team">
</div>
</div>
</div>

</div>

<?php include "includes/footer.php"; ?>