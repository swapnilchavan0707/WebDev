<?php
// FlowTrack - Database Configuration
// Powered by Nexora Technologies

$host = "localhost";
$username = "root";
$password = "manager";
$dbname = "todo_db";
$charset = "utf8mb4";

$dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $conn = new PDO($dsn, $username, $password, $options);
} catch (PDOException $e) {
    // Log real error for developer only
    error_log("DB Connection Failed: " . $e->getMessage());
    
    // Show refined Playfair Display error page to user
    die("
    <link rel='preconnect' href='https://fonts.googleapis.com'>
    <link rel='preconnect' href='https://fonts.gstatic.com' crossorigin>
    <link href='https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap' rel='stylesheet'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css'>
    <body style='background-color:#fcfaf7; color:#1e293b; margin:0; padding:0; display:flex; align-items:center; justify-content:center; min-height:100vh;'>
    <div style='font-family:\"Playfair Display\",serif; text-align:center; max-width:480px; padding:40px; background:rgba(255, 255, 255, 0.92); backdrop-filter:blur(24px); -webkit-backdrop-filter:blur(24px); border-radius:2.5rem; box-shadow:0 20px 40px -15px rgba(0,0,0,0.1); border:1px solid #e2e8f0; margin:20px;'>
        <div style='width:72px; height:72px; margin:0 auto 24px; background:#ffe4e6; border-radius:1.25rem; display:grid; place-items:center; box-shadow:inset 0 2px 4px rgba(0,0,0,0.05);'>
            <i class='fa-solid fa-database' style='font-size:28px; color:#e11d48;'></i>
        </div>
        <h2 style='color:#0f172a; font-size:28px; font-weight:800; margin:0 0 12px 0;'>Database Connection Failed</h2>
        <p style='color:#475569; font-size:16px; font-weight:600; line-height:1.5; margin:0 0 8px 0;'>Please check your <code style='background:#f1f5f9; padding:2px 6px; border-radius:6px; color:#e11d48;'>config/db.php</code> credentials.</p>
        <p style='color:#94a3b8; font-size:14px; font-weight:600; margin:0 0 28px 0;'>The technical issue has been securely logged on the server.</p>
        <a href='../index.php' style='display:inline-flex; align-items:center; justify-content:center; gap:8px; background:linear-gradient(to right, #0f172a, #1e293b); color:#fff; padding:14px 28px; border-radius:999px; text-decoration:none; font-size:16px; font-weight:700; box-shadow:0 10px 20px -10px rgba(15,23,42,0.3); transition:all 0.2s ease;'>
            <i class='fa-solid fa-house'></i> Go Home
        </a>
    </div>
    </body>
    ");
}
?>