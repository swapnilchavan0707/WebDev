<?php
session_start();
include "../config/db.php";

/* ================= SECURITY ================= */
if (!isset($_SESSION['user_id'])) {
    header("Location:../index.php");
    exit;
}
if (!in_array($_SESSION['role'], ["Super Admin", "Admin"])) {
    die("<link href='https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap' rel='stylesheet'><div style='text-align:center;margin-top:100px;font-family:\"Playfair Display\",serif;'><h2 style='color:#e11d48;font-size:32px;font-weight:800;'>Access Denied</h2><p style='font-size:18px;font-weight:600;color:#475569;'>Only Admin & Super Admin allowed.</p><a href='../dashboard.php' style='background:#0f172a;color:#fff;padding:12px 24px;border-radius:999px;text-decoration:none;font-size:16px;font-weight:700;display:inline-block;margin-top:15px;'>Back to Dashboard</a></div>");
}

$success = ""; 
$error = "";

/* ================= ADD ADMIN ================= */
if (isset($_POST['add_admin'])) {
    $first = trim($_POST['first']); 
    $last = trim($_POST['last']); 
    $mobile = trim($_POST['mobile']); 
    $email = trim(strtolower($_POST['email'])); 
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); 
    $role = "Admin"; // New accounts created here are standard Admins

    if ($first && $last && $mobile && $email && $_POST['password']) {
        $check = $conn->prepare("SELECT user_id FROM users WHERE email = :email"); 
        $check->execute([':email' => $email]);
        if ($check->fetch()) {
            $error = "Email already exists!";
        } else {
            $sql = "INSERT INTO users (first_name, last_name, mobile_number, email, password, role) VALUES (:first, :last, :mobile, :email, :password, :role)";
            $stmt = $conn->prepare($sql); 
            $stmt->execute([':first' => $first, ':last' => $last, ':mobile' => $mobile, ':email' => $email, ':password' => $password, ':role' => $role]);
            header("Location: manage_admin.php?msg=added");
            exit;
        }
    } else {
        $error = "Please fill all fields!";
    }
}

/* ================= DELETE ADMIN ================= */
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete']; 

    // Prevent deleting Super Admin (ID 1)
    if ($id === 1) {
        header("Location: manage_admin.php?msg=protected");
        exit;
    }

    // Check if target is a Super Admin
    $targetCheck = $conn->prepare("SELECT role FROM users WHERE user_id = :id");
    $targetCheck->execute([':id' => $id]);
    $targetUser = $targetCheck->fetch();

    if ($targetUser && $targetUser['role'] === 'Super Admin') {
        header("Location: manage_admin.php?msg=protected");
        exit;
    }

    $del = $conn->prepare("DELETE FROM users WHERE user_id = :id AND role='Admin'"); 
    $del->execute([':id' => $id]);
    header("Location: manage_admin.php?msg=deleted"); 
    exit;
}

/* ================= UPDATE ADMIN ================= */
if (isset($_POST['update_admin'])) {
    $id = (int)$_POST['user_id']; 
    $first = trim($_POST['first']); 
    $last = trim($_POST['last']); 
    $mobile = trim($_POST['mobile']); 
    $email = trim(strtolower($_POST['email']));

    // Prevent regular admins from editing Super Admin (ID 1)
    if ($id === 1 && $_SESSION['user_id'] != 1) {
        header("Location: manage_admin.php?msg=protected");
        exit;
    }

    $targetCheck = $conn->prepare("SELECT role FROM users WHERE user_id = :id");
    $targetCheck->execute([':id' => $id]);
    $targetUser = $targetCheck->fetch();

    if ($targetUser && $targetUser['role'] === 'Super Admin' && $_SESSION['user_id'] != 1) {
        header("Location: manage_admin.php?msg=protected");
        exit;
    }
    
    if (!empty($_POST['password'])) {
        $password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);
        $sql = "UPDATE users SET first_name=:first, last_name=:last, mobile_number=:mobile, email=:email, password=:password WHERE user_id=:id";
        $params = [':first' => $first, ':last' => $last, ':mobile' => $mobile, ':email' => $email, ':password' => $password, ':id' => $id];
    } else {
        $sql = "UPDATE users SET first_name=:first, last_name=:last, mobile_number=:mobile, email=:email WHERE user_id=:id";
        $params = [':first' => $first, ':last' => $last, ':mobile' => $mobile, ':email' => $email, ':id' => $id];
    }
    $stmt = $conn->prepare($sql); 
    $stmt->execute($params);
    header("Location: manage_admin.php?msg=updated"); 
    exit;
}

if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'added') $success = "Admin added successfully!";
    if ($_GET['msg'] == 'deleted') $success = "Admin deleted successfully!";
    if ($_GET['msg'] == 'updated') $success = "Admin updated successfully!";
    if ($_GET['msg'] == 'protected') $error = "Security Alert: Super Admin account cannot be modified or deleted by standard admins!";
}

$stmt = $conn->prepare("SELECT * FROM users WHERE role IN ('Super Admin', 'Admin') ORDER BY user_id ASC"); 
$stmt->execute(); 
$admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Administrators - FlowTrack</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<style>
/* ================= CUSTOM STYLING MATCHING DASHBOARD ================= */
* { font-family: "Playfair Display", serif !important; font-optical-sizing: auto; font-style: normal; }
body, div, h1, h2, h3, p, a, input, button, table, th, td, textarea, select { font-family: "Playfair Display", serif !important; font-weight: 600 !important; letter-spacing: 0.02em; }
h1, h2, h3 { font-weight: 800 !important; }
input, button, td, th { font-size: 16px !important; }
.fa, .fa-solid, .fa-regular, .fa-brands { font-family: "Font Awesome 6 Free", "Font Awesome 6 Brands" !important; font-weight: 900 !important; }
.glass { background: rgba(255, 255, 255, 0.92); backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px); }
.hide-scrollbar { scrollbar-width: none; -ms-overflow-style: none; }
.hide-scrollbar::-webkit-scrollbar { display: none; }
</style>
</head>
<body class="bg-[#fcfaf7] min-h-screen text-slate-800 relative selection:bg-purple-600 selection:text-white">

<!-- BACKGROUND AMBIENT GLOWS -->
<div class="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[450px] bg-gradient-to-tr from-purple-500/20 via-indigo-500/10 to-amber-500/15 rounded-full blur-3xl"></div>
    <div class="absolute inset-0 bg-gradient-to-br from-[#fffcf7] via-[#f4f3fd] to-[#f0f5ff] opacity-85"></div>
</div>

<!-- NAVBAR -->
<nav class="bg-white/90 backdrop-blur-md shadow-sm border-b border-indigo-100 sticky top-0 z-50">
<div class="max-w-7xl mx-auto px-6 h-24 flex justify-between items-center">
<a href="../dashboard.php" class="flex items-center gap-3 group">
    <div class="w-12 h-12 bg-gradient-to-br from-purple-600 to-indigo-700 rounded-2xl flex items-center justify-center shadow-lg shadow-purple-600/25 group-hover:scale-105 transition"><i class="fa-solid fa-shield-halved text-white"></i></div>
    <div><h1 class="text-xl font-extrabold text-slate-900 leading-none">FlowTrack</h1><p class="text-xs text-slate-400 tracking-widest mt-1 font-bold">Admin Management</p></div>
</a>
<div class="flex items-center gap-4">
    <span class="hidden md:flex items-center gap-2 text-base text-slate-600 font-bold bg-indigo-50 border border-indigo-100 px-4 py-2 rounded-xl"><i class="fa-solid fa-user-tie text-purple-600"></i> <?= htmlspecialchars($_SESSION['role']) ?></span>
    <a href="../dashboard.php" class="px-5 py-2.5 rounded-full bg-slate-900 text-white hover:bg-slate-950 shadow-lg shadow-slate-900/20 text-base flex items-center gap-2 h-11 font-extrabold transition-all hover:scale-105"><i class="fa-solid fa-arrow-left"></i> Dashboard</a>
</div>
</div>
</nav>

<!-- MARQUEE CAROUSEL -->
<div class="relative max-w-7xl mx-auto px-6 mt-6 group">
<div class="relative rounded-[2.5rem] overflow-hidden border border-indigo-100 shadow-2xl bg-white/95 backdrop-blur-2xl p-4 h-48">
<button id="marqueePrev" class="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/95 border border-indigo-100 shadow-xl grid place-items-center hover:bg-gradient-to-r hover:from-purple-600 hover:to-indigo-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-left text-sm"></i></button>
<button id="marqueeNext" class="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/95 border border-indigo-100 shadow-xl grid place-items-center hover:bg-gradient-to-r hover:from-purple-600 hover:to-indigo-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-right text-sm"></i></button>
<div class="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"></div>
<div class="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"></div>
<div id="marqueeWrapper" class="overflow-x-auto hide-scrollbar h-full scroll-smooth">
<div class="flex gap-4 p-1 h-full items-center">
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card shadow-md"><img src="https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base font-bold flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-purple-500/40 grid place-items-center"><i class="fa-solid fa-shield-dog text-purple-300"></i></div> Admin Security</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card shadow-md"><img src="https://images.unsplash.com/photo-1454165205744-3b78555e5572?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base font-bold flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-indigo-500/40 grid place-items-center"><i class="fa-solid fa-network-wired text-indigo-300"></i></div> Role Hierarchy</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card shadow-md"><img src="https://images.unsplash.com/photo-1521791136064-7986c2920216?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base font-bold flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-blue-500/40 grid place-items-center"><i class="fa-solid fa-user-shield text-blue-300"></i></div> Control Center</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card shadow-md"><img src="https://images.unsplash.com/photo-1553877522-43269d4ea984?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base font-bold flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-amber-500/40 grid place-items-center"><i class="fa-solid fa-lock text-amber-300"></i></div> Access Management</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card shadow-md"><img src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base font-bold flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-emerald-500/40 grid place-items-center"><i class="fa-solid fa-users-gear text-emerald-300"></i></div> System Administration</div></div>
</div></div>
</div>
</div>
<script>
const wrapper = document.getElementById('marqueeWrapper'); 
let auto = setInterval(() => { 
    wrapper.scrollBy({ left: 1.5, behavior: 'smooth' }); 
    if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) wrapper.scrollTo({ left: 0, behavior: 'smooth' }); 
}, 30);
document.getElementById('marqueePrev').onclick = () => wrapper.scrollBy({ left: -350, behavior: 'smooth' }); 
document.getElementById('marqueeNext').onclick = () => wrapper.scrollBy({ left: 350, behavior: 'smooth' });
wrapper.addEventListener('mouseenter', () => clearInterval(auto)); 
wrapper.addEventListener('mouseleave', () => { 
    auto = setInterval(() => { 
        wrapper.scrollBy({ left: 1.5, behavior: 'smooth' }); 
        if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) wrapper.scrollTo({ left: 0, behavior: 'smooth' }); 
    }, 30); 
});
</script>

<!-- ADD ADMIN -->
<div class="max-w-6xl mx-auto mt-10 glass p-8 md:p-12 rounded-[2.5rem] shadow-xl border border-indigo-100">
<?php if($success): ?>
    <div class="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-2xl mb-6 flex items-center gap-3 text-base font-extrabold shadow-sm">
        <div class="w-8 h-8 rounded-xl bg-emerald-500 text-white grid place-items-center"><i class="fa-solid fa-circle-check"></i></div> 
        <?= $success ?>
    </div>
<?php endif; ?>

<?php if($error): ?>
    <div class="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-2xl mb-6 flex items-center gap-3 text-base font-extrabold shadow-sm">
        <div class="w-8 h-8 rounded-xl bg-rose-500 text-white grid place-items-center"><i class="fa-solid fa-circle-exclamation"></i></div> 
        <?= $error ?>
    </div>
<?php endif; ?>

<h2 class="text-2xl font-extrabold text-slate-900 mb-6 flex items-center gap-3">
    <div class="w-10 h-10 rounded-xl bg-purple-100 text-purple-600 grid place-items-center shadow-inner"><i class="fa-solid fa-user-plus text-base"></i></div> Add New Administrator
</h2>
<form method="POST" class="grid md:grid-cols-3 gap-5">
<input name="first" placeholder="First Name" class="border border-indigo-100 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-purple-600 focus:border-purple-600 outline-none text-base text-slate-900 shadow-sm font-semibold" required>
<input name="last" placeholder="Last Name" class="border border-indigo-100 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-purple-600 focus:border-purple-600 outline-none text-base text-slate-900 shadow-sm font-semibold" required>
<input name="mobile" placeholder="Mobile Number" class="border border-indigo-100 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-purple-600 focus:border-purple-600 outline-none text-base text-slate-900 shadow-sm font-semibold" required>
<input name="email" type="email" placeholder="Email Address" class="border border-indigo-100 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-purple-600 focus:border-purple-600 outline-none md:col-span-2 text-base text-slate-900 shadow-sm font-semibold" required>
<input name="password" type="password" placeholder="Password" class="border border-indigo-100 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-purple-600 focus:border-purple-600 outline-none text-base text-slate-900 shadow-sm font-semibold" required>
<button name="add_admin" class="bg-gradient-to-r from-purple-600 to-indigo-700 text-white py-4 rounded-full hover:from-purple-700 hover:to-indigo-800 md:col-span-3 shadow-lg shadow-purple-600/25 text-base flex items-center justify-center gap-2 font-extrabold transition-all hover:scale-[1.01] cursor-pointer"><i class="fa-solid fa-plus"></i> Add Administrator</button>
</form>
</div>

<!-- ADMIN LIST TABLE -->
<div class="max-w-6xl mx-auto mt-10 mb-16 glass p-8 md:p-12 rounded-[2.5rem] shadow-xl border border-indigo-100">
<h2 class="text-2xl font-extrabold text-slate-900 mb-6 flex items-center justify-between">
    <span class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-600 grid place-items-center shadow-inner"><i class="fa-solid fa-shield text-base"></i></div> Administrator List
    </span>
    <span class="bg-indigo-50 border border-indigo-100 text-indigo-800 px-4 py-1.5 rounded-full text-sm font-extrabold">Total: <?= count($admins) ?></span>
</h2>
<div class="overflow-x-auto rounded-2xl border border-indigo-100">
<table class="w-full border-collapse">
<thead>
    <tr class="bg-gradient-to-r from-purple-600 to-indigo-700 text-white text-left text-base"><th class="p-4 font-extrabold">Sr No</th><th class="p-4 font-extrabold">Name</th><th class="p-4 font-extrabold">Email</th><th class="p-4 font-extrabold">Mobile</th><th class="p-4 font-extrabold">Role</th><th class="p-4 font-extrabold">Action</th></tr>
</thead>
<tbody class="text-base">
<?php $i = 1; foreach($admins as $a) { 
    $isSuperAdmin = ($a['role'] === 'Super Admin' || $a['user_id'] == 1);
?>
<tr class="border-b border-indigo-50 hover:bg-white/80 transition">
    <td class="p-4 text-slate-500 font-semibold"><?= $i++ ?></td>
    <td class="p-4 font-extrabold text-slate-900"><?= htmlspecialchars($a['first_name']." ".$a['last_name']) ?></td>
    <td class="p-4 text-slate-600 font-semibold"><?= htmlspecialchars($a['email']) ?></td>
    <td class="p-4 text-slate-600 font-semibold"><?= htmlspecialchars($a['mobile_number']) ?></td>
    <td class="p-4">
        <span class="px-3 py-1 rounded-full text-sm font-extrabold text-white <?= $isSuperAdmin ? 'bg-indigo-600 shadow-sm' : 'bg-purple-500 shadow-sm' ?>">
            <?= htmlspecialchars($a['role']) ?>
        </span>
    </td>
    <td class="p-4 flex gap-2 items-center">
        <?php 
            $canModify = true;
            if ($isSuperAdmin && $_SESSION['user_id'] != 1) {
                $canModify = false;
            }
        ?>
        <?php if ($canModify || $_SESSION['user_id'] == $a['user_id']): ?>
            <button onclick="openEdit('<?= $a['user_id'] ?>','<?= htmlspecialchars($a['first_name']) ?>','<?= htmlspecialchars($a['last_name']) ?>','<?= htmlspecialchars($a['mobile_number']) ?>','<?= htmlspecialchars($a['email']) ?>')" class="bg-amber-500 text-white px-4 py-2 rounded-full hover:bg-amber-600 text-sm font-extrabold flex items-center gap-1.5 shadow-sm transition hover:scale-105 cursor-pointer"><i class="fa-solid fa-pen"></i> Edit</button>
        <?php else: ?>
            <span class="text-xs text-slate-400 font-semibold italic px-2 py-1 bg-slate-100 rounded-lg">Protected</span>
        <?php endif; ?>

        <?php if (!$isSuperAdmin): ?>
            <a href="?delete=<?= $a['user_id'] ?>" onclick="return confirm('Are you sure you want to delete this administrator?')" class="bg-rose-500 text-white px-4 py-2 rounded-full hover:bg-rose-600 text-sm font-extrabold flex items-center gap-1.5 shadow-sm transition hover:scale-105"><i class="fa-solid fa-trash"></i> Delete</a>
        <?php endif; ?>
    </td>
</tr>
<?php } if (count($admins) == 0) { echo "<tr><td colspan='6' class='p-8 text-center text-slate-400 text-base font-semibold'><i class='fa-solid fa-inbox text-3xl mb-2 block text-purple-500'></i>No administrators found.</td></tr>"; } ?>
</tbody></table>
</div>
</div>

<!-- EDIT MODAL -->
<div id="editModal" class="hidden fixed inset-0 bg-slate-950/60 backdrop-blur-md flex items-center justify-center z-50 p-4">
<div class="glass bg-white/95 w-full max-w-md p-8 rounded-[2.5rem] shadow-2xl border border-indigo-100">
<h2 class="text-2xl font-extrabold text-slate-900 mb-6 flex items-center gap-2"><div class="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-600 grid place-items-center text-sm"><i class="fa-solid fa-pen-to-square"></i></div> Edit Administrator</h2>
<form method="POST" class="space-y-4">
<input type="hidden" name="user_id" id="e_id">
<div>
    <label class="block text-sm text-slate-600 mb-1 font-extrabold">First Name</label>
    <input name="first" id="e_first" class="w-full border border-indigo-100 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-purple-600 outline-none text-base font-semibold text-slate-900 shadow-sm" required>
</div>
<div>
    <label class="block text-sm text-slate-600 mb-1 font-extrabold">Last Name</label>
    <input name="last" id="e_last" class="w-full border border-indigo-100 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-purple-600 outline-none text-base font-semibold text-slate-900 shadow-sm" required>
</div>
<div>
    <label class="block text-sm text-slate-600 mb-1 font-extrabold">Mobile Number</label>
    <input name="mobile" id="e_mobile" class="w-full border border-indigo-100 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-purple-600 outline-none text-base font-semibold text-slate-900 shadow-sm" required>
</div>
<div>
    <label class="block text-sm text-slate-600 mb-1 font-extrabold">Email Address</label>
    <input name="email" id="e_email" type="email" class="w-full border border-indigo-100 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-purple-600 outline-none text-base font-semibold text-slate-900 shadow-sm" required>
</div>
<div>
    <label class="block text-sm text-slate-600 mb-1 font-extrabold">New Password <span class="text-xs text-slate-400 font-normal">(Optional)</span></label>
    <input name="password" type="password" class="w-full border border-indigo-100 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-purple-600 outline-none text-base font-semibold text-slate-900 shadow-sm" placeholder="Leave blank to keep current">
</div>
<button name="update_admin" class="bg-gradient-to-r from-purple-600 to-indigo-700 text-white w-full py-3.5 rounded-full hover:from-purple-700 hover:to-indigo-800 shadow-lg shadow-purple-600/25 flex items-center justify-center gap-2 text-base font-extrabold transition-all hover:scale-[1.02] cursor-pointer mt-2"><i class="fa-solid fa-check"></i> Update Administrator</button>
</form>
<button onclick="closeEdit()" class="mt-4 w-full text-slate-500 text-base font-extrabold hover:text-slate-800 transition"><i class="fa-solid fa-xmark mr-1"></i> Close Modal</button>
</div>
</div>

<script>
function openEdit(id, f, l, m, e) {
    document.getElementById("editModal").classList.remove("hidden");
    document.getElementById("e_id").value = id;
    document.getElementById("e_first").value = f;
    document.getElementById("e_last").value = l;
    document.getElementById("e_mobile").value = m;
    document.getElementById("e_email").value = e;
}
function closeEdit() {
    document.getElementById("editModal").classList.add("hidden");
}
</script>
</body>
</html>