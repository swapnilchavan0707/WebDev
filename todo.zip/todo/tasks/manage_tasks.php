<?php
session_start();
include "../config/db.php";

/* ================= SECURITY ================= */
if (!isset($_SESSION['user_id'])) {
    header("Location:../index.php");
    exit;
}

$current_user_id = $_SESSION['user_id'];
$success = "";
$error = "";

/* ================= ADD TASK ================= */
if (isset($_POST['add_task'])) {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $status = trim($_POST['status']);

    if ($title && $status) {
        $sql = "INSERT INTO tasks (user_id, title, description, status) VALUES (:user_id, :title, :description, :status)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':user_id' => $current_user_id,
            ':title' => $title,
            ':description' => $description,
            ':status' => $status
        ]);
        header("Location: manage_tasks.php?msg=added");
        exit;
    } else {
        $error = "Task Title and Status are required fields.";
    }
}

/* ================= DELETE TASK ================= */
if (isset($_GET['delete'])) {
    $task_id = (int)$_GET['delete'];
    
    // Ensure users can only delete their own tasks
    $del = $conn->prepare("DELETE FROM tasks WHERE task_id = :task_id AND user_id = :user_id");
    $del->execute([
        ':task_id' => $task_id,
        ':user_id' => $current_user_id
    ]);
    header("Location: manage_tasks.php?msg=deleted");
    exit;
}

/* ================= UPDATE TASK ================= */
if (isset($_POST['update_task'])) {
    $task_id = (int)($_POST['task_id'] ?? 0);
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $status = trim($_POST['status']);

    if ($title && $status) {
        $sql = "UPDATE tasks SET title = :title, description = :description, status = :status WHERE task_id = :task_id AND user_id = :user_id";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':title' => $title,
            ':description' => $description,
            ':status' => $status,
            ':task_id' => $task_id,
            ':user_id' => $current_user_id
        ]);
        header("Location: manage_tasks.php?msg=updated");
        exit;
    } else {
        $error = "Task Title and Status are required fields.";
    }
}

if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'added') $success = "Task created successfully!";
    if ($_GET['msg'] == 'deleted') $success = "Task deleted successfully!";
    if ($_GET['msg'] == 'updated') $success = "Task updated successfully!";
}

/* ================= FETCH TASKS FOR CURRENT USER ================= */
$stmt = $conn->prepare("SELECT * FROM tasks WHERE user_id = :user_id ORDER BY task_id DESC");
$stmt->execute([':user_id' => $current_user_id]);
$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Tasks - FlowTrack</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<style>
* { font-family: "Playfair Display", serif !important; font-optical-sizing: auto; font-style: normal; }
body, div, h1, h2, h3, p, a, input, button, table, th, td, label, textarea, select { font-family: "Playfair Display", serif !important; font-weight: 600 !important; letter-spacing: 0.01em; }
h1, h2 { font-weight: 800 !important; }
input, button, td, th, textarea, select { font-size: 16px !important; }
.fa, .fa-solid, .fa-regular, .fa-brands { font-family: "Font Awesome 6 Free", "Font Awesome 6 Brands" !important; font-weight: 900 !important; }
.glass { background: rgba(255, 255, 255, 0.88); backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px); }
.hide-scrollbar { scrollbar-width: none; -ms-overflow-style: none; }
.hide-scrollbar::-webkit-scrollbar { display: none; }
</style>
</head>
<body class="bg-[#fcfaf7] text-[#1e293b] min-h-screen relative">
<div class="fixed inset-0 -z-10 pointer-events-none">
    <div class="absolute inset-0 bg-gradient-to-br from-[#fcfaf7] via-[#f4f7f6] to-[#edf2f7]"></div>
    <div class="absolute top-[-10%] left-[10%] w-96 h-96 bg-emerald-100/40 rounded-full blur-3xl"></div>
    <div class="absolute bottom-[-10%] right-[5%] w-96 h-96 bg-blue-100/30 rounded-full blur-3xl"></div>
</div>

<!-- NAVBAR -->
<nav class="bg-white/80 backdrop-blur-md shadow-[0_10px_30px_-15px_rgba(0,0,0,0.08)] border-b border-slate-200 sticky top-0 z-50">
<div class="max-w-7xl mx-auto px-6 h-24 flex justify-between items-center">
<a href="../dashboard.php" class="flex items-center gap-3.5 group">
    <div class="w-12 h-12 bg-gradient-to-tr from-slate-900 to-slate-800 rounded-2xl flex items-center justify-center shadow-md group-hover:scale-105 transition"><i class="fa-solid fa-list-check text-white text-lg"></i></div>
    <div><h1 class="text-2xl font-extrabold text-slate-900 leading-none">FlowTrack</h1><p class="text-xs text-slate-500 tracking-widest mt-1 uppercase font-bold">Task Manager</p></div>
</a>
<div class="flex items-center gap-4">
    <span class="hidden md:flex items-center text-sm text-slate-600 bg-slate-100 px-4 py-2 rounded-full border border-slate-200"><i class="fa-solid fa-user mr-2 text-emerald-600"></i> <?= htmlspecialchars($_SESSION['role']) ?></span>
    <a href="../dashboard.php" class="px-6 py-3 rounded-full bg-slate-900 text-white hover:bg-slate-800 shadow-md text-sm flex items-center gap-2 h-11 transition"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
</div>
</div>
</nav>

<!-- MARQUEE CAROUSEL -->
<div class="relative max-w-7xl mx-auto px-6 mt-8 group">
<div class="relative rounded-3xl overflow-hidden border border-slate-200 shadow-[0_20px_40px_-15px_rgba(0,0,0,0.07)] bg-white h-48">
<button id="marqueePrev" class="absolute left-4 top-1/2 -translate-y-1/2 z-25 w-10 h-10 rounded-full bg-white/90 border border-slate-200 shadow-lg grid place-items-center hover:bg-slate-900 hover:text-white transition-all hover:scale-105"><i class="fa-solid fa-chevron-left text-xs"></i></button>
<button id="marqueeNext" class="absolute right-4 top-1/2 -translate-y-1/2 z-25 w-10 h-10 rounded-full bg-white/90 border border-slate-200 shadow-lg grid place-items-center hover:bg-slate-900 hover:text-white transition-all hover:scale-105"><i class="fa-solid fa-chevron-right text-xs"></i></button>
<div class="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"></div>
<div class="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"></div>
<div id="marqueeWrapper" class="overflow-x-auto hide-scrollbar h-full scroll-smooth">
<div class="flex gap-4 p-3 h-full">
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card shadow-sm"><img src="https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-105 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base font-bold flex items-center gap-2"><i class="fa-solid fa-clipboard-list text-emerald-300"></i> Task Execution</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card shadow-sm"><img src="https://images.unsplash.com/photo-1507925921958-8a62f3d1a50d?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-105 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base font-bold flex items-center gap-2"><i class="fa-solid fa-bullseye text-emerald-300"></i> Goal Tracking</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card shadow-sm"><img src="https://images.unsplash.com/photo-1454165205744-3b78555e5572?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-105 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base font-bold flex items-center gap-2"><i class="fa-solid fa-business-time text-emerald-300"></i> Productivity Hub</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card shadow-sm"><img src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-105 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base font-bold flex items-center gap-2"><i class="fa-solid fa-list-check text-emerald-300"></i> Workflow Control</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card shadow-sm"><img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-105 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base font-bold flex items-center gap-2"><i class="fa-solid fa-check-double text-emerald-300"></i> Task Completion</div></div>
</div></div>
</div>
</div>
<script>
const wrapper = document.getElementById('marqueeWrapper'); 
let auto = setInterval(() => { 
    wrapper.scrollBy({ left: 2 }); 
    if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) wrapper.scrollTo({ left: 0, behavior: 'smooth' }); 
}, 30);
document.getElementById('marqueePrev').onclick = () => wrapper.scrollBy({ left: -350, behavior: 'smooth' }); 
document.getElementById('marqueeNext').onclick = () => wrapper.scrollBy({ left: 350, behavior: 'smooth' });
wrapper.addEventListener('mouseenter', () => clearInterval(auto)); 
wrapper.addEventListener('mouseleave', () => { 
    auto = setInterval(() => { 
        wrapper.scrollBy({ left: 2 }); 
        if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) wrapper.scrollTo({ left: 0, behavior: 'smooth' }); 
    }, 30); 
});
</script>

<!-- ADD TASK -->
<div class="max-w-6xl mx-auto mt-8 glass p-8 sm:p-10 rounded-3xl shadow-[0_20px_40px_-15px_rgba(0,0,0,0.05)] border border-slate-200">
<?php if($success): ?><div class="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-2xl mb-6 flex items-center gap-3 text-base shadow-sm"><i class="fa-solid fa-circle-check text-emerald-600 text-lg"></i> <?= $success ?></div><?php endif; ?>
<?php if($error): ?><div class="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-2xl mb-6 flex items-center gap-3 text-base shadow-sm"><i class="fa-solid fa-circle-exclamation text-rose-600 text-lg"></i> <?= $error ?></div><?php endif; ?>
<h2 class="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
    <span class="w-10 h-10 rounded-xl bg-slate-900 text-white grid place-items-center shadow-md"><i class="fa-solid fa-plus text-sm"></i></span> Add New Task
</h2>
<form method="POST" class="grid md:grid-cols-3 gap-4">
<input name="title" placeholder="Task Title" class="border border-slate-200 p-4 rounded-2xl bg-white/90 focus:ring-2 focus:ring-slate-900 focus:outline-none text-slate-800 shadow-sm md:col-span-2" required>
<select name="status" class="border border-slate-200 p-4 rounded-2xl bg-white/90 focus:ring-2 focus:ring-slate-900 focus:outline-none text-slate-800 shadow-sm" required>
    <option value="Pending">Pending</option>
    <option value="In Progress">In Progress</option>
    <option value="Completed">Completed</option>
</select>
<textarea name="description" placeholder="Task Description..." class="border border-slate-200 p-4 rounded-2xl bg-white/90 focus:ring-2 focus:ring-slate-900 focus:outline-none md:col-span-3 text-slate-800 shadow-sm h-28"></textarea>
<button name="add_task" class="bg-gradient-to-r from-slate-900 to-slate-800 text-white py-4 rounded-full hover:from-slate-800 hover:to-slate-700 md:col-span-3 shadow-lg text-base flex items-center justify-center gap-2 font-bold transition"><i class="fa-solid fa-circle-plus"></i> Create Task</button>
</form>
</div>

<!-- TASK LIST TABLE -->
<div class="max-w-6xl mx-auto mt-8 mb-16 glass p-8 sm:p-10 rounded-3xl shadow-[0_20px_40px_-15px_rgba(0,0,0,0.05)] border border-slate-200">
<h2 class="text-2xl font-bold text-slate-900 mb-6 flex items-center justify-between">
    <span class="flex items-center gap-3">
        <span class="w-10 h-10 rounded-xl bg-slate-900 text-white grid place-items-center shadow-md"><i class="fa-solid fa-tasks text-sm"></i></span> My Tasks List
    </span>
    <span class="text-sm bg-slate-100 text-slate-700 px-4 py-1.5 rounded-full border border-slate-200">Total: <?= count($tasks) ?></span>
</h2>
<div class="overflow-x-auto rounded-2xl border border-slate-200 bg-white/50 shadow-sm">
<table class="w-full border-collapse text-left">
<thead>
    <tr class="bg-slate-900 text-white text-base"><th class="p-4.5">Sr No</th><th class="p-4.5">Title</th><th class="p-4.5">Description</th><th class="p-4.5">Status</th><th class="p-4.5">Action</th></tr>
</thead>
<tbody class="text-base text-slate-700">
<?php $i = 1; foreach($tasks as $t) { 
    $statusClass = 'bg-amber-50 text-amber-700 border-amber-200';
    if ($t['status'] === 'Completed') $statusClass = 'bg-emerald-50 text-emerald-700 border-emerald-200';
    if ($t['status'] === 'In Progress') $statusClass = 'bg-indigo-50 text-indigo-700 border-indigo-200';
?>
<tr class="border-b border-slate-100 hover:bg-slate-50/80 transition">
    <td class="p-4.5 font-bold text-slate-500"><?= $i++ ?></td>
    <td class="p-4.5 font-bold text-slate-900"><?= htmlspecialchars($t['title']) ?></td>
    <td class="p-4.5 text-slate-600 max-w-xs truncate"><?= htmlspecialchars($t['description']) ?></td>
    <td class="p-4.5"><span class="px-3.5 py-1 rounded-full text-xs font-bold border <?= $statusClass ?>"><?= htmlspecialchars($t['status']) ?></span></td>
    <td class="p-4.5 flex gap-2">
        <button onclick="openEdit('<?= $t['task_id'] ?>','<?= htmlspecialchars(addslashes($t['title'])) ?>','<?= htmlspecialchars(addslashes($t['description'])) ?>','<?= htmlspecialchars($t['status']) ?>')" class="bg-amber-500 text-white px-3.5 py-2 rounded-full hover:bg-amber-600 text-sm flex items-center gap-1 shadow-sm transition"><i class="fa-solid fa-pen"></i> Edit</button>
        <a href="?delete=<?= $t['task_id'] ?>" onclick="return confirm('Are you sure you want to delete this task?')" class="bg-rose-500 text-white px-3.5 py-2 rounded-full hover:bg-rose-600 text-sm flex items-center gap-1 shadow-sm transition"><i class="fa-solid fa-trash"></i> Delete</a>
    </td>
</tr>
<?php } if (count($tasks) == 0) { echo "<tr><td colspan='5' class='p-12 text-center text-slate-400 text-base'><i class='fa-solid fa-inbox text-3xl mb-3 block text-slate-300'></i>No tasks found. Create your first task above!</td></tr>"; } ?>
</tbody></table>
</div>
</div>

<!-- EDIT MODAL -->
<div id="editModal" class="hidden fixed inset-0 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center z-50 p-4">
<div class="bg-white/95 backdrop-blur-xl w-full max-w-md p-8 rounded-3xl shadow-2xl border border-slate-200">
<h2 class="text-2xl font-bold mb-6 flex items-center gap-2.5 text-slate-900"><i class="fa-solid fa-pen-to-square text-emerald-600"></i> Edit Task</h2>
<form method="POST" class="space-y-4">
<input type="hidden" name="task_id" id="e_id">
<input name="title" id="e_title" class="w-full border border-slate-200 p-3.5 rounded-2xl bg-slate-50 focus:ring-2 focus:ring-slate-900 focus:outline-none text-slate-800 font-semibold" placeholder="Task Title" required>
<select name="status" id="e_status" class="w-full border border-slate-200 p-3.5 rounded-2xl bg-slate-50 focus:ring-2 focus:ring-slate-900 focus:outline-none text-slate-800 font-semibold" required>
    <option value="Pending">Pending</option>
    <option value="In Progress">In Progress</option>
    <option value="Completed">Completed</option>
</select>
<textarea name="description" id="e_desc" class="w-full border border-slate-200 p-3.5 rounded-2xl bg-slate-50 focus:ring-2 focus:ring-slate-900 focus:outline-none text-slate-800 h-28 font-semibold" placeholder="Task Description..."></textarea>
<button name="update_task" class="bg-slate-900 text-white w-full py-3.5 rounded-full hover:bg-slate-800 shadow-lg flex items-center justify-center gap-2 text-base font-bold transition mt-2"><i class="fa-solid fa-check"></i> Update Task</button>
</form>
<button onclick="closeEdit()" class="mt-4 w-full text-slate-500 text-sm font-bold hover:text-slate-800 py-2"><i class="fa-solid fa-xmark mr-1"></i> Close</button>
</div>
</div>

<script>
function openEdit(id, title, desc, status) {
    document.getElementById("editModal").classList.remove("hidden");
    document.getElementById("e_id").value = id;
    document.getElementById("e_title").value = title;
    document.getElementById("e_desc").value = desc;
    document.getElementById("e_status").value = status;
}
function closeEdit() {
    document.getElementById("editModal").classList.add("hidden");
}
</script>
</body>
</html>