</main>

<footer class="bg-white/90 backdrop-blur-md border-t border-indigo-100 mt-20 py-12">
<div class="max-w-7xl mx-auto px-6 grid md:grid-cols-4 gap-8">
<div>
<div class="flex items-center gap-3 mb-4">
<div class="w-10 h-10 bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl flex items-center justify-center text-white shadow-md shadow-amber-600/25"><i class="fa-solid fa-list-check"></i></div>
<span class="text-lg font-extrabold text-slate-900">FlowTrack</span>
</div>
<p class="text-sm text-slate-600 leading-relaxed font-semibold">Elevating daily productivity through intelligent task organization and real-time execution tracking.</p>
</div>
<div>
<h4 class="font-extrabold text-slate-900 mb-4">Quick Navigation</h4>
<ul class="space-y-2 text-sm text-slate-600 font-semibold">
<li><a href="index.php" class="hover:text-amber-600 transition">Home Page</a></li>
<li><a href="about.php" class="hover:text-amber-600 transition">About Our Story</a></li>
<li><a href="services.php" class="hover:text-amber-600 transition">Core Services</a></li>
<li><a href="contact.php" class="hover:text-amber-600 transition">Contact Team</a></li>
</ul>
</div>
<div>
<h4 class="font-extrabold text-slate-900 mb-4">Workspace</h4>
<ul class="space-y-2 text-sm text-slate-600 font-semibold">
<li><a href="dashboard.php" class="hover:text-amber-600 transition">User Dashboard</a></li>
<li><a href="tasks/manage_tasks.php" class="hover:text-amber-600 transition">Task Manager</a></li>
</ul>
</div>
<div>
<h4 class="font-extrabold text-slate-900 mb-4">Secure Network</h4>
<p class="text-sm text-slate-500 mb-4 font-semibold">Protected by Nexora Technologies advanced safety vaults.</p>
<div class="flex gap-3 text-amber-600">
<a href="#" class="w-10 h-10 rounded-full bg-amber-50 border border-amber-200 grid place-items-center hover:bg-gradient-to-r hover:from-amber-500 hover:to-orange-600 hover:text-white transition shadow-sm"><i class="fa-brands fa-x-twitter"></i></a>
<a href="#" class="w-10 h-10 rounded-full bg-amber-50 border border-amber-200 grid place-items-center hover:bg-gradient-to-r hover:from-amber-500 hover:to-orange-600 hover:text-white transition shadow-sm"><i class="fa-brands fa-linkedin-in"></i></a>
<a href="#" class="w-10 h-10 rounded-full bg-amber-50 border border-amber-200 grid place-items-center hover:bg-gradient-to-r hover:from-amber-500 hover:to-orange-600 hover:text-white transition shadow-sm"><i class="fa-brands fa-github"></i></a>
</div>
</div>
</div>
<div class="max-w-7xl mx-auto px-6 border-t border-indigo-100 mt-8 pt-8 text-center text-sm text-slate-400 font-bold">
&copy; <?= date('Y'); ?> FlowTrack Pro. All rights reserved. Built with precision and elegance.
</div>
</footer>
</body>
</html>