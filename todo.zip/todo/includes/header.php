<?php
// includes/header.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FlowTrack Pro - Task & Workflow Management</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<style>
* { font-family: "Playfair Display", serif !important; font-optical-sizing: auto; font-style: normal; }
body, div, h1, h2, h3, p, a, input, button, table, th, td, textarea, select, label { font-family: "Playfair Display", serif !important; font-weight: 600 !important; letter-spacing: 0.02em; }
h1, h2, h3 { font-weight: 800 !important; }
input, button, td, th, textarea, select { font-size: 16px !important; }
.fa, .fa-solid, .fa-regular, .fa-brands { font-family: "Font Awesome 6 Free", "Font Awesome 6 Brands" !important; font-weight: 900 !important; }
.glass { background: rgba(255, 255, 255, 0.92); backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px); }
.hide-scrollbar { scrollbar-width: none; -ms-overflow-style: none; }
.hide-scrollbar::-webkit-scrollbar { display: none; }
.card-hover { transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1); }
.card-hover:hover { transform: translateY(-6px); box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.1); }
</style>
</head>
<body class="bg-[#fcfaf7] min-h-screen text-slate-800 flex flex-col justify-between selection:bg-amber-600 selection:text-white relative">

<!-- BACKGROUND AMBIENT GLOWS -->
<div class="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[450px] bg-gradient-to-tr from-violet-500/20 via-fuchsia-500/10 to-amber-500/15 rounded-full blur-3xl"></div>
    <div class="absolute inset-0 bg-gradient-to-br from-[#fffcf7] via-[#f1f4fd] to-[#fff1ea] opacity-85"></div>
</div>

<!-- NAVIGATION BAR -->
<nav class="bg-white/90 backdrop-blur-md shadow-sm border-b border-indigo-100 sticky top-0 z-50">
<div class="max-w-7xl mx-auto px-6 h-24 flex justify-between items-center">
<a href="<?php echo (basename($_SERVER['PHP_SELF']) == 'dashboard.php') ? 'dashboard.php' : 'index.php'; ?>" class="flex items-center gap-3 group">
<div class="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl flex items-center justify-center shadow-lg shadow-amber-600/25 group-hover:scale-105 transition"><i class="fa-solid fa-list-check text-white text-lg"></i></div>
<div><h1 class="text-xl font-extrabold text-slate-900 leading-none">FlowTrack</h1><p class="text-xs text-slate-400 tracking-widest mt-1 font-bold">Workspace Pro</p></div>
</a>

<div class="hidden md:flex items-center gap-8">
<a href="index.php" class="text-base font-bold text-slate-700 hover:text-amber-600 transition">Home</a>
<a href="about.php" class="text-base font-bold text-slate-700 hover:text-amber-600 transition">About</a>
<a href="services.php" class="text-base font-bold text-slate-700 hover:text-amber-600 transition">Services</a>
<a href="contact.php" class="text-base font-bold text-slate-700 hover:text-amber-600 transition">Contact</a>
</div>

<div class="flex items-center gap-3">
<?php if(isset($_SESSION['user_id'])): ?>
<span class="hidden lg:inline text-base text-slate-700 mr-2"><i class="fa-solid fa-user-circle text-amber-600 mr-1"></i> <?= htmlspecialchars($_SESSION['name'] ?? 'User') ?></span>
<a href="dashboard.php" class="px-6 py-3 rounded-full bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 text-white font-bold shadow-lg shadow-amber-600/25 hover:from-amber-600 hover:to-orange-700 text-sm flex items-center gap-2 transition-all hover:scale-105"><i class="fa-solid fa-gauge"></i> Dashboard</a>
<a href="auth/logout.php" class="px-5 py-3 rounded-full bg-rose-600 text-white font-bold hover:bg-rose-700 shadow-lg shadow-rose-600/25 text-sm flex items-center gap-2 transition-all hover:scale-105"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
<?php else: ?>
<button onclick="openLogin()" class="px-6 py-3 rounded-full bg-white border border-indigo-100 text-slate-800 font-bold hover:bg-slate-50 shadow-sm text-sm transition-all hover:scale-105">Sign In</button>
<button onclick="openRegister()" class="px-6 py-3 rounded-full bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 text-white font-bold shadow-lg shadow-amber-600/25 hover:from-amber-600 hover:to-orange-700 text-sm transition-all hover:scale-105">Get Started</button>
<?php endif; ?>
</div>
</div>
</nav>

<!-- AUTH MODALS (LOGIN / REGISTER) -->
<div id="loginModal" class="hidden fixed inset-0 bg-slate-950/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
<div class="glass bg-white/95 w-full max-w-md p-8 rounded-[2.5rem] shadow-2xl border border-indigo-100 relative animate-in">
<h2 class="text-2xl font-extrabold mb-2 text-slate-900 flex items-center gap-2"><div class="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-600 grid place-items-center text-sm"><i class="fa-solid fa-right-to-bracket"></i></div> Welcome Back</h2>
<p class="text-sm text-slate-500 mb-4">Enter your credentials to access your workspace.</p>
<div id="loginError" class="hidden mb-4 p-3 rounded-2xl bg-red-50 border border-red-200 text-red-600 text-xs font-bold"></div>
<form id="loginForm" onsubmit="handleLogin(event)" class="space-y-4">
<div><label class="text-xs font-bold text-slate-500 mb-1 block">Email Address</label><input type="email" name="email" class="w-full p-3.5 border border-indigo-100 rounded-2xl bg-white/80 focus:ring-2 focus:ring-amber-500 outline-none text-base" required></div>
<div><label class="text-xs font-bold text-slate-500 mb-1 block">Password</label><input type="password" name="password" class="w-full p-3.5 border border-indigo-100 rounded-2xl bg-white/80 focus:ring-2 focus:ring-amber-500 outline-none text-base" required></div>
<button type="submit" id="loginBtn" class="w-full bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 text-white py-3.5 rounded-full font-extrabold hover:from-amber-600 hover:to-orange-700 shadow-lg shadow-amber-600/25 text-base transition-all hover:scale-[1.02]">Sign In</button>
</form>
<button onclick="closeLogin()" class="absolute top-6 right-6 w-9 h-9 rounded-full bg-slate-100 grid place-items-center text-slate-500 hover:bg-slate-200 transition"><i class="fa-solid fa-xmark"></i></button>
</div>
</div>

<div id="registerModal" class="hidden fixed inset-0 bg-slate-950/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
<div class="glass bg-white/95 w-full max-w-md p-8 rounded-[2.5rem] shadow-2xl border border-indigo-100 relative animate-in">
<h2 class="text-2xl font-extrabold mb-2 text-slate-900 flex items-center gap-2"><div class="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-600 grid place-items-center text-sm"><i class="fa-solid fa-rocket"></i></div> Create Account</h2>
<p class="text-sm text-slate-500 mb-4">Get started with FlowTrack Pro today.</p>
<div id="registerError" class="hidden mb-4 p-3 rounded-2xl bg-red-50 border border-red-200 text-red-600 text-xs font-bold"></div>
<form id="registerForm" onsubmit="handleRegister(event)" class="space-y-4">
<div><label class="text-xs font-bold text-slate-500 mb-1 block">Full Name</label><input type="text" name="name" class="w-full p-3.5 border border-indigo-100 rounded-2xl bg-white/80 focus:ring-2 focus:ring-amber-500 outline-none text-base" required></div>
<div><label class="text-xs font-bold text-slate-500 mb-1 block">Email Address</label><input type="email" name="email" class="w-full p-3.5 border border-indigo-100 rounded-2xl bg-white/80 focus:ring-2 focus:ring-amber-500 outline-none text-base" required></div>
<div><label class="text-xs font-bold text-slate-500 mb-1 block">Password (min 6 chars)</label><input type="password" name="password" class="w-full p-3.5 border border-indigo-100 rounded-2xl bg-white/80 focus:ring-2 focus:ring-amber-500 outline-none text-base" required></div>
<button type="submit" id="registerBtn" class="w-full bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 text-white py-3.5 rounded-full font-extrabold hover:from-amber-600 hover:to-orange-700 shadow-lg shadow-amber-600/25 text-base transition-all hover:scale-[1.02]">Register Now</button>
</form>
<button onclick="closeRegister()" class="absolute top-6 right-6 w-9 h-9 rounded-full bg-slate-100 grid place-items-center text-slate-500 hover:bg-slate-200 transition"><i class="fa-solid fa-xmark"></i></button>
</div>
</div>

<script>
function openLogin() { document.getElementById('loginModal').classList.remove('hidden'); }
function closeLogin() { document.getElementById('loginModal').classList.add('hidden'); }
function openRegister() { document.getElementById('registerModal').classList.remove('hidden'); }
function closeRegister() { document.getElementById('registerModal').classList.add('hidden'); }

async function handleLogin(e) {
    e.preventDefault();
    const form = document.getElementById('loginForm');
    const errBox = document.getElementById('loginError');
    const btn = document.getElementById('loginBtn');
    errBox.classList.add('hidden');
    btn.disabled = true;
    btn.innerText = 'Signing In...';

    try {
        const response = await fetch('auth/login.php', {
            method: 'POST',
            body: new URLSearchParams(new FormData(form))
        });
        const result = await response.text();
        if (result.trim() === 'success') {
            window.location.href = 'dashboard.php';
        } else {
            errBox.innerText = 'Invalid email or password combination.';
            errBox.classList.remove('hidden');
            btn.disabled = false;
            btn.innerText = 'Sign In';
        }
    } catch (err) {
        errBox.innerText = 'Connection error. Please try again.';
        errBox.classList.remove('hidden');
        btn.disabled = false;
        btn.innerText = 'Sign In';
    }
}

async function handleRegister(e) {
    e.preventDefault();
    const form = document.getElementById('registerForm');
    const errBox = document.getElementById('registerError');
    const btn = document.getElementById('registerBtn');
    errBox.classList.add('hidden');
    btn.disabled = true;
    btn.innerText = 'Creating Account...';

    try {
        const response = await fetch('auth/register.php', {
            method: 'POST',
            body: new URLSearchParams(new FormData(form))
        });
        const result = await response.text();
        if (result.trim() === 'success') {
            window.location.reload();
        } else if (result.trim() === 'exists') {
            errBox.innerText = 'This email address is already registered. Please sign in instead.';
            errBox.classList.remove('hidden');
            btn.disabled = false;
            btn.innerText = 'Register Now';
        } else {
            errBox.innerText = 'Registration failed. Password must be at least 6 characters.';
            errBox.classList.remove('hidden');
            btn.disabled = false;
            btn.innerText = 'Register Now';
        }
    } catch (err) {
        errBox.innerText = 'Connection error. Please try again.';
        errBox.classList.remove('hidden');
        btn.disabled = false;
        btn.innerText = 'Register Now';
    }
}
</script>

<main class="max-w-7xl mx-auto px-6 w-full flex-grow my-8">