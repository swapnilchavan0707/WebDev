<?php
session_start();
include "config/db.php";

/* ================= SECURITY ================= */
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
$current_user_id = $_SESSION['user_id'];
$success = "";
$error = "";

/* ================= UPDATE PROFILE ================= */
if (isset($_POST['update_profile'])) {
    $first = trim($_POST['first_name']);
    $last = trim($_POST['last_name']);
    $mobile = trim($_POST['mobile_number']);
    $email = trim(strtolower($_POST['email']));

    if ($first && $last && $mobile && $email) {
        // Check if email is taken by another user
        $check = $conn->prepare("SELECT user_id FROM users WHERE email = :email AND user_id != :id");
        $check->execute([':email' => $email, ':id' => $current_user_id]);
        if ($check->fetch()) {
            $error = "Email address is already in use by another account!";
        } else {
            if (!empty($_POST['password'])) {
                $password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);
                $sql = "UPDATE users SET first_name=:first, last_name=:last, mobile_number=:mobile, email=:email, password=:password WHERE user_id=:id";
                $params = [':first' => $first, ':last' => $last, ':mobile' => $mobile, ':email' => $email, ':password' => $password, ':id' => $current_user_id];
            } else {
                $sql = "UPDATE users SET first_name=:first, last_name=:last, mobile_number=:mobile, email=:email WHERE user_id=:id";
                $params = [':first' => $first, ':last' => $last, ':mobile' => $mobile, ':email' => $email, ':id' => $current_user_id];
            }
            $stmt = $conn->prepare($sql);
            $stmt->execute($params);

            // Update session name if changed
            $_SESSION['name'] = $first . " " . $last;
            $success = "Profile updated successfully!";
        }
    } else {
        $error = "Please fill in all required fields.";
    }
}

/* ================= FETCH USER DETAILS ================= */
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = :id");
$stmt->execute([':id' => $current_user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Profile - FlowTrack</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<style>
/* ================= CUSTOM STYLING MATCHING DASHBOARD ================= */
* { font-family: "Playfair Display", serif !important; font-optical-sizing: auto; font-style: normal; }
body, div, h1, h2, h3, p, a, input, button, label { font-family: "Playfair Display", serif !important; font-weight: 600 !important; letter-spacing: 0.02em; }
h1, h2 { font-weight: 800 !important; }
input, button { font-size: 16px !important; }
.fa, .fa-solid, .fa-regular, .fa-brands { font-family: "Font Awesome 6 Free", "Font Awesome 6 Brands" !important; font-weight: 900 !important; }
.glass { background: rgba(255, 255, 255, 0.92); backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px); }
.hide-scrollbar { scrollbar-width: none; -ms-overflow-style: none; }
.hide-scrollbar::-webkit-scrollbar { display: none; }
</style>
</head>
<body class="bg-[#fcfaf7] min-h-screen text-slate-800 relative selection:bg-amber-600 selection:text-white">

<!-- BACKGROUND AMBIENT GLOWS -->
<div class="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[450px] bg-gradient-to-tr from-violet-500/20 via-fuchsia-500/10 to-amber-500/15 rounded-full blur-3xl"></div>
    <div class="absolute inset-0 bg-gradient-to-br from-[#fffcf7] via-[#f1f4fd] to-[#fff1ea] opacity-85"></div>
</div>

<!-- NAVBAR -->
<nav class="bg-white/90 backdrop-blur-md shadow-sm border-b border-indigo-100 sticky top-0 z-50">
<div class="max-w-7xl mx-auto px-6 h-24 flex justify-between items-center">
<a href="dashboard.php" class="flex items-center gap-3 group">
    <div class="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl flex items-center justify-center shadow-lg shadow-amber-600/25 group-hover:scale-105 transition"><i class="fa-solid fa-user-gear text-white"></i></div>
    <div><h1 class="text-xl font-extrabold text-slate-900 leading-none">FlowTrack</h1><p class="text-xs text-slate-400 tracking-widest mt-1 font-bold">Account Settings</p></div>
</a>
<div class="flex items-center gap-4">
    <span class="hidden md:flex items-center gap-2 text-base text-slate-600 font-bold bg-indigo-50 border border-indigo-100 px-4 py-2 rounded-xl"><i class="fa-solid fa-shield-halved text-amber-600"></i> <?= htmlspecialchars($user['role']) ?></span>
    <a href="dashboard.php" class="px-5 py-2.5 rounded-full bg-slate-900 text-white hover:bg-slate-950 shadow-lg shadow-slate-900/20 text-base flex items-center gap-2 h-11 font-extrabold transition-all hover:scale-105"><i class="fa-solid fa-arrow-left"></i> Dashboard</a>
</div>
</div>
</nav>

<!-- PROFILE SECTION -->
<div class="max-w-3xl mx-auto mt-12 mb-16 glass p-8 md:p-12 rounded-[2.5rem] shadow-xl border border-indigo-100">
<?php if($success): ?>
    <div class="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-2xl mb-6 flex items-center gap-3 text-base font-extrabold shadow-sm">
        <div class="w-8 h-8 rounded-xl bg-emerald-500 text-white grid place-items-center"><i class="fa-solid fa-circle-check"></i></div> 
        <?= $success ?>
    </div>
<?php endif; ?>

<?php if($error): ?>
    <div class="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-2xl mb-6 flex items-center gap-3 text-base font-extrabold shadow-sm">
        <div class="w-8 h-8 rounded-xl bg-rose-500 text-white grid place-items-center"><i class="fa-solid fa-circle-exclamation"></i></div> 
        <?= $error ?>
    </div>
<?php endif; ?>

<div class="flex items-center gap-5 mb-8 pb-6 border-b border-indigo-100">
    <div class="w-20 h-20 bg-gradient-to-br from-amber-500 to-orange-600 text-white rounded-2xl flex items-center justify-center text-3xl shadow-lg shadow-amber-600/25 font-extrabold shrink-0">
        <?= strtoupper(substr($user['first_name'], 0, 1)) ?>
    </div>
    <div>
        <h2 class="text-3xl font-extrabold text-slate-900"><?= htmlspecialchars($user['first_name'] . " " . $user['last_name']) ?></h2>
        <p class="text-base text-slate-600 mt-1 flex items-center gap-2 font-semibold"><i class="fa-solid fa-envelope text-amber-600"></i> <?= htmlspecialchars($user['email']) ?> &bull; <span class="bg-amber-50 text-amber-800 border border-amber-200 px-3 py-0.5 rounded-full text-sm font-extrabold"><?= htmlspecialchars($user['role']) ?></span></p>
    </div>
</div>

<form method="POST" class="space-y-6">
<div class="grid md:grid-cols-2 gap-5">
    <div>
        <label class="block text-sm text-slate-600 mb-1.5 font-extrabold"><i class="fa-solid fa-user mr-1 text-amber-600"></i> First Name</label>
        <input name="first_name" value="<?= htmlspecialchars($user['first_name']) ?>" class="w-full border border-indigo-100 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-base font-semibold text-slate-900 shadow-sm" required>
    </div>
    <div>
        <label class="block text-sm text-slate-600 mb-1.5 font-extrabold"><i class="fa-solid fa-user mr-1 text-amber-600"></i> Last Name</label>
        <input name="last_name" value="<?= htmlspecialchars($user['last_name']) ?>" class="w-full border border-indigo-100 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-base font-semibold text-slate-900 shadow-sm" required>
    </div>
</div>

<div class="grid md:grid-cols-2 gap-5">
    <div>
        <label class="block text-sm text-slate-600 mb-1.5 font-extrabold"><i class="fa-solid fa-phone mr-1 text-amber-600"></i> Mobile Number</label>
        <input name="mobile_number" value="<?= htmlspecialchars($user['mobile_number']) ?>" class="w-full border border-indigo-100 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-base font-semibold text-slate-900 shadow-sm" required>
    </div>
    <div>
        <label class="block text-sm text-slate-600 mb-1.5 font-extrabold"><i class="fa-solid fa-envelope mr-1 text-amber-600"></i> Email Address</label>
        <input name="email" type="email" value="<?= htmlspecialchars($user['email']) ?>" class="w-full border border-indigo-100 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-base font-semibold text-slate-900 shadow-sm" required>
    </div>
</div>

<div>
    <label class="block text-sm text-slate-600 mb-1.5 font-extrabold"><i class="fa-solid fa-lock mr-1 text-amber-600"></i> New Password <span class="text-xs text-slate-400 font-semibold">(Leave blank to keep current password)</span></label>
    <input name="password" type="password" placeholder="Enter new password if you want to change it" class="w-full border border-indigo-100 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-base font-semibold text-slate-900 shadow-sm">
</div>

<button name="update_profile" class="w-full bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 text-white py-4 rounded-full hover:from-amber-600 hover:to-orange-700 shadow-lg shadow-amber-600/25 text-base flex items-center justify-center gap-2 font-extrabold transition-all hover:scale-[1.02] cursor-pointer"><i class="fa-solid fa-floppy-disk"></i> Save Profile Changes</button>
</form>
</div>

</body>
</html>