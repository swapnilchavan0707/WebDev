<?php
session_start();
include "includes/header.php";
?>
<style>
/* ================= CUSTOM STYLING MATCHING DASHBOARD ================= */
* { font-family: "Playfair Display", serif !important; font-optical-sizing: auto; font-style: normal; }
body, div, h1, h2, h3, p, a, input, button, table, th, td { font-family: "Playfair Display", serif !important; font-weight: 600 !important; letter-spacing: 0.02em; }
h1, h2, h3 { font-weight: 800 !important; }
input, button, td, th { font-size: 16px !important; }
.fa, .fa-solid, .fa-regular, .fa-brands { font-family: "Font Awesome 6 Free", "Font Awesome 6 Brands" !important; font-weight: 900 !important; }
.glass { background: rgba(255, 255, 255, 0.92); backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px); }
.hide-scrollbar { scrollbar-width: none; -ms-overflow-style: none; }
.hide-scrollbar::-webkit-scrollbar { display: none; }
</style>

<!-- BACKGROUND AMBIENT GLOWS -->
<div class="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[450px] bg-gradient-to-tr from-violet-500/20 via-fuchsia-500/10 to-amber-500/15 rounded-full blur-3xl"></div>
    <div class="absolute inset-0 bg-gradient-to-br from-[#fffcf7] via-[#f1f4fd] to-[#fff1ea] opacity-80"></div>
</div>

<div class="max-w-7xl mx-auto px-6 py-6 text-slate-800">

<!-- UNIQUE MARQUEE CAROUSEL FOR CONTACT -->
<div class="relative max-w-7xl mx-auto mb-12">
<div class="relative rounded-[2.5rem] overflow-hidden border border-indigo-100 shadow-2xl bg-white/95 backdrop-blur-2xl p-4">
<div class="relative overflow-hidden w-full h-48">
<button id="marqueePrev" class="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/95 border border-indigo-100 shadow-xl grid place-items-center hover:bg-gradient-to-r hover:from-indigo-600 hover:to-purple-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-left text-sm"></i></button>
<button id="marqueeNext" class="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/95 border border-indigo-100 shadow-xl grid place-items-center hover:bg-gradient-to-r hover:from-indigo-600 hover:to-purple-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-right text-sm"></i></button>
<div class="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"></div>
<div class="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"></div>

<div id="marqueeWrapper" class="flex gap-4 overflow-x-auto hide-scrollbar scroll-smooth py-2 px-1 h-full items-center">
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1423784346385-c1d4dac9093a?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-indigo-500/40 grid place-items-center"><i class="fa-solid fa-headset text-indigo-300"></i></div> Customer Support Desk</div>
</div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1577563908411-5077b6dc7624?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-purple-500/40 grid place-items-center"><i class="fa-solid fa-comments text-purple-300"></i></div> Client Communication</div>
</div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-emerald-500/40 grid place-items-center"><i class="fa-solid fa-envelope-open-text text-emerald-300"></i></div> Inquiry Response Hub</div>
</div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1534536281715-e28d76689b4d?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-amber-500/40 grid place-items-center"><i class="fa-solid fa-phone-volume text-amber-300"></i></div> Hotline Assistance</div>
</div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-rose-500/40 grid place-items-center"><i class="fa-solid fa-building-user text-rose-300"></i></div> Corporate Office</div>
</div>
</div>
</div>
</div>
</div>

<script>
const wrapper = document.getElementById('marqueeWrapper');
const cardWidth = 336;
let autoScroll = setInterval(() => {
    wrapper.scrollBy({ left: 1.5, behavior: 'smooth' });
    if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) {
        wrapper.scrollTo({ left: 0, behavior: 'smooth' });
    }
}, 30);

document.getElementById('marqueePrev').onclick = () => wrapper.scrollBy({ left: -cardWidth, behavior: 'smooth' });
document.getElementById('marqueeNext').onclick = () => wrapper.scrollBy({ left: cardWidth, behavior: 'smooth' });

wrapper.addEventListener('mouseenter', () => clearInterval(autoScroll));
wrapper.addEventListener('mouseleave', () => {
    autoScroll = setInterval(() => {
        wrapper.scrollBy({ left: 1.5, behavior: 'smooth' });
        if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) {
            wrapper.scrollTo({ left: 0, behavior: 'smooth' });
        }
    }, 30);
});
</script>

<div class="py-4">
<div class="text-center max-w-3xl mx-auto mb-16">
<span class="px-4 py-2 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-sm font-bold shadow-sm inline-block mb-4">Get In Touch</span>
<h1 class="text-4xl font-extrabold text-slate-900">We Would Love To Hear From You</h1>
<p class="text-slate-600 text-lg mt-4">Have questions or feedback? Reach out to our dedicated corporate support team.</p>
</div>

<!-- CONTACT DETAILS SECTION -->
<div class="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-16 px-4">
    
    <!-- Corporate HQ -->
    <div class="glass p-8 rounded-[2rem] shadow-xl border border-indigo-100 space-y-4 hover:shadow-2xl hover:border-amber-300 transition group">
        <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 grid place-items-center text-white text-xl shadow-md group-hover:scale-110 transition"><i class="fa-solid fa-building"></i></div>
        <h3 class="text-xl font-extrabold text-slate-900">Corporate HQ</h3>
        <p class="text-slate-600 text-base leading-relaxed">Nexora Technologies, Pune Office, Maharashtra, India.</p>
    </div>

    <!-- Call Support -->
    <div class="glass p-8 rounded-[2rem] shadow-xl border border-indigo-100 space-y-4 hover:shadow-2xl hover:border-indigo-300 transition group">
        <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-indigo-700 grid place-items-center text-white text-xl shadow-md group-hover:scale-110 transition"><i class="fa-solid fa-headset"></i></div>
        <h3 class="text-xl font-extrabold text-slate-900">Call Support</h3>
        <p class="text-slate-600 text-base leading-relaxed">
            <a href="tel:+919876543210" class="hover:text-indigo-600 font-extrabold">+91 98765 43210</a><br>
            <span class="text-xs text-slate-400 font-bold">Mon - Fri, 9:00 AM - 6:00 PM</span>
        </p>
    </div>

    <!-- Email Address -->
    <div class="glass p-8 rounded-[2rem] shadow-xl border border-indigo-100 space-y-4 hover:shadow-2xl hover:border-emerald-300 transition group">
        <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 grid place-items-center text-white text-xl shadow-md group-hover:scale-110 transition"><i class="fa-solid fa-envelope"></i></div>
        <h3 class="text-xl font-extrabold text-slate-900">Email Address</h3>
        <p class="text-slate-600 text-base leading-relaxed">
            <a href="mailto:support@flowtrack.nexora.com" class="hover:text-indigo-600 font-extrabold break-all">support@flowtrack.nexora.com</a><br>
            <span class="text-xs text-slate-400 font-bold">Online 24/7 for queries</span>
        </p>
    </div>

</div>
</div>

<?php include "includes/footer.php"; ?>