<?php
session_start();
include "includes/header.php";
?>
<style>
/* ================= CUSTOM STYLING MATCHING DASHBOARD ================= */
* { font-family: "Playfair Display", serif !important; font-optical-sizing: auto; font-style: normal; }
body, div, h1, h2, h3, p, a, input, button, table, th, td { font-family: "Playfair Display", serif !important; font-weight: 600 !important; letter-spacing: 0.02em; }
h1, h2, h3 { font-weight: 800 !important; }
input, button, td, th { font-size: 16px !important; }
.fa, .fa-solid, .fa-regular, .fa-brands { font-family: "Font Awesome 6 Free", "Font Awesome 6 Brands" !important; font-weight: 900 !important; }
.glass { background: rgba(255, 255, 255, 0.92); backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px); }
.hide-scrollbar { scrollbar-width: none; -ms-overflow-style: none; }
.hide-scrollbar::-webkit-scrollbar { display: none; }
</style>

<!-- BACKGROUND AMBIENT GLOWS -->
<div class="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[450px] bg-gradient-to-tr from-violet-500/20 via-fuchsia-500/10 to-amber-500/15 rounded-full blur-3xl"></div>
    <div class="absolute inset-0 bg-gradient-to-br from-[#fffcf7] via-[#f1f4fd] to-[#fff1ea] opacity-80"></div>
</div>

<div class="max-w-7xl mx-auto px-6 py-6 text-slate-800">

<!-- UNIQUE MARQUEE CAROUSEL FOR SERVICES -->
<div class="relative max-w-7xl mx-auto mb-12">
<div class="relative rounded-[2.5rem] overflow-hidden border border-indigo-100 shadow-2xl bg-white/95 backdrop-blur-2xl p-4">
<div class="relative overflow-hidden w-full h-48">
<button id="marqueePrev" class="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/95 border border-indigo-100 shadow-xl grid place-items-center hover:bg-gradient-to-r hover:from-indigo-600 hover:to-purple-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-left text-sm"></i></button>
<button id="marqueeNext" class="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/95 border border-indigo-100 shadow-xl grid place-items-center hover:bg-gradient-to-r hover:from-indigo-600 hover:to-purple-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-right text-sm"></i></button>
<div class="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"></div>
<div class="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"></div>

<div id="marqueeWrapper" class="flex gap-4 overflow-x-auto hide-scrollbar scroll-smooth py-2 px-1 h-full items-center">
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1454165205744-3b78555e5572?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-indigo-500/40 grid place-items-center"><i class="fa-solid fa-chart-pie text-indigo-300"></i></div> Enterprise Analytics</div>
</div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1563986768609-322da13575f3?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-purple-500/40 grid place-items-center"><i class="fa-solid fa-shield-halved text-purple-300"></i></div> Data Security & Vaults</div>
</div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-emerald-500/40 grid place-items-center"><i class="fa-solid fa-list-check text-emerald-300"></i></div> Advanced Task Sorting</div>
</div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-amber-500/40 grid place-items-center"><i class="fa-solid fa-gauge-high text-amber-300"></i></div> Performance Metrics</div>
</div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1531482615713-2afd69097998?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-rose-500/40 grid place-items-center"><i class="fa-solid fa-headset text-rose-300"></i></div> 24/7 Expert Support</div>
</div>
</div>
</div>
</div>
</div>

<script>
const wrapper = document.getElementById('marqueeWrapper');
const cardWidth = 336;
let autoScroll = setInterval(() => {
    wrapper.scrollBy({ left: 1.5, behavior: 'smooth' });
    if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) {
        wrapper.scrollTo({ left: 0, behavior: 'smooth' });
    }
}, 30);

document.getElementById('marqueePrev').onclick = () => wrapper.scrollBy({ left: -cardWidth, behavior: 'smooth' });
document.getElementById('marqueeNext').onclick = () => wrapper.scrollBy({ left: cardWidth, behavior: 'smooth' });

wrapper.addEventListener('mouseenter', () => clearInterval(autoScroll));
wrapper.addEventListener('mouseleave', () => {
    autoScroll = setInterval(() => {
        wrapper.scrollBy({ left: 1.5, behavior: 'smooth' });
        if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) {
            wrapper.scrollTo({ left: 0, behavior: 'smooth' });
        }
    }, 30);
});
</script>

<div class="py-4">
<div class="text-center max-w-3xl mx-auto mb-16">
<span class="px-4 py-2 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-sm font-bold shadow-sm inline-block mb-4">What We Offer</span>
<h1 class="text-4xl font-extrabold text-slate-900">Professional Services & Solutions</h1>
<p class="text-slate-600 text-lg mt-4">Discover our comprehensive suite of productivity and organizational toolsets.</p>
</div>

<div class="grid md:grid-cols-3 gap-8 mb-16">
<div class="glass p-8 rounded-[2rem] shadow-xl border border-indigo-100 hover:shadow-2xl hover:border-amber-300 transition group">
<div class="w-14 h-14 bg-gradient-to-br from-indigo-500 to-indigo-700 rounded-2xl grid place-items-center text-white text-xl mb-6 shadow-md group-hover:scale-110 transition"><i class="fa-solid fa-chart-simple"></i></div>
<h3 class="text-xl font-extrabold text-slate-900 mb-3">Analytics Dashboard</h3>
<p class="text-slate-600 text-base leading-relaxed">Real-time statistics displaying task velocity, completion percentages, and milestone breakdowns.</p>
</div>
<div class="glass p-8 rounded-[2rem] shadow-xl border border-indigo-100 hover:shadow-2xl hover:border-indigo-300 transition group">
<div class="w-14 h-14 bg-gradient-to-br from-violet-500 to-purple-600 rounded-2xl grid place-items-center text-white text-xl mb-6 shadow-md group-hover:scale-110 transition"><i class="fa-solid fa-lock"></i></div>
<h3 class="text-xl font-extrabold text-slate-900 mb-3">Secure Workspace</h3>
<p class="text-slate-600 text-base leading-relaxed">Isolated database vaults ensuring your private corporate notes and project data remain entirely safe.</p>
</div>
<div class="glass p-8 rounded-[2rem] shadow-xl border border-indigo-100 hover:shadow-2xl hover:border-emerald-300 transition group">
<div class="w-14 h-14 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl grid place-items-center text-white text-xl mb-6 shadow-md group-hover:scale-110 transition"><i class="fa-solid fa-list-check"></i></div>
<h3 class="text-xl font-extrabold text-slate-900 mb-3">Task Management</h3>
<p class="text-slate-600 text-base leading-relaxed">Advanced categorization system allowing pending, in-progress, and complete sorting effortlessly.</p>
</div>
</div>
</div>

</div>

<?php include "includes/footer.php"; ?>