<?php
session_start();
include "config/db.php";

/* ================= SECURITY ================= */
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$current_user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$name = $_SESSION['name'] ?? 'User';

/* ================= FETCH TASK STATS ================= */
$stmt = $conn->prepare("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN status = 'In Progress' THEN 1 ELSE 0 END) as progress,
    SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) as completed
    FROM tasks WHERE user_id = :user_id");
$stmt->execute([':user_id' => $current_user_id]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC);

/* ================= FETCH RECENT TASKS ================= */
$taskStmt = $conn->prepare("SELECT * FROM tasks WHERE user_id = :user_id ORDER BY task_id DESC LIMIT 5");
$taskStmt->execute([':user_id' => $current_user_id]);
$recentTasks = $taskStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard - FlowTrack</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<style>
/* ================= CUSTOM STYLING MATCHING DASHBOARD ================= */
* { font-family: "Playfair Display", serif !important; font-optical-sizing: auto; font-style: normal; }
body, div, h1, h2, h3, p, a, input, button, table, th, td { font-family: "Playfair Display", serif !important; font-weight: 600 !important; letter-spacing: 0.02em; }
h1, h2, h3 { font-weight: 800 !important; }
input, button, td, th { font-size: 16px !important; }
.fa, .fa-solid, .fa-regular, .fa-brands { font-family: "Font Awesome 6 Free", "Font Awesome 6 Brands" !important; font-weight: 900 !important; }
.glass { background: rgba(255, 255, 255, 0.92); backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px); }
.hide-scrollbar { scrollbar-width: none; -ms-overflow-style: none; }
.hide-scrollbar::-webkit-scrollbar { display: none; }
</style>
</head>
<body class="bg-[#fcfaf7] min-h-screen text-slate-800 relative selection:bg-amber-600 selection:text-white">

<!-- BACKGROUND AMBIENT GLOWS -->
<div class="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[450px] bg-gradient-to-tr from-violet-500/20 via-fuchsia-500/10 to-amber-500/15 rounded-full blur-3xl"></div>
    <div class="absolute inset-0 bg-gradient-to-br from-[#fffcf7] via-[#f1f4fd] to-[#fff1ea] opacity-85"></div>
</div>

<!-- NAVBAR -->
<nav class="bg-white/90 backdrop-blur-md shadow-sm border-b border-indigo-100 sticky top-0 z-50">
<div class="max-w-7xl mx-auto px-6 h-24 flex justify-between items-center">
<a href="dashboard.php" class="flex items-center gap-3 group">
    <div class="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl flex items-center justify-center shadow-lg shadow-amber-600/25 group-hover:scale-105 transition"><i class="fa-solid fa-list-check text-white"></i></div>
    <div><h1 class="text-xl font-extrabold text-slate-900 leading-none">FlowTrack</h1><p class="text-xs text-slate-400 tracking-widest mt-1 font-bold">Workspace Pro</p></div>
</a>
<div class="flex items-center gap-4">
    <a href="profile.php" class="text-base text-slate-700 hover:text-amber-600 font-bold flex items-center gap-2"><i class="fa-solid fa-user-gear text-amber-600"></i> <?= htmlspecialchars($name) ?></a>
    <a href="logout.php" class="px-5 py-2.5 rounded-full bg-rose-600 text-white hover:bg-rose-700 shadow-lg shadow-rose-600/25 text-base flex items-center gap-2 h-11 font-bold transition-all hover:scale-105"><i class="fa-solid fa-house"></i> Home</a>
</div>
</div>
</nav>

<!-- MARQUEE CAROUSEL -->
<div class="relative max-w-7xl mx-auto px-6 mt-6 group">
<div class="relative rounded-[2.5rem] overflow-hidden border border-indigo-100 shadow-2xl bg-white/95 backdrop-blur-2xl p-4 h-48">
<button id="marqueePrev" class="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/95 border border-indigo-100 shadow-xl grid place-items-center hover:bg-gradient-to-r hover:from-indigo-600 hover:to-purple-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-left text-sm"></i></button>
<button id="marqueeNext" class="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/95 border border-indigo-100 shadow-xl grid place-items-center hover:bg-gradient-to-r hover:from-indigo-600 hover:to-purple-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-right text-sm"></i></button>
<div class="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"></div>
<div class="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"></div>
<div id="marqueeWrapper" class="overflow-x-auto hide-scrollbar h-full scroll-smooth">
<div class="flex gap-4 p-1 h-full items-center">
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card shadow-md"><img src="https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base font-bold flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-indigo-500/40 grid place-items-center"><i class="fa-solid fa-shield-dog text-indigo-300"></i></div> Role Management</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card shadow-md"><img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base font-bold flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-purple-500/40 grid place-items-center"><i class="fa-solid fa-users text-purple-300"></i></div> Customer Directory</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card shadow-md"><img src="https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base font-bold flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-emerald-500/40 grid place-items-center"><i class="fa-solid fa-list-check text-emerald-300"></i></div> Task Execution</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card shadow-md"><img src="https://images.unsplash.com/photo-1454165205744-3b78555e5572?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base font-bold flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-amber-500/40 grid place-items-center"><i class="fa-solid fa-network-wired text-amber-300"></i></div> Productivity Hub</div></div>
</div></div>
</div>
</div>
<script>
const wrapper = document.getElementById('marqueeWrapper'); 
let auto = setInterval(() => { 
    wrapper.scrollBy({ left: 1.5, behavior: 'smooth' }); 
    if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) wrapper.scrollTo({ left: 0, behavior: 'smooth' }); 
}, 30);
document.getElementById('marqueePrev').onclick = () => wrapper.scrollBy({ left: -350, behavior: 'smooth' }); 
document.getElementById('marqueeNext').onclick = () => wrapper.scrollBy({ left: 350, behavior: 'smooth' });
wrapper.addEventListener('mouseenter', () => clearInterval(auto)); 
wrapper.addEventListener('mouseleave', () => { 
    auto = setInterval(() => { 
        wrapper.scrollBy({ left: 1.5, behavior: 'smooth' }); 
        if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) wrapper.scrollTo({ left: 0, behavior: 'smooth' }); 
    }, 30); 
});
</script>

<!-- DASHBOARD CONTENT -->
<div class="max-w-7xl mx-auto px-6 mt-10 mb-16">
<div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
    <div>
        <h2 class="text-3xl font-extrabold text-slate-900">Dashboard Control Center</h2>
        <p class="text-base text-slate-600 mt-1">Welcome back, <span class="text-amber-600 font-extrabold"><?= htmlspecialchars($name) ?></span> &bull; Role: <span class="bg-amber-50 text-amber-800 border border-amber-200 px-3 py-0.5 rounded-full text-sm font-extrabold"><?= htmlspecialchars($role) ?></span></p>
    </div>
    
    <!-- QUICK NAVIGATION BUTTONS -->
    <div class="flex flex-wrap items-center gap-3">
        <a href="tasks/manage_tasks.php" class="bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-6 py-3 rounded-full hover:from-emerald-600 hover:to-teal-700 shadow-lg shadow-emerald-600/25 text-base font-extrabold flex items-center gap-2 transition-all hover:scale-105"><i class="fa-solid fa-list-check"></i> Manage Tasks</a>
        
        <?php if ($role === 'Super Admin' || $role === 'Admin'): ?>
            <a href="customer/manage_customer.php" class="bg-gradient-to-r from-indigo-500 to-indigo-700 text-white px-6 py-3 rounded-full hover:from-indigo-600 hover:to-indigo-800 shadow-lg shadow-indigo-600/25 text-base font-extrabold flex items-center gap-2 transition-all hover:scale-105"><i class="fa-solid fa-users"></i> Manage Customers</a>
        <?php endif; ?>

        <?php if ($role === 'Super Admin' || $role === 'Admin'): ?>
            <a href="admin/manage_admin.php" class="bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 text-white px-6 py-3 rounded-full hover:from-amber-600 hover:to-orange-700 shadow-lg shadow-amber-600/25 text-base font-extrabold flex items-center gap-2 transition-all hover:scale-105"><i class="fa-solid fa-shield-halved"></i> Manage Admins</a>
        <?php endif; ?>
    </div>
</div>

<!-- STATS CARDS -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
    <div class="glass p-6 rounded-[2rem] shadow-xl border border-indigo-100 flex items-center gap-4 hover:shadow-2xl hover:border-indigo-300 transition group">
        <div class="w-14 h-14 bg-gradient-to-br from-indigo-500 to-indigo-700 text-white rounded-2xl grid place-items-center text-xl shadow-md group-hover:scale-110 transition"><i class="fa-solid fa-clipboard-list"></i></div>
        <div><p class="text-xs text-slate-400 uppercase tracking-wider font-extrabold">Total Tasks</p><h3 class="text-3xl font-extrabold text-slate-900"><?= $stats['total'] ?? 0 ?></h3></div>
    </div>
    <div class="glass p-6 rounded-[2rem] shadow-xl border border-indigo-100 flex items-center gap-4 hover:shadow-2xl hover:border-amber-300 transition group">
        <div class="w-14 h-14 bg-gradient-to-br from-amber-500 to-orange-600 text-white rounded-2xl grid place-items-center text-xl shadow-md group-hover:scale-110 transition"><i class="fa-solid fa-clock"></i></div>
        <div><p class="text-xs text-slate-400 uppercase tracking-wider font-extrabold">Pending</p><h3 class="text-3xl font-extrabold text-slate-900"><?= $stats['pending'] ?? 0 ?></h3></div>
    </div>
    <div class="glass p-6 rounded-[2rem] shadow-xl border border-indigo-100 flex items-center gap-4 hover:shadow-2xl hover:border-purple-300 transition group">
        <div class="w-14 h-14 bg-gradient-to-br from-violet-500 to-purple-600 text-white rounded-2xl grid place-items-center text-xl shadow-md group-hover:scale-110 transition"><i class="fa-solid fa-spinner"></i></div>
        <div><p class="text-xs text-slate-400 uppercase tracking-wider font-extrabold">In Progress</p><h3 class="text-3xl font-extrabold text-slate-900"><?= $stats['progress'] ?? 0 ?></h3></div>
    </div>
    <div class="glass p-6 rounded-[2rem] shadow-xl border border-indigo-100 flex items-center gap-4 hover:shadow-2xl hover:border-emerald-300 transition group">
        <div class="w-14 h-14 bg-gradient-to-br from-emerald-500 to-teal-600 text-white rounded-2xl grid place-items-center text-xl shadow-md group-hover:scale-110 transition"><i class="fa-solid fa-circle-check"></i></div>
        <div><p class="text-xs text-slate-400 uppercase tracking-wider font-extrabold">Completed</p><h3 class="text-3xl font-extrabold text-slate-900"><?= $stats['completed'] ?? 0 ?></h3></div>
    </div>
</div>

<!-- RECENT TASKS TABLE -->
<div class="glass p-8 rounded-[2.5rem] shadow-xl border border-indigo-100">
<div class="flex justify-between items-center mb-6">
    <h3 class="text-2xl font-extrabold text-slate-900 flex items-center gap-2"><div class="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-600 grid place-items-center text-sm"><i class="fa-solid fa-clock-rotate-left"></i></div> Recent Task Entries</h3>
    <a href="tasks/manage_tasks.php" class="text-amber-600 hover:text-amber-700 text-base font-extrabold transition">View All &rarr;</a>
</div>
<div class="overflow-x-auto rounded-2xl border border-indigo-100">
<table class="w-full border-collapse">
<thead>
    <tr class="bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 text-white text-left text-base"><th class="p-4 font-extrabold">Title</th><th class="p-4 font-extrabold">Description</th><th class="p-4 font-extrabold">Status</th><th class="p-4 font-extrabold">Date Added</th></tr>
</thead>
<tbody class="text-base">
<?php foreach($recentTasks as $t) { 
    $statusColor = 'bg-amber-500';
    if ($t['status'] === 'Completed') $statusColor = 'bg-emerald-600';
    if ($t['status'] === 'In Progress') $statusColor = 'bg-blue-600';
?>
<tr class="border-b border-indigo-50 hover:bg-white/80 transition">
    <td class="p-4 font-extrabold text-slate-900"><?= htmlspecialchars($t['title']) ?></td>
    <td class="p-4 text-slate-600 max-w-xs truncate font-semibold"><?= htmlspecialchars($t['description']) ?></td>
    <td class="p-4"><span class="px-3 py-1 rounded-full text-sm font-extrabold text-white <?= $statusColor ?> shadow-sm"><?= htmlspecialchars($t['status']) ?></span></td>
    <td class="p-4 text-slate-500 font-semibold"><?= htmlspecialchars(date('d-M-Y', strtotime($t['created_at'] ?? 'now'))) ?></td>
</tr>
<?php } if (count($recentTasks) == 0) { echo "<tr><td colspan='4' class='p-8 text-center text-slate-400 text-base font-semibold'><i class='fa-solid fa-inbox text-3xl mb-2 block text-amber-500'></i>No tasks found. Go to task manager to create one.</td></tr>"; } ?>
</tbody></table>
</div>
</div>
</div>

</body>
</html>