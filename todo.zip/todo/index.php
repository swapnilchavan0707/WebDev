<?php
session_start();
include "includes/header.php";
?>
<style>

* { font-family: "Playfair Display", serif !important; font-optical-sizing: auto; font-style: normal; }
body, div, h1, h2, h3, p, a, input, button, table, th, td { font-family: "Playfair Display", serif !important; font-weight: 600 !important; letter-spacing: 0.02em; }
h1, h2, h3 { font-weight: 800 !important; }
input, button, td, th { font-size: 16px !important; }
.fa, .fa-solid, .fa-regular, .fa-brands { font-family: "Font Awesome 6 Free", "Font Awesome 6 Brands" !important; font-weight: 900 !important; }
.glass { background: rgba(255, 255, 255, 0.92); backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px); }
.hide-scrollbar { scrollbar-width: none; -ms-overflow-style: none; }
.hide-scrollbar::-webkit-scrollbar { display: none; }
</style>

<!-- BACKGROUND AMBIENT GLOWS -->
<div class="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[450px] bg-gradient-to-tr from-violet-500/20 via-fuchsia-500/10 to-amber-500/15 rounded-full blur-3xl"></div>
    <div class="absolute inset-0 bg-gradient-to-br from-[#fffcf7] via-[#f1f4fd] to-[#fff1ea] opacity-80"></div>
</div>

<div class="max-w-7xl mx-auto px-6 py-6 text-slate-800">

<!-- UNIQUE MARQUEE CAROUSEL FOR INDEX -->
<div class="relative max-w-7xl mx-auto mb-12">
<div class="relative rounded-[2.5rem] overflow-hidden border border-indigo-100 shadow-2xl bg-white/95 backdrop-blur-2xl p-4">
<div class="relative overflow-hidden w-full h-48">
<button id="marqueePrev" class="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/95 border border-indigo-100 shadow-xl grid place-items-center hover:bg-gradient-to-r hover:from-indigo-600 hover:to-purple-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-left text-sm"></i></button>
<button id="marqueeNext" class="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/95 border border-indigo-100 shadow-xl grid place-items-center hover:bg-gradient-to-r hover:from-indigo-600 hover:to-purple-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-right text-sm"></i></button>
<div class="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"></div>
<div class="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"></div>

<div id="marqueeWrapper" class="flex gap-4 overflow-x-auto hide-scrollbar scroll-smooth py-2 px-1 h-full items-center">
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-indigo-500/40 grid place-items-center"><i class="fa-solid fa-code text-indigo-300"></i></div> Modern Code Architecture</div>
</div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-purple-500/40 grid place-items-center"><i class="fa-solid fa-users text-purple-300"></i></div> Collaborative Teamwork</div>
</div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1531482615713-2afd69097998?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-emerald-500/40 grid place-items-center"><i class="fa-solid fa-chart-line text-emerald-300"></i></div> Strategic Growth</div>
</div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1551836022-d5d88e9218df?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-amber-500/40 grid place-items-center"><i class="fa-solid fa-laptop-code text-amber-300"></i></div> Remote Productivity</div>
</div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 shadow-md group/card">
<img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
<div class="absolute bottom-4 left-4 text-white font-bold text-base flex items-center gap-2"><div class="w-7 h-7 rounded-lg bg-rose-500/40 grid place-items-center"><i class="fa-solid fa-bullseye text-rose-300"></i></div> Goal Achievement</div>
</div>
</div>
</div>
</div>
</div>

<script>
const wrapper = document.getElementById('marqueeWrapper');
const cardWidth = 336; // 320px width + 16px gap
let autoScroll = setInterval(() => {
    wrapper.scrollBy({ left: 1.5, behavior: 'smooth' });
    if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) {
        wrapper.scrollTo({ left: 0, behavior: 'smooth' });
    }
}, 30);

document.getElementById('marqueePrev').onclick = () => wrapper.scrollBy({ left: -cardWidth, behavior: 'smooth' });
document.getElementById('marqueeNext').onclick = () => wrapper.scrollBy({ left: cardWidth, behavior: 'smooth' });

wrapper.addEventListener('mouseenter', () => clearInterval(autoScroll));
wrapper.addEventListener('mouseleave', () => {
    autoScroll = setInterval(() => {
        wrapper.scrollBy({ left: 1.5, behavior: 'smooth' });
        if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) {
            wrapper.scrollTo({ left: 0, behavior: 'smooth' });
        }
    }, 30);
});
</script>

<!-- HERO SECTION -->
<div class="grid md:grid-cols-2 gap-12 items-center py-6">
<div class="space-y-6">
<div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-sm font-bold shadow-sm">
<i class="fa-solid fa-sparkles text-amber-600"></i> Welcome to FlowTrack Pro
</div>
<h1 class="text-4xl md:text-5xl font-extrabold text-slate-900 leading-tight">
Organize Your Day, <br><span class="bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Master Your Workflow.</span>
</h1>
<p class="text-slate-600 text-base leading-relaxed">
FlowTrack helps modern teams and individuals streamline tasks, track real-time progress, and achieve peak productivity with unmatched elegance and simplicity.
</p>
<div class="flex flex-wrap gap-4 pt-4">
<?php if(isset($_SESSION['user_id'])): ?>
<a href="dashboard.php" class="px-8 py-4 bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 text-white rounded-full shadow-lg shadow-amber-600/25 hover:from-amber-600 hover:to-orange-700 font-bold text-base flex items-center gap-2 transition-all hover:scale-105">
<i class="fa-solid fa-gauge-high"></i> Go to Dashboard
</a>
<?php else: ?>
<button onclick="openRegister()" class="px-8 py-4 bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 text-white rounded-full shadow-lg shadow-amber-600/25 hover:from-amber-600 hover:to-orange-700 font-bold text-base flex items-center gap-2 transition-all hover:scale-105">
<i class="fa-solid fa-rocket"></i> Get Started Free
</button>
<button onclick="openLogin()" class="px-8 py-4 bg-white border border-indigo-100 text-slate-800 rounded-full shadow-md hover:bg-slate-50 font-bold text-base flex items-center gap-2 transition-all hover:scale-105">
<i class="fa-solid fa-right-to-bracket text-amber-600"></i> Sign In
</button>
<?php endif; ?>
</div>
</div>

<div class="relative">
<div class="absolute -inset-1.5 bg-gradient-to-r from-amber-500 to-orange-600 rounded-[2.5rem] blur-xl opacity-20"></div>
<div class="relative glass rounded-[2.5rem] p-6 shadow-2xl border border-indigo-100">
<img src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=800&auto=format&fit=crop" alt="Workspace" class="w-full h-80 object-cover rounded-2xl shadow-md">
<div class="mt-6 grid grid-cols-3 gap-4 text-center">
<div class="bg-white/80 p-3 rounded-2xl shadow-sm border border-indigo-50">
<h3 class="text-2xl font-extrabold text-amber-600">100%</h3>
<p class="text-xs text-slate-500 mt-1 font-bold">Productivity</p>
</div>
<div class="bg-white/80 p-3 rounded-2xl shadow-sm border border-indigo-50">
<h3 class="text-2xl font-extrabold text-indigo-600">24/7</h3>
<p class="text-xs text-slate-500 mt-1 font-bold">Access</p>
</div>
<div class="bg-white/80 p-3 rounded-2xl shadow-sm border border-indigo-50">
<h3 class="text-2xl font-extrabold text-emerald-600">Secure</h3>
<p class="text-xs text-slate-500 mt-1 font-bold">Workspace</p>
</div>
</div>
</div>
</div>
</div>

<!-- FEATURES GRID -->
<div class="mt-20 mb-10">
<div class="text-center max-w-2xl mx-auto mb-12">
<h2 class="text-3xl font-extrabold text-slate-900">Designed for Peak Performance</h2>
<p class="text-slate-600 text-base mt-2">Everything you need to keep your daily projects organized and under control.</p>
</div>
<div class="grid md:grid-cols-3 gap-8">
<div class="glass p-8 rounded-[2rem] shadow-xl border border-indigo-100 hover:shadow-2xl hover:border-amber-300 transition group">
<div class="w-14 h-14 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl grid place-items-center text-white text-xl mb-6 shadow-md group-hover:scale-110 transition"><i class="fa-solid fa-bolt"></i></div>
<h3 class="text-xl font-extrabold text-slate-900 mb-3">Lightning Fast Tasks</h3>
<p class="text-slate-600 text-base leading-relaxed">Add, modify, or strike through tasks instantly with our ultra-responsive task manager interface.</p>
</div>
<div class="glass p-8 rounded-[2rem] shadow-xl border border-indigo-100 hover:shadow-2xl hover:border-indigo-300 transition group">
<div class="w-14 h-14 bg-gradient-to-br from-indigo-500 to-indigo-700 rounded-2xl grid place-items-center text-white text-xl mb-6 shadow-md group-hover:scale-110 transition"><i class="fa-solid fa-shield-halved"></i></div>
<h3 class="text-xl font-extrabold text-slate-900 mb-3">Secure Encryption</h3>
<p class="text-slate-600 text-base leading-relaxed">Your personal schedules and company workflows are protected using robust security protocols.</p>
</div>
<div class="glass p-8 rounded-[2rem] shadow-xl border border-indigo-100 hover:shadow-2xl hover:border-emerald-300 transition group">
<div class="w-14 h-14 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl grid place-items-center text-white text-xl mb-6 shadow-md group-hover:scale-110 transition"><i class="fa-solid fa-chart-pie"></i></div>
<h3 class="text-xl font-extrabold text-slate-900 mb-3">Live Status Trackers</h3>
<p class="text-slate-600 text-base leading-relaxed">Monitor pending, active, and completed deliverables instantly from your control hub.</p>
</div>
</div>
</div>

</div>

<?php include "includes/footer.php"; ?>