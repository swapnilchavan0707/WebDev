<?php
include "../config/db.php";
session_start();
header('Content-Type: text/plain');

$email = trim(strtolower($_POST['email'] ?? ''));
$password = $_POST['password'] ?? '';

if (empty($email) || empty($password)) {
    echo "error";
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "error";
    exit;
}

try {
    // Fetch with role for dashboard routing
    $stmt = $conn->prepare("SELECT user_id, first_name, email, password, role FROM users WHERE email = :email LIMIT 1");
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['name'] = $user['first_name'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['email'] = $user['email'];
        echo "success";
    } else {
        echo "error";
    }
} catch (PDOException $e) {
    error_log("Login Error: " . $e->getMessage());
    echo "error";
}
?>