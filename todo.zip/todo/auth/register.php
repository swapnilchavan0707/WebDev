<?php
include "../config/db.php";
header('Content-Type: text/plain');

// Capture separate fields if present, or handle a combined 'name' / 'full_name' field from modal inputs
$firstName = trim($_POST['first'] ?? '');
$lastName  = trim($_POST['last'] ?? '');
$fullName  = trim($_POST['name'] ?? $_POST['full_name'] ?? '');

if (empty($firstName) && !empty($fullName)) {
    $nameParts = explode(' ', $fullName, 2);
    $firstName = $nameParts[0];
    $lastName  = $nameParts[1] ?? 'User'; // Fallback last name if only one name word is entered
}

// Fallback mobile number if not submitted by a simplified frontend form, satisfying database requirement
$mobile  = trim($_POST['mobile'] ?? '9876543210');
$email   = trim(strtolower($_POST['email'] ?? ''));
$passRaw = $_POST['password'] ?? '';
$role    = "Customer";

if (empty($firstName) || empty($email) || empty($passRaw)) {
    echo "error";
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "error";
    exit;
}

if (strlen($passRaw) < 6) {
    echo "error";
    exit;
}

$password = password_hash($passRaw, PASSWORD_DEFAULT);

try {
    $check = $conn->prepare("SELECT user_id FROM users WHERE email = :email LIMIT 1");
    $check->execute([':email' => $email]);

    if ($check->fetch()) {
        echo "exists";
        exit;
    }

    $sql = "INSERT INTO users (first_name, last_name, mobile_number, email, password, role) 
            VALUES (:first, :last, :mobile, :email, :password, :role)";

    $stmt = $conn->prepare($sql);
    $result = $stmt->execute([
        ':first'    => $firstName,
        ':last'     => $lastName,
        ':mobile'   => $mobile,
        ':email'    => $email,
        ':password' => $password,
        ':role'     => $role
    ]);

    echo $result ? "success" : "error";

} catch (PDOException $e) {
    error_log("Register Error: " . $e->getMessage());
    echo "error";
}
?>