<?php
session_start();
include "../config/db.php";

/* ================= SECURITY ================= */
if (!isset($_SESSION['user_id'])) {
    header("Location:../index.php");
    exit;
}
// Only Super Admin and Admins can manage customers
if (!in_array($_SESSION['role'], ["Super Admin", "Admin"])) {
    die("<link href='https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap' rel='stylesheet'><div style='text-align:center;margin-top:100px;font-family:\"Playfair Display\",serif;'><h2 style='color:#ef4444;font-size:32px;font-weight:800;'>Access Denied</h2><p style='font-size:20px;font-weight:600;color:#475569;'>You do not have permission to manage customers.</p><a href='../dashboard.php' style='background:#0f172a;color:#fff;padding:12px 24px;border-radius:999px;text-decoration:none;font-size:18px;display:inline-block;margin-top:16px;'>Back to Dashboard</a></div>");
}

$success = "";
$error = "";

/* ================= ADD CUSTOMER ================= */
if (isset($_POST['add_customer'])) {
    $first = trim($_POST['first_name']);
    $last = trim($_POST['last_name']);
    $mobile = trim($_POST['mobile_number']);
    $email = trim(strtolower($_POST['email']));
    $password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);
    $role = "Customer";

    if ($first && $last && $mobile && $email && $_POST['password']) {
        $check = $conn->prepare("SELECT user_id FROM users WHERE email = :email");
        $check->execute([':email' => $email]);
        if ($check->fetch()) {
            $error = "Email address is already registered!";
        } else {
            $sql = "INSERT INTO users (first_name, last_name, mobile_number, email, password, role) VALUES (:first, :last, :mobile, :email, :password, :role)";
            $stmt = $conn->prepare($sql);
            $stmt->execute([
                ':first' => $first,
                ':last' => $last,
                ':mobile' => $mobile,
                ':email' => $email,
                ':password' => $password,
                ':role' => $role
            ]);
            header("Location: manage_customer.php?msg=added");
            exit;
        }
    } else {
        $error = "Please fill in all required fields.";
    }
}

/* ================= DELETE CUSTOMER ================= */
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    
    // Ensure we only delete users with the 'Customer' role
    $del = $conn->prepare("DELETE FROM users WHERE user_id = :id AND role = 'Customer'");
    $del->execute([':id' => $id]);
    header("Location: manage_customer.php?msg=deleted");
    exit;
}

/* ================= UPDATE CUSTOMER ================= */
if (isset($_POST['update_customer'])) {
    $id = (int)$_POST['user_id'];
    $first = trim($_POST['first_name']);
    $last = trim($_POST['last_name']);
    $mobile = trim($_POST['mobile_number']);
    $email = trim(strtolower($_POST['email']));

    // Check email uniqueness for other users
    $check = $conn->prepare("SELECT user_id FROM users WHERE email = :email AND user_id != :id");
    $check->execute([':email' => $email, ':id' => $id]);
    if ($check->fetch()) {
        $error = "Email is already taken by another user!";
    } else {
        if (!empty($_POST['password'])) {
            $password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);
            $sql = "UPDATE users SET first_name=:first, last_name=:last, mobile_number=:mobile, email=:email, password=:password WHERE user_id=:id AND role='Customer'";
            $params = [':first' => $first, ':last' => $last, ':mobile' => $mobile, ':email' => $email, ':password' => $password, ':id' => $id];
        } else {
            $sql = "UPDATE users SET first_name=:first, last_name=:last, mobile_number=:mobile, email=:email WHERE user_id=:id AND role='Customer'";
            $params = [':first' => $first, ':last' => $last, ':mobile' => $mobile, ':email' => $email, ':id' => $id];
        }
        $stmt = $conn->prepare($sql);
        $stmt->execute($params);
        header("Location: manage_customer.php?msg=updated");
        exit;
    }
}

if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'added') $success = "Customer added successfully!";
    if ($_GET['msg'] == 'deleted') $success = "Customer deleted successfully!";
    if ($_GET['msg'] == 'updated') $success = "Customer updated successfully!";
}

/* ================= FETCH CUSTOMERS ================= */
$stmt = $conn->prepare("SELECT * FROM users WHERE role = 'Customer' ORDER BY user_id ASC");
$stmt->execute();
$customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Customers - WorkWave Pro</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<style>
* { font-family: "Playfair Display", serif !important; font-optical-sizing: auto; font-style: normal; }
body, div, h1, h2, h3, p, a, input, button, table, th, td, label { font-family: "Playfair Display", serif !important; font-weight: 600 !important; letter-spacing: 0.02em; }
h1, h2 { font-weight: 800 !important; }
input, button, td, th { font-size: 16px !important; }
.fa, .fa-solid, .fa-regular, .fa-brands { font-family: "Font Awesome 6 Free", "Font Awesome 6 Brands" !important; font-weight: 900 !important; }
.glass { background: rgba(255, 255, 255, 0.85); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); }
.hide-scrollbar { scrollbar-width: none; -ms-overflow-style: none; }
.hide-scrollbar::-webkit-scrollbar { display: none; }
</style>
</head>
<body class="bg-[#fdfbf7] min-h-screen relative text-slate-800">
<div class="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-gradient-to-tr from-blue-400/15 via-indigo-400/10 to-amber-400/5 rounded-full blur-3xl"></div>
    <div class="absolute inset-0 bg-gradient-to-br from-[#fffaf0] via-[#f4f7ff] to-[#fff3ed] opacity-60"></div>
</div>

<!-- NAVBAR -->
<nav class="bg-white/90 backdrop-blur-2xl shadow-sm border-b border-slate-200/60 sticky top-0 z-50">
<div class="max-w-7xl mx-auto px-6 h-24 flex justify-between items-center">
<a href="../dashboard.php" class="flex items-center gap-3 group">
    <div class="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-105 transition-all duration-300"><i class="fa-solid fa-users text-white text-lg"></i></div>
    <div><h1 class="text-xl font-extrabold text-slate-900 leading-none">WorkWave</h1><p class="text-xs text-slate-400 tracking-widest mt-1">Pixel & Pulp</p></div>
</a>
<div class="flex items-center gap-3">
    <span class="hidden md:flex items-center gap-2 text-base text-slate-700 bg-blue-50/60 border border-blue-200/60 px-5 py-2.5 rounded-full shadow-sm font-bold">
        <i class="fa-solid fa-user text-blue-600"></i> <?= htmlspecialchars($_SESSION['role']) ?>
    </span>
    <a href="../dashboard.php" class="px-6 py-3 rounded-full bg-slate-900 text-white hover:bg-slate-800 shadow-lg text-sm flex items-center gap-2 h-12 transition-all"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
</div>
</div>
</nav>

<!-- MARQUEE CAROUSEL -->
<div class="relative max-w-7xl mx-auto px-6 mt-8 group">
<div class="relative rounded-[2.5rem] overflow-hidden border border-slate-200/85 shadow-xl bg-white h-48">
<button id="marqueePrev" class="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/90 border border-slate-200 shadow-xl grid place-items-center hover:bg-blue-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-left text-sm"></i></button>
<button id="marqueeNext" class="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/90 border border-slate-200 shadow-xl grid place-items-center hover:bg-blue-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-right text-sm"></i></button>
<div class="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"></div>
<div class="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"></div>
<div id="marqueeWrapper" class="overflow-x-auto hide-scrollbar h-full scroll-smooth">
<div class="flex gap-4 p-3 h-full">
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card"><img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/70 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base"><i class="fa-solid fa-user-group mr-2 text-blue-400"></i> Manage Customers</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card"><img src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/70 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base"><i class="fa-solid fa-handshake mr-2 text-blue-400"></i> Client Relations</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card"><img src="https://images.unsplash.com/photo-1531482615713-2afd69097998?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/70 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base"><i class="fa-solid fa-address-book mr-2 text-blue-400"></i> Directory Control</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card"><img src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/70 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base"><i class="fa-solid fa-bullseye mr-2 text-blue-400"></i> Support Hub</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card"><img src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/70 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base"><i class="fa-solid fa-chart-pie mr-2 text-blue-400"></i> User Analytics</div></div>
</div></div>
</div>
</div>
<script>
const wrapper = document.getElementById('marqueeWrapper'); 
let auto = setInterval(() => { 
    wrapper.scrollBy({ left: 2 }); 
    if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) wrapper.scrollTo({ left: 0, behavior: 'smooth' }); 
}, 30);
document.getElementById('marqueePrev').onclick = () => wrapper.scrollBy({ left: -350, behavior: 'smooth' }); 
document.getElementById('marqueeNext').onclick = () => wrapper.scrollBy({ left: 350, behavior: 'smooth' });
wrapper.addEventListener('mouseenter', () => clearInterval(auto)); 
wrapper.addEventListener('mouseleave', () => { 
    auto = setInterval(() => { 
        wrapper.scrollBy({ left: 2 }); 
        if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) wrapper.scrollTo({ left: 0, behavior: 'smooth' }); 
    }, 30); 
});
</script>

<!-- ADD CUSTOMER -->
<div class="max-w-6xl mx-auto mt-10 glass p-8 rounded-[2.5rem] shadow-xl border border-slate-200/80">
<?php if($success): ?><div class="bg-emerald-50 border border-emerald-200 text-emerald-700 p-4 rounded-2xl mb-6 flex items-center gap-2 text-base"><i class="fa-solid fa-circle-check"></i> <?= $success ?></div><?php endif; ?>
<?php if($error): ?><div class="bg-rose-50 border border-rose-200 text-rose-700 p-4 rounded-2xl mb-6 flex items-center gap-2 text-base"><i class="fa-solid fa-circle-exclamation"></i> <?= $error ?></div><?php endif; ?>
<h2 class="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
    <span class="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 grid place-items-center"><i class="fa-solid fa-user-plus text-base"></i></span> Add New Customer
</h2>
<form method="POST" class="grid md:grid-cols-3 gap-4">
<input name="first_name" placeholder="First Name" class="border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-blue-600 outline-none text-base transition" required>
<input name="last_name" placeholder="Last Name" class="border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-blue-600 outline-none text-base transition" required>
<input name="mobile_number" placeholder="Mobile Number" class="border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-blue-600 outline-none text-base transition" required>
<input name="email" type="email" placeholder="Email Address" class="border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-blue-600 outline-none md:col-span-2 text-base transition" required>
<input name="password" type="password" placeholder="Password" class="border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-blue-600 outline-none text-base transition" required>
<button name="add_customer" class="bg-blue-600 text-white py-3.5 rounded-full hover:bg-blue-700 md:col-span-3 shadow-lg text-base flex items-center justify-center gap-2 font-bold transition-all"><i class="fa-solid fa-plus"></i> Add Customer</button>
</form>
</div>

<!-- CUSTOMER LIST TABLE -->
<div class="max-w-6xl mx-auto mt-10 mb-12 glass p-8 rounded-[2.5rem] shadow-xl border border-slate-200/80">
<h2 class="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
    <span class="w-10 h-10 rounded-xl bg-amber-100 text-amber-600 grid place-items-center"><i class="fa-solid fa-users text-base"></i></span> Customer Directory (Total: <?= count($customers) ?>)
</h2>
<div class="overflow-x-auto rounded-2xl border border-slate-200/60 bg-white/50">
<table class="w-full border-collapse">
<thead>
    <tr class="bg-blue-600 text-white text-left text-base"><th class="p-4">Sr No</th><th class="p-4">Name</th><th class="p-4">Email</th><th class="p-4">Mobile</th><th class="p-4">Role</th><th class="p-4">Action</th></tr>
</thead>
<tbody class="text-base">
<?php $i = 1; foreach($customers as $c) { ?>
<tr class="border-b border-slate-100 hover:bg-white/80 transition">
    <td class="p-4 text-slate-500"><?= $i++ ?></td>
    <td class="p-4 font-bold text-slate-900"><?= htmlspecialchars($c['first_name']." ".$c['last_name']) ?></td>
    <td class="p-4 text-slate-600"><?= htmlspecialchars($c['email']) ?></td>
    <td class="p-4 text-slate-600"><?= htmlspecialchars($c['mobile_number']) ?></td>
    <td class="p-4"><span class="px-3 py-1 rounded-full text-xs font-bold bg-blue-500 text-white shadow-sm"><?= htmlspecialchars($c['role']) ?></span></td>
    <td class="p-4 flex gap-2">
        <button onclick="openEdit('<?= $c['user_id'] ?>','<?= htmlspecialchars($c['first_name']) ?>','<?= htmlspecialchars($c['last_name']) ?>','<?= htmlspecialchars($c['mobile_number']) ?>','<?= htmlspecialchars($c['email']) ?>')" class="bg-amber-500 text-white px-4 py-2 rounded-full hover:bg-amber-600 text-sm flex items-center gap-1 shadow-sm transition"><i class="fa-solid fa-pen"></i> Edit</button>
        <a href="?delete=<?= $c['user_id'] ?>" onclick="return confirm('Are you sure you want to delete this customer?')" class="bg-rose-500 text-white px-4 py-2 rounded-full hover:bg-rose-600 text-sm flex items-center gap-1 shadow-sm transition"><i class="fa-solid fa-trash"></i> Delete</a>
    </td>
</tr>
<?php } if (count($customers) == 0) { echo "<tr><td colspan='6' class='p-8 text-center text-slate-400 text-base'><i class='fa-solid fa-inbox text-2xl mb-2 block'></i>No customers found.</td></tr>"; } ?>
</tbody></table>
</div>
</div>

<!-- EDIT MODAL -->
<div id="editModal" class="hidden fixed inset-0 bg-slate-950/50 backdrop-blur-md flex items-center justify-center z-50 p-4">
<div class="glass bg-white/95 w-full max-w-sm p-8 rounded-[2.5rem] shadow-2xl border border-slate-200/80 relative animate-in">
<h2 class="text-2xl font-bold mb-5 flex items-center gap-2 text-slate-900"><i class="fa-solid fa-pen-to-square text-blue-600"></i> Edit Customer</h2>
<form method="POST" class="space-y-3">
<input type="hidden" name="user_id" id="e_id">
<input name="first_name" id="e_first" class="w-full border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-blue-600 outline-none text-base transition" placeholder="First Name" required>
<input name="last_name" id="e_last" class="w-full border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-blue-600 outline-none text-base transition" placeholder="Last Name" required>
<input name="mobile_number" id="e_mobile" class="w-full border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-blue-600 outline-none text-base transition" placeholder="Mobile Number" required>
<input name="email" id="e_email" type="email" class="w-full border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-blue-600 outline-none text-base transition" placeholder="Email Address" required>
<input name="password" type="password" class="w-full border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-blue-600 outline-none text-base transition" placeholder="New Password (optional)">
<button name="update_customer" class="bg-blue-600 text-white w-full py-3.5 rounded-full hover:bg-blue-700 shadow-lg flex items-center justify-center gap-2 text-base font-bold transition-all"><i class="fa-solid fa-check"></i> Update Customer</button>
</form>
<button onclick="closeEdit()" class="mt-4 w-full text-slate-500 text-base hover:text-slate-800 transition"><i class="fa-solid fa-xmark mr-1"></i> Close</button>
</div>
</div>

<script>
function openEdit(id, f, l, m, e) {
    document.getElementById("editModal").classList.remove("hidden");
    document.getElementById("e_id").value = id;
    document.getElementById("e_first").value = f;
    document.getElementById("e_last").value = l;
    document.getElementById("e_mobile").value = m;
    document.getElementById("e_email").value = e;
}
function closeEdit() {
    document.getElementById("editModal").classList.add("hidden");
}
</script>
</body>
</html>