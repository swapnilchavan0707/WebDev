<?php
session_start();
include "includes/header.php";
?>

<!-- GOOGLE FONT: PLAYFAIR DISPLAY INJECTION -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">

<style>
.font-playfair {
    font-family: "Playfair Display", serif;
    font-optical-sizing: auto;
}
</style>

<!-- AMBIENT BACKGROUND GLOW EFFECTS -->
<div class="absolute top-10 left-1/2 -translate-x-1/2 w-[650px] h-[350px] bg-gradient-to-tr from-blue-400/20 via-indigo-400/15 to-purple-400/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>

<!-- UNIQUE MARQUEE CAROUSEL FOR ABOUT -->
<div class="relative max-w-7xl mx-auto mb-16 pt-6">
<div class="relative rounded-[2.5rem] overflow-hidden border border-slate-200/60 shadow-2xl bg-white/80 backdrop-blur-2xl p-6">
<div class="flex items-center justify-between mb-5 px-3">
<div class="flex items-center gap-2.5 text-xs font-bold uppercase tracking-wider text-blue-600">
<span class="w-2.5 h-2.5 rounded-full bg-blue-600 animate-ping"></span> Pixel & Pulp Showcase
</div>
<span class="text-xs text-slate-400 font-medium tracking-wide">WorkWave Culture & Vision</span>
</div>

<div class="relative overflow-hidden w-full">
<button id="marqueePrev" class="absolute left-3 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-2xl bg-white/95 border border-slate-200/80 shadow-2xl grid place-items-center text-slate-700 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all duration-300"><i class="fa-solid fa-chevron-left text-sm"></i></button>
<button id="marqueeNext" class="absolute right-3 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-2xl bg-white/95 border border-slate-200/80 shadow-2xl grid place-items-center text-slate-700 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all duration-300"><i class="fa-solid fa-chevron-right text-sm"></i></button>

<div id="marqueeWrapper" class="flex gap-6 overflow-x-auto hide-scrollbar scroll-smooth py-3 px-2">
<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1515187029135-18ee286d815b?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-blue-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-handshake"></i></div> Corporate Culture
</div>
</div>

<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-indigo-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-brain"></i></div> Creative Brainstorming
</div>
</div>

<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-emerald-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-people-group"></i></div> Dedicated Team
</div>
</div>

<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-violet-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-building"></i></div> Modern Workspace
</div>
</div>

<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1542744094-3a31243364d0?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-amber-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-trophy"></i></div> Mission & Vision
</div>
</div>
</div>
</div>
</div>
</div>

<script>
const wrapper = document.getElementById('marqueeWrapper');
const cardWidth = 384; // matched updated card width + gap offset
let autoScroll = setInterval(() => {
    wrapper.scrollBy({ left: 1.5, behavior: 'smooth' });
    if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) {
        wrapper.scrollTo({ left: 0, behavior: 'smooth' });
    }
}, 30);

document.getElementById('marqueePrev').onclick = () => wrapper.scrollBy({ left: -cardWidth, behavior: 'smooth' });
document.getElementById('marqueeNext').onclick = () => wrapper.scrollBy({ left: cardWidth, behavior: 'smooth' });

wrapper.addEventListener('mouseenter', () => clearInterval(autoScroll));
wrapper.addEventListener('mouseleave', () => {
    autoScroll = setInterval(() => {
        wrapper.scrollBy({ left: 1.5, behavior: 'smooth' });
        if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) {
            wrapper.scrollTo({ left: 0, behavior: 'smooth' });
        }
    }, 30);
});
</script>

<div class="py-6 max-w-7xl mx-auto">
<div class="text-center max-w-3xl mx-auto mb-16">
<span class="px-5 py-2 rounded-full bg-blue-50 border border-blue-200/60 text-blue-700 text-xs font-bold uppercase tracking-widest shadow-sm inline-block mb-4">Our Story & Mission</span>
<h1 class="text-4xl md:text-5xl font-black text-slate-900 tracking-tight font-playfair">Empowering Productivity Worldwide</h1>
<p class="text-slate-600 text-lg mt-4 leading-relaxed font-normal">
Built by <span class="text-slate-900 font-bold">Pixel & Pulp</span>, WorkWave was engineered out of a passion for clean design, robust organization, and absolute efficiency.
</p>
</div>

<div class="grid md:grid-cols-2 gap-12 items-center mb-20">
<div class="relative rounded-[2.5rem] p-8 shadow-2xl border border-white/90 bg-white/90 backdrop-blur-2xl space-y-6">
<div class="absolute -top-3 -left-3 w-20 h-20 bg-blue-500/10 rounded-full blur-xl pointer-events-none"></div>
<h2 class="text-3xl font-bold text-slate-900 font-playfair">Who We Are</h2>
<p class="text-slate-600 text-base leading-relaxed">
We are a collective group of creators, engineers, and visionaries dedicated to building software that simplifies life. Whether you are managing personal chores or corporate pipelines, WorkWave adapts seamlessly to your tempo.
</p>
<div class="grid grid-cols-2 gap-4 pt-2">
<div class="flex items-center gap-3.5 p-3 rounded-2xl bg-slate-50 border border-slate-100 shadow-inner">
<div class="w-10 h-10 rounded-xl bg-blue-600 text-white grid place-items-center shadow-md"><i class="fa-solid fa-check"></i></div>
<span class="font-bold text-slate-800 text-sm">User Centric</span>
</div>
<div class="flex items-center gap-3.5 p-3 rounded-2xl bg-slate-50 border border-slate-100 shadow-inner">
<div class="w-10 h-10 rounded-xl bg-emerald-600 text-white grid place-items-center shadow-md"><i class="fa-solid fa-check"></i></div>
<span class="font-bold text-slate-800 text-sm">Modern Tech</span>
</div>
</div>
</div>

<div class="relative">
<div class="absolute -inset-3 bg-gradient-to-r from-blue-600/30 to-indigo-600/30 rounded-[2.5rem] blur-2xl opacity-40"></div>
<div class="relative rounded-[2.5rem] p-4 shadow-2xl border border-white/90 bg-white/90 backdrop-blur-2xl">
<img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=1000" class="w-full h-96 object-cover rounded-3xl shadow-lg border border-slate-100 bg-slate-900" alt="Team">
</div>
</div>
</div>
</div>

<?php include "includes/footer.php"; ?>