<?php
session_start();
include "../config/db.php";

/* ================= SECURITY ================= */
if (!isset($_SESSION['user_id'])) {
    header("Location:../index.php");
    exit;
}
if (!in_array($_SESSION['role'], ["Super Admin", "Admin"])) {
    die("<link href='https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap' rel='stylesheet'><div style='text-align:center;margin-top:100px;font-family:\"Playfair Display\",serif;'><h2 style='color:#ef4444;font-size:32px;font-weight:800;'>Access Denied</h2><p style='font-size:20px;font-weight:600;color:#475569;'>Only Admin & Super Admin allowed.</p><a href='../dashboard.php' style='background:#0f172a;color:#fff;padding:12px 24px;border-radius:999px;text-decoration:none;font-size:18px;display:inline-block;margin-top:16px;'>Back</a></div>");
}

$success = ""; 
$error = "";

/* ================= ADD ADMIN ================= */
if (isset($_POST['add_admin'])) {
    $first = trim($_POST['first']); 
    $last = trim($_POST['last']); 
    $mobile = trim($_POST['mobile']); 
    $email = trim(strtolower($_POST['email'])); 
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); 
    $role = "Admin"; // New accounts created here are standard Admins

    if ($first && $last && $mobile && $email && $_POST['password']) {
        $check = $conn->prepare("SELECT user_id FROM users WHERE email = :email"); 
        $check->execute([':email' => $email]);
        if ($check->fetch()) {
            $error = "Email already exists!";
        } else {
            $sql = "INSERT INTO users (first_name, last_name, mobile_number, email, password, role) VALUES (:first, :last, :mobile, :email, :password, :role)";
            $stmt = $conn->prepare($sql); 
            $stmt->execute([':first' => $first, ':last' => $last, ':mobile' => $mobile, ':email' => $email, ':password' => $password, ':role' => $role]);
            header("Location: manage_admin.php?msg=added");
            exit;
        }
    } else {
        $error = "Please fill all fields!";
    }
}

/* ================= DELETE ADMIN ================= */
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete']; 

    // Prevent deleting Super Admin (ID 1)
    if ($id === 1) {
        header("Location: manage_admin.php?msg=protected");
        exit;
    }

    // Check if target is a Super Admin
    $targetCheck = $conn->prepare("SELECT role FROM users WHERE user_id = :id");
    $targetCheck->execute([':id' => $id]);
    $targetUser = $targetCheck->fetch();

    if ($targetUser && $targetUser['role'] === 'Super Admin') {
        header("Location: manage_admin.php?msg=protected");
        exit;
    }

    $del = $conn->prepare("DELETE FROM users WHERE user_id = :id AND role='Admin'"); 
    $del->execute([':id' => $id]);
    header("Location: manage_admin.php?msg=deleted"); 
    exit;
}

/* ================= UPDATE ADMIN ================= */
if (isset($_POST['update_admin'])) {
    $id = (int)$_POST['user_id']; 
    $first = trim($_POST['first']); 
    $last = trim($_POST['last']); 
    $mobile = trim($_POST['mobile']); 
    $email = trim(strtolower($_POST['email']));

    // Prevent regular admins from editing Super Admin (ID 1)
    if ($id === 1 && $_SESSION['user_id'] != 1) {
        header("Location: manage_admin.php?msg=protected");
        exit;
    }

    $targetCheck = $conn->prepare("SELECT role FROM users WHERE user_id = :id");
    $targetCheck->execute([':id' => $id]);
    $targetUser = $targetCheck->fetch();

    if ($targetUser && $targetUser['role'] === 'Super Admin' && $_SESSION['user_id'] != 1) {
        header("Location: manage_admin.php?msg=protected");
        exit;
    }
    
    if (!empty($_POST['password'])) {
        $password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);
        $sql = "UPDATE users SET first_name=:first, last_name=:last, mobile_number=:mobile, email=:email, password=:password WHERE user_id=:id";
        $params = [':first' => $first, ':last' => $last, ':mobile' => $mobile, ':email' => $email, ':password' => $password, ':id' => $id];
    } else {
        $sql = "UPDATE users SET first_name=:first, last_name=:last, mobile_number=:mobile, email=:email WHERE user_id=:id";
        $params = [':first' => $first, ':last' => $last, ':mobile' => $mobile, ':email' => $email, ':id' => $id];
    }
    $stmt = $conn->prepare($sql); 
    $stmt->execute($params);
    header("Location: manage_admin.php?msg=updated"); 
    exit;
}

if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'added') $success = "Admin added successfully!";
    if ($_GET['msg'] == 'deleted') $success = "Admin deleted successfully!";
    if ($_GET['msg'] == 'updated') $success = "Admin updated successfully!";
    if ($_GET['msg'] == 'protected') $error = "Security Alert: Super Admin account cannot be modified or deleted by standard admins!";
}

$stmt = $conn->prepare("SELECT * FROM users WHERE role IN ('Super Admin', 'Admin') ORDER BY user_id ASC"); 
$stmt->execute(); 
$admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Administrators - WorkWave Pro</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<style>
* { font-family: "Playfair Display", serif !important; font-optical-sizing: auto; font-style: normal; }
body, div, h1, h2, h3, p, a, input, button, table, th, td, textarea, select { font-family: "Playfair Display", serif !important; font-weight: 600 !important; letter-spacing: 0.02em; }
h1, h2 { font-weight: 800 !important; }
input, button, td, th { font-size: 16px !important; }
.fa, .fa-solid, .fa-regular, .fa-brands { font-family: "Font Awesome 6 Free", "Font Awesome 6 Brands" !important; font-weight: 900 !important; }
.glass { background: rgba(255, 255, 255, 0.85); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); }
.hide-scrollbar { scrollbar-width: none; -ms-overflow-style: none; }
.hide-scrollbar::-webkit-scrollbar { display: none; }
</style>
</head>
<body class="bg-[#fdfbf7] min-h-screen relative text-slate-800">
<div class="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-gradient-to-tr from-indigo-400/10 via-purple-400/10 to-blue-400/5 rounded-full blur-3xl"></div>
    <div class="absolute inset-0 bg-gradient-to-br from-[#fffaf0] via-[#f4f7ff] to-[#fff3ed] opacity-60"></div>
</div>

<!-- NAVBAR -->
<nav class="bg-white/90 backdrop-blur-2xl shadow-sm border-b border-slate-200/60 sticky top-0 z-50">
<div class="max-w-7xl mx-auto px-6 h-24 flex justify-between items-center">
<a href="../dashboard.php" class="flex items-center gap-3 group">
    <div class="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-105 transition-all duration-300"><i class="fa-solid fa-shield-halved text-white text-lg"></i></div>
    <div><h1 class="text-xl font-extrabold text-slate-900 leading-none">WorkWave</h1><p class="text-xs text-slate-400 tracking-widest mt-1">Pixel & Pulp</p></div>
</a>
<div class="flex items-center gap-3">
    <span class="hidden md:flex items-center gap-2 text-base text-slate-700 bg-blue-50/60 border border-blue-200/60 px-5 py-2.5 rounded-full shadow-sm font-bold">
        <i class="fa-solid fa-user-tie text-indigo-600"></i> <?= htmlspecialchars($_SESSION['role']) ?>
    </span>
    <a href="../dashboard.php" class="px-6 py-3 rounded-full bg-slate-900 text-white hover:bg-slate-800 shadow-lg text-sm flex items-center gap-2 h-12 transition-all"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
</div>
</div>
</nav>

<!-- MARQUEE CAROUSEL -->
<div class="relative max-w-7xl mx-auto px-6 mt-8 group">
<div class="relative rounded-[2.5rem] overflow-hidden border border-slate-200/80 shadow-xl bg-white h-48">
<button id="marqueePrev" class="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/90 border border-slate-200 shadow-xl grid place-items-center hover:bg-indigo-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-left text-sm"></i></button>
<button id="marqueeNext" class="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/90 border border-slate-200 shadow-xl grid place-items-center hover:bg-indigo-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-right text-sm"></i></button>
<div class="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"></div>
<div class="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"></div>
<div id="marqueeWrapper" class="overflow-x-auto hide-scrollbar h-full scroll-smooth">
<div class="flex gap-4 p-3 h-full">
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card"><img src="https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/70 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base"><i class="fa-solid fa-shield-dog mr-2 text-indigo-400"></i> Admin Security</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card"><img src="https://images.unsplash.com/photo-1454165205744-3b78555e5572?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/70 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base"><i class="fa-solid fa-network-wired mr-2 text-indigo-400"></i> Role Hierarchy</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card"><img src="https://images.unsplash.com/photo-1521791136064-7986c2920216?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/70 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base"><i class="fa-solid fa-user-shield mr-2 text-indigo-400"></i> Control Center</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card"><img src="https://images.unsplash.com/photo-1553877522-43269d4ea984?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/70 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base"><i class="fa-solid fa-lock mr-2 text-indigo-400"></i> Access Management</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card"><img src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-950/70 to-transparent"></div><div class="absolute bottom-4 left-4 text-white text-base"><i class="fa-solid fa-users-gear mr-2 text-indigo-400"></i> System Administration</div></div>
</div></div>
</div>
</div>
<script>
const wrapper = document.getElementById('marqueeWrapper'); 
let auto = setInterval(() => { 
    wrapper.scrollBy({ left: 2 }); 
    if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) wrapper.scrollTo({ left: 0, behavior: 'smooth' }); 
}, 30);
document.getElementById('marqueePrev').onclick = () => wrapper.scrollBy({ left: -350, behavior: 'smooth' }); 
document.getElementById('marqueeNext').onclick = () => wrapper.scrollBy({ left: 350, behavior: 'smooth' });
wrapper.addEventListener('mouseenter', () => clearInterval(auto)); 
wrapper.addEventListener('mouseleave', () => { 
    auto = setInterval(() => { 
        wrapper.scrollBy({ left: 2 }); 
        if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) wrapper.scrollTo({ left: 0, behavior: 'smooth' }); 
    }, 30); 
});
</script>

<!-- ADD ADMIN -->
<div class="max-w-6xl mx-auto mt-10 glass p-8 rounded-[2.5rem] shadow-xl border border-slate-200/80">
<?php if($success): ?><div class="bg-emerald-50 border border-emerald-200 text-emerald-700 p-4 rounded-2xl mb-6 flex items-center gap-2 text-base"><i class="fa-solid fa-circle-check"></i> <?= $success ?></div><?php endif; ?>
<?php if($error): ?><div class="bg-rose-50 border border-rose-200 text-rose-700 p-4 rounded-2xl mb-6 flex items-center gap-2 text-base"><i class="fa-solid fa-circle-exclamation"></i> <?= $error ?></div><?php endif; ?>
<h2 class="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
    <span class="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-600 grid place-items-center"><i class="fa-solid fa-user-plus text-base"></i></span> Add New Administrator
</h2>
<form method="POST" class="grid md:grid-cols-3 gap-4">
<input name="first" placeholder="First Name" class="border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-indigo-600 outline-none text-base transition" required>
<input name="last" placeholder="Last Name" class="border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-indigo-600 outline-none text-base transition" required>
<input name="mobile" placeholder="Mobile Number" class="border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-indigo-600 outline-none text-base transition" required>
<input name="email" type="email" placeholder="Email Address" class="border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-indigo-600 outline-none md:col-span-2 text-base transition" required>
<input name="password" type="password" placeholder="Password" class="border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-indigo-600 outline-none text-base transition" required>
<button name="add_admin" class="bg-indigo-600 text-white py-3.5 rounded-full hover:bg-indigo-700 md:col-span-3 shadow-lg text-base flex items-center justify-center gap-2 font-bold transition-all"><i class="fa-solid fa-plus"></i> Add Administrator</button>
</form>
</div>

<!-- ADMIN LIST TABLE -->
<div class="max-w-6xl mx-auto mt-10 mb-12 glass p-8 rounded-[2.5rem] shadow-xl border border-slate-200/80">
<h2 class="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-3">
    <span class="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 grid place-items-center"><i class="fa-solid fa-shield text-base"></i></span> Administrator List (Total: <?= count($admins) ?>)
</h2>
<div class="overflow-x-auto rounded-2xl border border-slate-200/60 bg-white/50">
<table class="w-full border-collapse">
<thead>
    <tr class="bg-indigo-600 text-white text-left text-base"><th class="p-4">Sr No</th><th class="p-4">Name</th><th class="p-4">Email</th><th class="p-4">Mobile</th><th class="p-4">Role</th><th class="p-4">Action</th></tr>
</thead>
<tbody class="text-base">
<?php $i = 1; foreach($admins as $a) { 
    $isSuperAdmin = ($a['role'] === 'Super Admin' || $a['user_id'] == 1);
?>
<tr class="border-b border-slate-100 hover:bg-white/80 transition">
    <td class="p-4 text-slate-500"><?= $i++ ?></td>
    <td class="p-4 font-bold text-slate-900"><?= htmlspecialchars($a['first_name']." ".$a['last_name']) ?></td>
    <td class="p-4 text-slate-600"><?= htmlspecialchars($a['email']) ?></td>
    <td class="p-4 text-slate-600"><?= htmlspecialchars($a['mobile_number']) ?></td>
    <td class="p-4">
        <span class="px-3 py-1 rounded-full text-xs font-bold text-white shadow-sm <?= $isSuperAdmin ? 'bg-slate-900' : 'bg-indigo-500' ?>">
            <?= htmlspecialchars($a['role']) ?>
        </span>
    </td>
    <td class="p-4 flex gap-2">
        <?php 
            $canModify = true;
            if ($isSuperAdmin && $_SESSION['user_id'] != 1) {
                $canModify = false;
            }
        ?>
        <?php if ($canModify || $_SESSION['user_id'] == $a['user_id']): ?>
            <button onclick="openEdit('<?= $a['user_id'] ?>','<?= htmlspecialchars($a['first_name']) ?>','<?= htmlspecialchars($a['last_name']) ?>','<?= htmlspecialchars($a['mobile_number']) ?>','<?= htmlspecialchars($a['email']) ?>')" class="bg-amber-500 text-white px-4 py-2 rounded-full hover:bg-amber-600 text-sm flex items-center gap-1 shadow-sm transition"><i class="fa-solid fa-pen"></i> Edit</button>
        <?php else: ?>
            <span class="text-xs text-slate-400 italic px-2 py-1">Protected</span>
        <?php endif; ?>

        <?php if (!$isSuperAdmin): ?>
            <a href="?delete=<?= $a['user_id'] ?>" onclick="return confirm('Are you sure you want to delete this administrator?')" class="bg-rose-500 text-white px-4 py-2 rounded-full hover:bg-rose-600 text-sm flex items-center gap-1 shadow-sm transition"><i class="fa-solid fa-trash"></i> Delete</a>
        <?php endif; ?>
    </td>
</tr>
<?php } if (count($admins) == 0) { echo "<tr><td colspan='6' class='p-8 text-center text-slate-400 text-base'><i class='fa-solid fa-inbox text-2xl mb-2 block'></i>No administrators found.</td></tr>"; } ?>
</tbody></table>
</div>
</div>

<!-- EDIT MODAL -->
<div id="editModal" class="hidden fixed inset-0 bg-slate-950/50 backdrop-blur-md flex items-center justify-center z-50 p-4">
<div class="glass bg-white/95 w-full max-w-sm p-8 rounded-[2.5rem] shadow-2xl border border-slate-200/80 relative animate-in">
<h2 class="text-2xl font-bold mb-5 flex items-center gap-2 text-slate-900"><i class="fa-solid fa-pen-to-square text-indigo-600"></i> Edit Administrator</h2>
<form method="POST" class="space-y-3">
<input type="hidden" name="user_id" id="e_id">
<input name="first" id="e_first" class="w-full border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-indigo-600 outline-none text-base transition" placeholder="First Name" required>
<input name="last" id="e_last" class="w-full border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-indigo-600 outline-none text-base transition" placeholder="Last Name" required>
<input name="mobile" id="e_mobile" class="w-full border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-indigo-600 outline-none text-base transition" placeholder="Mobile Number" required>
<input name="email" id="e_email" type="email" class="w-full border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-indigo-600 outline-none text-base transition" placeholder="Email Address" required>
<input name="password" type="password" class="w-full border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-indigo-600 outline-none text-base transition" placeholder="New Password (optional)">
<button name="update_admin" class="bg-indigo-600 text-white w-full py-3.5 rounded-full hover:bg-indigo-700 shadow-lg flex items-center justify-center gap-2 text-base font-bold transition-all"><i class="fa-solid fa-check"></i> Update Administrator</button>
</form>
<button onclick="closeEdit()" class="mt-4 w-full text-slate-500 text-base hover:text-slate-800 transition"><i class="fa-solid fa-xmark mr-1"></i> Close</button>
</div>
</div>

<script>
function openEdit(id, f, l, m, e) {
    document.getElementById("editModal").classList.remove("hidden");
    document.getElementById("e_id").value = id;
    document.getElementById("e_first").value = f;
    document.getElementById("e_last").value = l;
    document.getElementById("e_mobile").value = m;
    document.getElementById("e_email").value = e;
}
function closeEdit() {
    document.getElementById("editModal").classList.add("hidden");
}
</script>
</body>
</html>