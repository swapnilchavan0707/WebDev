<?php
session_start();
include "config/db.php";

/* ================= SECURITY ================= */
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
$current_user_id = $_SESSION['user_id'];
$success = "";
$error = "";

/* ================= UPDATE PROFILE ================= */
if (isset($_POST['update_profile'])) {
    $first = trim($_POST['first_name']);
    $last = trim($_POST['last_name']);
    $mobile = trim($_POST['mobile_number']);
    $email = trim(strtolower($_POST['email']));

    if ($first && $last && $mobile && $email) {
        // Check if email is taken by another user
        $check = $conn->prepare("SELECT user_id FROM users WHERE email = :email AND user_id != :id");
        $check->execute([':email' => $email, ':id' => $current_user_id]);
        if ($check->fetch()) {
            $error = "Email address is already in use by another account!";
        } else {
            if (!empty($_POST['password'])) {
                $password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);
                $sql = "UPDATE users SET first_name=:first, last_name=:last, mobile_number=:mobile, email=:email, password=:password WHERE user_id=:id";
                $params = [':first' => $first, ':last' => $last, ':mobile' => $mobile, ':email' => $email, ':password' => $password, ':id' => $current_user_id];
            } else {
                $sql = "UPDATE users SET first_name=:first, last_name=:last, mobile_number=:mobile, email=:email WHERE user_id=:id";
                $params = [':first' => $first, ':last' => $last, ':mobile' => $mobile, ':email' => $email, ':id' => $current_user_id];
            }
            $stmt = $conn->prepare($sql);
            $stmt->execute($params);

            // Update session name if changed
            $_SESSION['name'] = $first . " " . $last;
            $success = "Profile updated successfully!";
        }
    } else {
        $error = "Please fill in all required fields.";
    }
}

/* ================= FETCH USER DETAILS ================= */
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = :id");
$stmt->execute([':id' => $current_user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Profile - FlowTrack</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<style>
* { font-family: "Playfair Display", serif !important; font-optical-sizing: auto; font-style: normal; }
body, div, h1, h2, h3, p, a, input, button, label { font-family: "Playfair Display", serif !important; font-weight: 600 !important; letter-spacing: 0.02em; }
h1, h2 { font-weight: 800 !important; }
input, button { font-size: 16px !important; }
.fa, .fa-solid, .fa-regular, .fa-brands { font-family: "Font Awesome 6 Free", "Font Awesome 6 Brands" !important; font-weight: 900 !important; }
.glass-panel { background: rgba(255, 255, 255, 0.92); backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px); border: 1px solid rgba(245, 158, 11, 0.2); }
.hide-scrollbar { scrollbar-width: none; -ms-overflow-style: none; }
.hide-scrollbar::-webkit-scrollbar { display: none; }
</style>
</head>
<body class="bg-[#f8f6f0] min-h-screen relative text-slate-800">

<!-- AMBIENT BACKGROUND GLOWS -->
<div class="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
    <div class="absolute inset-0 bg-gradient-to-br from-[#fffdfa] via-[#f5f7ff] to-[#fff3ed]"></div>
    <div class="absolute top-[-10%] left-[10%] w-[450px] h-[450px] bg-amber-400/15 rounded-full blur-[120px]"></div>
    <div class="absolute bottom-[-10%] right-[5%] w-[450px] h-[450px] bg-indigo-500/15 rounded-full blur-[120px]"></div>
</div>

<!-- NAVBAR -->
<nav class="bg-white/95 backdrop-blur-2xl shadow-md border-b border-amber-100 sticky top-0 z-50">
<div class="max-w-7xl mx-auto px-6 h-24 flex justify-between items-center">
<a href="dashboard.php" class="flex items-center gap-3.5 group">
    <div class="w-12 h-12 bg-gradient-to-tr from-amber-500 to-amber-600 rounded-2xl flex items-center justify-center shadow-lg shadow-amber-500/30 group-hover:scale-110 transition-transform duration-300">
        <i class="fa-solid fa-user-gear text-white text-lg"></i>
    </div>
    <div>
        <h1 class="text-xl font-extrabold bg-gradient-to-r from-amber-700 to-amber-900 bg-clip-text text-transparent leading-none">FlowTrack</h1>
        <p class="text-xs text-amber-600 font-bold tracking-widest mt-1">Account Settings</p>
    </div>
</a>
<div class="flex items-center gap-4">
    <span class="hidden md:flex items-center gap-2 text-base text-slate-600 bg-amber-50 border border-amber-200/60 px-4 py-2 rounded-full shadow-sm font-bold">
        <i class="fa-solid fa-shield-halved text-amber-600"></i> <?= htmlspecialchars($user['role']) ?>
    </span>
    <a href="dashboard.php" class="px-5 py-2.5 rounded-full bg-gradient-to-r from-slate-900 to-slate-950 text-white hover:from-slate-800 hover:to-slate-900 shadow-md text-base flex items-center gap-2 h-11 font-bold transition-all hover:scale-105">
        <i class="fa-solid fa-arrow-left"></i> Dashboard
    </a>
</div>
</div>
</nav>

<!-- PROFILE SECTION -->
<div class="max-w-3xl mx-auto mt-12 mb-20 glass-panel p-8 md:p-12 rounded-[2.5rem] shadow-2xl">
<?php if($success): ?>
    <div class="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-2xl mb-6 flex items-center gap-3 text-base shadow-sm">
        <div class="w-8 h-8 rounded-xl bg-emerald-500 text-white grid place-items-center shrink-0"><i class="fa-solid fa-circle-check"></i></div> 
        <span><?= $success ?></span>
    </div>
<?php endif; ?>

<?php if($error): ?>
    <div class="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-2xl mb-6 flex items-center gap-3 text-base shadow-sm">
        <div class="w-8 h-8 rounded-xl bg-rose-500 text-white grid place-items-center shrink-0"><i class="fa-solid fa-circle-exclamation"></i></div> 
        <span><?= $error ?></span>
    </div>
<?php endif; ?>

<div class="flex flex-col sm:flex-row items-center gap-6 mb-8 pb-8 border-b border-slate-200/80 text-center sm:text-left">
    <div class="w-24 h-24 bg-gradient-to-tr from-amber-500 to-amber-600 text-white rounded-3xl flex items-center justify-center text-4xl shadow-xl shadow-amber-500/30 font-extrabold shrink-0">
        <?= strtoupper(substr($user['first_name'], 0, 1)) ?>
    </div>
    <div>
        <h2 class="text-3xl font-extrabold text-slate-900"><?= htmlspecialchars($user['first_name'] . " " . $user['last_name']) ?></h2>
        <p class="text-base text-slate-500 mt-1 flex flex-wrap items-center justify-center sm:justify-start gap-2">
            <span><i class="fa-solid fa-envelope mr-1.5 text-amber-600"></i> <?= htmlspecialchars($user['email']) ?></span>
            <span class="text-slate-300">&bull;</span>
            <span class="bg-amber-100 text-amber-800 border border-amber-200 px-3 py-0.5 rounded-full text-xs font-bold shadow-sm"><?= htmlspecialchars($user['role']) ?></span>
        </p>
    </div>
</div>

<form method="POST" class="space-y-6">
<div class="grid md:grid-cols-2 gap-6">
    <div>
        <label class="block text-sm font-bold text-slate-600 mb-2"><i class="fa-solid fa-user mr-1.5 text-amber-600"></i> First Name</label>
        <input name="first_name" value="<?= htmlspecialchars($user['first_name']) ?>" class="w-full border border-slate-200 p-4 rounded-2xl bg-white/90 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-base font-semibold shadow-sm transition" required>
    </div>
    <div>
        <label class="block text-sm font-bold text-slate-600 mb-2"><i class="fa-solid fa-user mr-1.5 text-amber-600"></i> Last Name</label>
        <input name="last_name" value="<?= htmlspecialchars($user['last_name']) ?>" class="w-full border border-slate-200 p-4 rounded-2xl bg-white/90 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-base font-semibold shadow-sm transition" required>
    </div>
</div>

<div class="grid md:grid-cols-2 gap-6">
    <div>
        <label class="block text-sm font-bold text-slate-600 mb-2"><i class="fa-solid fa-phone mr-1.5 text-amber-600"></i> Mobile Number</label>
        <input name="mobile_number" value="<?= htmlspecialchars($user['mobile_number']) ?>" class="w-full border border-slate-200 p-4 rounded-2xl bg-white/90 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-base font-semibold shadow-sm transition" required>
    </div>
    <div>
        <label class="block text-sm font-bold text-slate-600 mb-2"><i class="fa-solid fa-envelope mr-1.5 text-amber-600"></i> Email Address</label>
        <input name="email" type="email" value="<?= htmlspecialchars($user['email']) ?>" class="w-full border border-slate-200 p-4 rounded-2xl bg-white/90 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-base font-semibold shadow-sm transition" required>
    </div>
</div>

<div>
    <label class="block text-sm font-bold text-slate-600 mb-2"><i class="fa-solid fa-lock mr-1.5 text-amber-600"></i> New Password <span class="text-xs text-slate-400 font-normal">(Leave blank to keep current password)</span></label>
    <input name="password" type="password" placeholder="Enter new password if you want to change it" class="w-full border border-slate-200 p-4 rounded-2xl bg-white/90 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-base font-semibold shadow-sm transition">
</div>

<button name="update_profile" class="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-white py-4 rounded-full hover:from-amber-600 hover:to-amber-700 shadow-xl shadow-amber-500/25 text-lg flex items-center justify-center gap-2.5 font-bold transition-all hover:scale-[1.01]">
    <i class="fa-solid fa-floppy-disk"></i> Save Profile Changes
</button>
</form>
</div>

</body>
</html>