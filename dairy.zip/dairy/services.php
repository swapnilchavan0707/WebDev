<?php
session_start();
include "includes/header.php";
?>

<!-- GOOGLE FONT: PLAYFAIR DISPLAY INJECTION -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">

<style>
.font-playfair {
    font-family: "Playfair Display", serif;
    font-optical-sizing: auto;
}
</style>

<!-- AMBIENT BACKGROUND GLOW EFFECTS -->
<div class="absolute top-10 left-1/2 -translate-x-1/2 w-[650px] h-[350px] bg-gradient-to-tr from-blue-400/20 via-indigo-400/15 to-purple-400/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>

<!-- UNIQUE MARQUEE CAROUSEL FOR SERVICES -->
<div class="relative max-w-7xl mx-auto mb-16 pt-6">
<div class="relative rounded-[2.5rem] overflow-hidden border border-slate-200/60 shadow-2xl bg-white/80 backdrop-blur-2xl p-6">
<div class="flex items-center justify-between mb-5 px-3">
<div class="flex items-center gap-2.5 text-xs font-bold uppercase tracking-wider text-blue-600">
<span class="w-2.5 h-2.5 rounded-full bg-blue-600 animate-ping"></span> Pixel & Pulp Solutions
</div>
<span class="text-xs text-slate-400 font-medium tracking-wide">WorkWave Professional Suite</span>
</div>

<div class="relative overflow-hidden w-full">
<button id="marqueePrev" class="absolute left-3 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-2xl bg-white/95 border border-slate-200/80 shadow-2xl grid place-items-center text-slate-700 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all duration-300"><i class="fa-solid fa-chevron-left text-sm"></i></button>
<button id="marqueeNext" class="absolute right-3 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-2xl bg-white/95 border border-slate-200/80 shadow-2xl grid place-items-center text-slate-700 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all duration-300"><i class="fa-solid fa-chevron-right text-sm"></i></button>

<div id="marqueeWrapper" class="flex gap-6 overflow-x-auto hide-scrollbar scroll-smooth py-3 px-2">
<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-blue-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-chart-pie"></i></div> Enterprise Analytics
</div>
</div>

<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-indigo-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-shield-halved"></i></div> Data Security & Vaults
</div>
</div>

<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-emerald-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-list-check"></i></div> Advanced Task Sorting
</div>
</div>

<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-violet-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-gauge-high"></i></div> Performance Metrics
</div>
</div>

<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-amber-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-headset"></i></div> 24/7 Expert Support
</div>
</div>
</div>
</div>
</div>
</div>

<script>
const wrapper = document.getElementById('marqueeWrapper');
const cardWidth = 384;
let autoScroll = setInterval(() => {
    wrapper.scrollBy({ left: 1.5, behavior: 'smooth' });
    if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) {
        wrapper.scrollTo({ left: 0, behavior: 'smooth' });
    }
}, 30);

document.getElementById('marqueePrev').onclick = () => wrapper.scrollBy({ left: -cardWidth, behavior: 'smooth' });
document.getElementById('marqueeNext').onclick = () => wrapper.scrollBy({ left: cardWidth, behavior: 'smooth' });

wrapper.addEventListener('mouseenter', () => clearInterval(autoScroll));
wrapper.addEventListener('mouseleave', () => {
    autoScroll = setInterval(() => {
        wrapper.scrollBy({ left: 1.5, behavior: 'smooth' });
        if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) {
            wrapper.scrollTo({ left: 0, behavior: 'smooth' });
        }
    }, 30);
});
</script>

<div class="py-6">
<div class="text-center max-w-3xl mx-auto mb-16">
<span class="px-5 py-2 rounded-full bg-blue-50 border border-blue-200/60 text-blue-700 text-xs font-bold uppercase tracking-widest shadow-sm inline-block mb-4">What We Offer</span>
<h1 class="text-4xl md:text-5xl font-black text-slate-900 tracking-tight font-playfair">Professional Services & Solutions</h1>
<p class="text-slate-600 text-lg mt-4 font-normal">Discover our comprehensive suite of productivity and organizational toolsets engineered by WorkWave.</p>
</div>

<div class="grid md:grid-cols-3 gap-8 mb-20">
<div class="p-8 rounded-[2.5rem] shadow-xl border border-slate-200/60 bg-white/90 backdrop-blur-2xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl group">
<div class="w-16 h-16 bg-blue-50 border border-blue-100 rounded-2xl grid place-items-center text-blue-600 text-2xl mb-6 shadow-md group-hover:scale-110 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300"><i class="fa-solid fa-chart-simple"></i></div>
<h3 class="text-2xl font-bold text-slate-900 mb-3 font-playfair">Analytics Dashboard</h3>
<p class="text-slate-600 text-base leading-relaxed">Real-time statistics displaying task velocity, completion percentages, and milestone breakdowns.</p>
</div>

<div class="p-8 rounded-[2.5rem] shadow-xl border border-slate-200/60 bg-white/90 backdrop-blur-2xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl group">
<div class="w-16 h-16 bg-indigo-50 border border-indigo-100 rounded-2xl grid place-items-center text-indigo-600 text-2xl mb-6 shadow-md group-hover:scale-110 group-hover:bg-indigo-600 group-hover:text-white transition-all duration-300"><i class="fa-solid fa-lock"></i></div>
<h3 class="text-2xl font-bold text-slate-900 mb-3 font-playfair">Secure Workspace</h3>
<p class="text-slate-600 text-base leading-relaxed">Isolated database vaults ensuring your private corporate notes and project data remain entirely safe.</p>
</div>

<div class="p-8 rounded-[2.5rem] shadow-xl border border-slate-200/60 bg-white/90 backdrop-blur-2xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl group">
<div class="w-16 h-16 bg-emerald-50 border border-emerald-100 rounded-2xl grid place-items-center text-emerald-600 text-2xl mb-6 shadow-md group-hover:scale-110 group-hover:bg-emerald-600 group-hover:text-white transition-all duration-300"><i class="fa-solid fa-list-check"></i></div>
<h3 class="text-2xl font-bold text-slate-900 mb-3 font-playfair">Task Management</h3>
<p class="text-slate-600 text-base leading-relaxed">Advanced categorization system allowing pending, in-progress, and complete sorting effortlessly.</p>
</div>
</div>
</div>

<?php include "includes/footer.php"; ?>