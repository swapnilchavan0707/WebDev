<?php
session_start();
include "includes/header.php";
?>

<!-- GOOGLE FONT: PLAYFAIR DISPLAY INJECTION -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">

<style>
.font-playfair {
    font-family: "Playfair Display", serif;
    font-optical-sizing: auto;
}
</style>

<!-- AMBIENT BACKGROUND GLOW EFFECTS -->
<div class="absolute top-10 left-1/2 -translate-x-1/2 w-[650px] h-[350px] bg-gradient-to-tr from-blue-400/20 via-indigo-400/15 to-purple-400/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>

<!-- UNIQUE MARQUEE CAROUSEL FOR CONTACT -->
<div class="relative max-w-7xl mx-auto mb-16 pt-6">
<div class="relative rounded-[2.5rem] overflow-hidden border border-slate-200/60 shadow-2xl bg-white/80 backdrop-blur-2xl p-6">
<div class="flex items-center justify-between mb-5 px-3">
<div class="flex items-center gap-2.5 text-xs font-bold uppercase tracking-wider text-blue-600">
<span class="w-2.5 h-2.5 rounded-full bg-blue-600 animate-ping"></span> Pixel & Pulp Support Network
</div>
<span class="text-xs text-slate-400 font-medium tracking-wide">WorkWave Customer Relations</span>
</div>

<div class="relative overflow-hidden w-full">
<button id="marqueePrev" class="absolute left-3 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-2xl bg-white/95 border border-slate-200/80 shadow-2xl grid place-items-center text-slate-700 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all duration-300"><i class="fa-solid fa-chevron-left text-sm"></i></button>
<button id="marqueeNext" class="absolute right-3 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-2xl bg-white/95 border border-slate-200/80 shadow-2xl grid place-items-center text-slate-700 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all duration-300"><i class="fa-solid fa-chevron-right text-sm"></i></button>

<div id="marqueeWrapper" class="flex gap-6 overflow-x-auto hide-scrollbar scroll-smooth py-3 px-2">
<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1423784346385-c1d4dac9093a?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-blue-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-headset"></i></div> Customer Support Desk
</div>
</div>

<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1577563908411-5077b6dc7624?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-indigo-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-comments"></i></div> Client Communication
</div>
</div>

<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-emerald-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-envelope-open-text"></i></div> Inquiry Response Hub
</div>
</div>

<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1534536281715-e28d76689b4d?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-violet-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-phone-volume"></i></div> Hotline Assistance
</div>
</div>

<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-amber-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-building-user"></i></div> Corporate Office
</div>
</div>
</div>
</div>
</div>
</div>

<script>
const wrapper = document.getElementById('marqueeWrapper');
const cardWidth = 384;
let autoScroll = setInterval(() => {
    wrapper.scrollBy({ left: 1.5, behavior: 'smooth' });
    if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) {
        wrapper.scrollTo({ left: 0, behavior: 'smooth' });
    }
}, 30);

document.getElementById('marqueePrev').onclick = () => wrapper.scrollBy({ left: -cardWidth, behavior: 'smooth' });
document.getElementById('marqueeNext').onclick = () => wrapper.scrollBy({ left: cardWidth, behavior: 'smooth' });

wrapper.addEventListener('mouseenter', () => clearInterval(autoScroll));
wrapper.addEventListener('mouseleave', () => {
    autoScroll = setInterval(() => {
        wrapper.scrollBy({ left: 1.5, behavior: 'smooth' });
        if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) {
            wrapper.scrollTo({ left: 0, behavior: 'smooth' });
        }
    }, 30);
});
</script>

<div class="py-6">
<div class="text-center max-w-3xl mx-auto mb-16">
<span class="px-5 py-2 rounded-full bg-blue-50 border border-blue-200/60 text-blue-700 text-xs font-bold uppercase tracking-widest shadow-sm inline-block mb-4">Get In Touch</span>
<h1 class="text-4xl md:text-5xl font-black text-slate-900 tracking-tight font-playfair">We Would Love To Hear From You</h1>
<p class="text-slate-600 text-lg mt-4 font-normal">Have questions or feedback? Reach out to our dedicated corporate support team at WorkWave.</p>
</div>

<!-- CONTACT DETAILS SECTION -->
<div class="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-20 px-4">
    
    <!-- Corporate HQ -->
    <div class="relative p-8 rounded-[2.5rem] shadow-xl border border-slate-200/60 bg-white/90 backdrop-blur-2xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl group space-y-4">
        <div class="w-16 h-16 bg-blue-50 border border-blue-100 rounded-2xl grid place-items-center text-blue-600 text-2xl shadow-md group-hover:scale-110 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300"><i class="fa-solid fa-building"></i></div>
        <h3 class="text-2xl font-bold text-slate-900 font-playfair">Corporate HQ</h3>
        <p class="text-slate-600 text-base leading-relaxed">Pixel & Pulp, Pune Office, Maharashtra, India.</p>
    </div>

    <!-- Call Support -->
    <div class="relative p-8 rounded-[2.5rem] shadow-xl border border-slate-200/60 bg-white/90 backdrop-blur-2xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl group space-y-4">
        <div class="w-16 h-16 bg-indigo-50 border border-indigo-100 rounded-2xl grid place-items-center text-indigo-600 text-2xl shadow-md group-hover:scale-110 group-hover:bg-indigo-600 group-hover:text-white transition-all duration-300"><i class="fa-solid fa-headset"></i></div>
        <h3 class="text-2xl font-bold text-slate-900 font-playfair">Call Support</h3>
        <p class="text-slate-600 text-base leading-relaxed">
            <a href="tel:+919876543210" class="hover:text-blue-600 font-semibold transition-colors">+91 98765 43210</a><br>
            <span class="text-xs text-slate-400 font-medium">Mon - Fri, 9:00 AM - 6:00 PM</span>
        </p>
    </div>

    <!-- Email Address -->
    <div class="relative p-8 rounded-[2.5rem] shadow-xl border border-slate-200/60 bg-white/90 backdrop-blur-2xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl group space-y-4">
        <div class="w-16 h-16 bg-emerald-50 border border-emerald-100 rounded-2xl grid place-items-center text-emerald-600 text-2xl shadow-md group-hover:scale-110 group-hover:bg-emerald-600 group-hover:text-white transition-all duration-300"><i class="fa-solid fa-envelope"></i></div>
        <h3 class="text-2xl font-bold text-slate-900 font-playfair">Email Address</h3>
        <p class="text-slate-600 text-base leading-relaxed">
            <a href="mailto:support@workwave.com" class="hover:text-blue-600 font-semibold break-all transition-colors">support@workwave.com</a><br>
            <span class="text-xs text-slate-400 font-medium">Online 24/7 for queries</span>
        </p>
    </div>

</div>
</div>

<?php include "includes/footer.php"; ?>