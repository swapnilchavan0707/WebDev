</main>

<footer class="bg-white/80 backdrop-blur-2xl border-t border-slate-200/60 mt-20 py-12">
<div class="max-w-7xl mx-auto px-6 grid md:grid-cols-4 gap-8">
<div>
<div class="flex items-center gap-3 mb-4">
<div class="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-md"><i class="fa-solid fa-list-check"></i></div>
<span class="text-lg font-extrabold text-slate-900 font-playfair">WorkWave</span>
</div>
<p class="text-sm text-slate-600 leading-relaxed font-normal">Elevating daily productivity through intelligent task organization and real-time execution tracking by Pixel & Pulp.</p>
</div>
<div>
<h4 class="font-bold text-slate-900 mb-4 font-playfair text-base">Quick Navigation</h4>
<ul class="space-y-2 text-sm text-slate-600 font-normal">
<li><a href="index.php" class="hover:text-blue-600 transition-colors">Home Page</a></li>
<li><a href="about.php" class="hover:text-blue-600 transition-colors">About Our Story</a></li>
<li><a href="services.php" class="hover:text-blue-600 transition-colors">Core Services</a></li>
<li><a href="contact.php" class="hover:text-blue-600 transition-colors">Contact Team</a></li>
</ul>
</div>
<div>
<h4 class="font-bold text-slate-900 mb-4 font-playfair text-base">Workspace</h4>
<ul class="space-y-2 text-sm text-slate-600 font-normal">
<li><a href="dashboard.php" class="hover:text-blue-600 transition-colors">User Dashboard</a></li>
<li><a href="tasks/manage_tasks.php" class="hover:text-blue-600 transition-colors">Task Manager</a></li>
</ul>
</div>
<div>
<h4 class="font-bold text-slate-900 mb-4 font-playfair text-base">Secure Network</h4>
<p class="text-sm text-slate-600 mb-4 font-normal">Protected by Pixel & Pulp advanced safety vaults.</p>
<div class="flex gap-3 text-blue-600">
<a href="#" class="w-10 h-10 rounded-full bg-blue-50 border border-blue-100 grid place-items-center hover:bg-blue-600 hover:text-white transition-all shadow-sm"><i class="fa-brands fa-x-twitter"></i></a>
<a href="#" class="w-10 h-10 rounded-full bg-blue-50 border border-blue-100 grid place-items-center hover:bg-blue-600 hover:text-white transition-all shadow-sm"><i class="fa-brands fa-linkedin-in"></i></a>
<a href="#" class="w-10 h-10 rounded-full bg-blue-50 border border-blue-100 grid place-items-center hover:bg-blue-600 hover:text-white transition-all shadow-sm"><i class="fa-brands fa-github"></i></a>
</div>
</div>
</div>
<div class="max-w-7xl mx-auto px-6 border-t border-slate-200/60 mt-8 pt-8 text-center text-sm text-slate-400 font-normal">
&copy; <?= date('Y'); ?> WorkWave Pro by Pixel & Pulp. All rights reserved. Built with precision and elegance.
</div>
</footer>
</body>
</html>