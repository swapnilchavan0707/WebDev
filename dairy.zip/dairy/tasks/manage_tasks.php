<?php
session_start();
include "../config/db.php";

/* ================= SECURITY ================= */
if (!isset($_SESSION['user_id'])) {
    header("Location:../index.php");
    exit;
}

$current_user_id = $_SESSION['user_id'];
$success = "";
$error = "";

/* ================= ADD TASK ================= */
if (isset($_POST['add_task'])) {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $status = trim($_POST['status']);

    if ($title && $status) {
        $sql = "INSERT INTO tasks (user_id, title, description, status) VALUES (:user_id, :title, :description, :status)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':user_id' => $current_user_id,
            ':title' => $title,
            ':description' => $description,
            ':status' => $status
        ]);
        header("Location: manage_tasks.php?msg=added");
        exit;
    } else {
        $error = "Task Title and Status are required fields.";
    }
}

/* ================= DELETE TASK ================= */
if (isset($_GET['delete'])) {
    $task_id = (int)$_GET['delete'];
    
    $del = $conn->prepare("DELETE FROM tasks WHERE task_id = :task_id AND user_id = :user_id");
    $del->execute([
        ':task_id' => $task_id,
        ':user_id' => $current_user_id
    ]);
    header("Location: manage_tasks.php?msg=deleted");
    exit;
}

/* ================= UPDATE TASK ================= */
if (isset($_POST['update_task'])) {
    $task_id = (int)($_POST['task_id'] ?? 0);
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $status = trim($_POST['status']);

    if ($title && $status) {
        $sql = "UPDATE tasks SET title = :title, description = :description, status = :status WHERE task_id = :task_id AND user_id = :user_id";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':title' => $title,
            ':description' => $description,
            ':status' => $status,
            ':task_id' => $task_id,
            ':user_id' => $current_user_id
        ]);
        header("Location: manage_tasks.php?msg=updated");
        exit;
    } else {
        $error = "Task Title and Status are required fields.";
    }
}

if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'added') $success = "Task created successfully!";
    if ($_GET['msg'] == 'deleted') $success = "Task deleted successfully!";
    if ($_GET['msg'] == 'updated') $success = "Task updated successfully!";
}

/* ================= FETCH TASKS FOR CURRENT USER ================= */
$stmt = $conn->prepare("SELECT * FROM tasks WHERE user_id = :user_id ORDER BY task_id DESC");
$stmt->execute([':user_id' => $current_user_id]);
$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Tasks - WorkWave Pixel & Pulp</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<style>
* { font-family: "Playfair Display", serif !important; font-optical-sizing: auto; font-style: normal; }
body, div, h1, h2, h3, p, a, input, button, table, th, td, label, textarea, select { font-family: "Playfair Display", serif !important; font-weight: 600 !important; letter-spacing: 0.02em; }
h1, h2 { font-weight: 800 !important; }
input, button, td, th, textarea, select { font-size: 16px !important; }
.fa, .fa-solid, .fa-regular, .fa-brands { font-family: "Font Awesome 6 Free", "Font Awesome 6 Brands" !important; font-weight: 900 !important; }
.glass { background: rgba(255, 255, 255, 0.92); backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px); border: 1px solid rgba(245, 158, 11, 0.2); }
.hide-scrollbar { scrollbar-width: none; -ms-overflow-style: none; }
.hide-scrollbar::-webkit-scrollbar { display: none; }
</style>
</head>
<body class="bg-[#f8f6f0] min-h-screen relative text-slate-800">
<div class="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
    <div class="absolute inset-0 bg-gradient-to-br from-[#fffdfa] via-[#f5f7ff] to-[#fff3ed]"></div>
    <div class="absolute top-[-10%] left-[10%] w-[450px] h-[450px] bg-amber-400/15 rounded-full blur-[120px]"></div>
    <div class="absolute bottom-[-10%] right-[5%] w-[450px] h-[450px] bg-indigo-500/15 rounded-full blur-[120px]"></div>
</div>

<!-- NAVBAR -->
<nav class="bg-white/95 backdrop-blur-2xl shadow-md border-b border-amber-100 sticky top-0 z-50">
<div class="max-w-7xl mx-auto px-6 h-24 flex justify-between items-center">
<a href="../dashboard.php" class="flex items-center gap-3.5 group">
    <div class="w-12 h-12 bg-gradient-to-tr from-amber-500 to-amber-600 rounded-2xl flex items-center justify-center shadow-lg shadow-amber-500/30 group-hover:scale-110 transition-transform duration-300">
        <i class="fa-solid fa-list-check text-white text-lg"></i>
    </div>
    <div>
        <h1 class="text-xl font-extrabold bg-gradient-to-r from-amber-700 to-amber-900 bg-clip-text text-transparent leading-none">WorkWave</h1>
        <p class="text-xs text-amber-600 font-bold tracking-widest mt-1">Pixel & Pulp</p>
    </div>
</a>
<div class="flex items-center gap-4">
    <span class="hidden md:flex items-center gap-2 text-base text-slate-600 bg-amber-50 border border-amber-200/60 px-4 py-2 rounded-full shadow-sm font-bold">
        <i class="fa-solid fa-user text-amber-600"></i> <?= htmlspecialchars($_SESSION['role'] ?? 'User') ?>
    </span>
    <a href="../dashboard.php" class="px-5 py-2.5 rounded-full bg-gradient-to-r from-slate-900 to-slate-950 text-white hover:from-slate-800 hover:to-slate-900 shadow-md text-base flex items-center gap-2 h-11 font-bold transition-all hover:scale-105">
        <i class="fa-solid fa-arrow-left"></i> Dashboard
    </a>
</div>
</div>
</nav>

<!-- MARQUEE CAROUSEL -->
<div class="relative max-w-7xl mx-auto px-6 mt-8 group">
<div class="relative rounded-[2rem] overflow-hidden border border-amber-100 shadow-xl bg-white h-48">
<button id="marqueePrev" class="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/90 border border-amber-200 shadow-xl grid place-items-center hover:bg-amber-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-left text-sm"></i></button>
<button id="marqueeNext" class="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full glass bg-white/90 border border-amber-200 shadow-xl grid place-items-center hover:bg-amber-600 hover:text-white transition-all hover:scale-110"><i class="fa-solid fa-chevron-right text-sm"></i></button>
<div class="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"></div>
<div class="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"></div>
<div id="marqueeWrapper" class="overflow-x-auto hide-scrollbar h-full scroll-smooth">
<div class="flex gap-4 p-3 h-full">
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card"><img src="https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-900/70 to-transparent"></div><div class="absolute bottom-3 left-3 text-white text-base"><i class="fa-solid fa-clipboard-list mr-2 text-amber-400"></i> Task Execution</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card"><img src="https://images.unsplash.com/photo-1507925921958-8a62f3d1a50d?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-900/70 to-transparent"></div><div class="absolute bottom-3 left-3 text-white text-base"><i class="fa-solid fa-bullseye mr-2 text-amber-400"></i> Goal Tracking</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card"><img src="https://images.unsplash.com/photo-1454165205744-3b78555e5572?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-900/70 to-transparent"></div><div class="absolute bottom-3 left-3 text-white text-base"><i class="fa-solid fa-business-time mr-2 text-amber-400"></i> Productivity Hub</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card"><img src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-900/70 to-transparent"></div><div class="absolute bottom-3 left-3 text-white text-base"><i class="fa-solid fa-list-check mr-2 text-amber-400"></i> Workflow Control</div></div>
<div class="relative min-w-[320px] h-full rounded-2xl overflow-hidden shrink-0 group/card"><img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700"><div class="absolute inset-0 bg-gradient-to-t from-slate-900/70 to-transparent"></div><div class="absolute bottom-3 left-3 text-white text-base"><i class="fa-solid fa-check-double mr-2 text-amber-400"></i> Task Completion</div></div>
</div></div>
</div>
</div>
<script>
const wrapper = document.getElementById('marqueeWrapper'); 
let auto = setInterval(() => { 
    wrapper.scrollBy({ left: 2 }); 
    if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) wrapper.scrollTo({ left: 0, behavior: 'smooth' }); 
}, 30);
document.getElementById('marqueePrev').onclick = () => wrapper.scrollBy({ left: -350, behavior: 'smooth' }); 
document.getElementById('marqueeNext').onclick = () => wrapper.scrollBy({ left: 350, behavior: 'smooth' });
wrapper.addEventListener('mouseenter', () => clearInterval(auto)); 
wrapper.addEventListener('mouseleave', () => { 
    auto = setInterval(() => { 
        wrapper.scrollBy({ left: 2 }); 
        if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) wrapper.scrollTo({ left: 0, behavior: 'smooth' }); 
    }, 30); 
});
</script>

<!-- ADD TASK SECTION -->
<div class="max-w-4xl mx-auto mt-10 glass p-8 md:p-10 rounded-[2.5rem] shadow-2xl border border-amber-200/60">
<?php if($success): ?>
    <div class="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-2xl mb-6 flex items-center gap-3 text-base shadow-sm">
        <div class="w-8 h-8 rounded-xl bg-emerald-500 text-white grid place-items-center shrink-0"><i class="fa-solid fa-circle-check"></i></div> 
        <span><?= $success ?></span>
    </div>
<?php endif; ?>

<?php if($error): ?>
    <div class="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-2xl mb-6 flex items-center gap-3 text-base shadow-sm">
        <div class="w-8 h-8 rounded-xl bg-rose-500 text-white grid place-items-center shrink-0"><i class="fa-solid fa-circle-exclamation"></i></div> 
        <span><?= $error ?></span>
    </div>
<?php endif; ?>

<h2 class="text-2xl font-extrabold text-slate-900 mb-6 flex items-center gap-3">
    <span class="w-10 h-10 rounded-2xl bg-amber-500 text-white grid place-items-center shadow-md shadow-amber-500/30"><i class="fa-solid fa-plus text-base"></i></span> Add New Task
</h2>

<form method="POST" class="space-y-5">
<div class="grid md:grid-cols-3 gap-4">
    <div class="md:col-span-2">
        <label class="block text-sm font-bold text-slate-600 mb-1.5"><i class="fa-solid fa-heading mr-1.5 text-amber-600"></i> Task Title</label>
        <input name="title" placeholder="Enter task title" class="w-full border border-slate-200 p-4 rounded-2xl bg-white/90 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-base font-semibold shadow-sm transition" required>
    </div>
    <div>
        <label class="block text-sm font-bold text-slate-600 mb-1.5"><i class="fa-solid fa-spinner mr-1.5 text-amber-600"></i> Status</label>
        <select name="status" class="w-full border border-slate-200 p-4 rounded-2xl bg-white/90 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-base font-semibold shadow-sm transition" required>
            <option value="Pending">Pending</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed</option>
        </select>
    </div>
</div>

<div>
    <label class="block text-sm font-bold text-slate-600 mb-1.5"><i class="fa-solid fa-align-left mr-1.5 text-amber-600"></i> Task Description</label>
    <textarea name="description" placeholder="Write down extra details or notes..." class="w-full border border-slate-200 p-4 rounded-2xl bg-white/90 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none md:col-span-3 text-base h-28 font-semibold shadow-sm transition"></textarea>
</div>

<button name="add_task" class="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-white py-4 rounded-full hover:from-amber-600 hover:to-amber-700 shadow-xl shadow-amber-500/25 text-lg flex items-center justify-center gap-2.5 font-bold transition-all hover:scale-[1.01]">
    <i class="fa-solid fa-circle-plus"></i> Create Task
</button>
</form>
</div>

<!-- TASK LIST TABLE -->
<div class="max-w-6xl mx-auto mt-12 mb-20 glass p-8 md:p-10 rounded-[2.5rem] shadow-2xl border border-amber-200/60">
<h2 class="text-2xl font-extrabold text-slate-900 mb-6 flex items-center justify-between">
    <span class="flex items-center gap-3">
        <span class="w-10 h-10 rounded-2xl bg-indigo-500 text-white grid place-items-center shadow-md shadow-indigo-500/30"><i class="fa-solid fa-tasks text-base"></i></span> My Tasks List
    </span>
    <span class="text-sm bg-amber-100 border border-amber-200 text-amber-800 px-4 py-1.5 rounded-full shadow-sm font-bold">Total: <?= count($tasks) ?></span>
</h2>
<div class="overflow-x-auto rounded-3xl border border-slate-200/80 shadow-sm bg-white/50">
<table class="w-full border-collapse">
<thead>
    <tr class="bg-gradient-to-r from-slate-900 to-slate-950 text-white text-left text-base">
        <th class="p-4 pl-6">Sr No</th>
        <th class="p-4">Title</th>
        <th class="p-4">Description</th>
        <th class="p-4">Status</th>
        <th class="p-4 pr-6">Action</th>
    </tr>
</thead>
<tbody class="text-base font-semibold">
<?php $i = 1; foreach($tasks as $t) { 
    $statusColor = 'bg-amber-500';
    if ($t['status'] === 'Completed') $statusColor = 'bg-emerald-600';
    if ($t['status'] === 'In Progress') $statusColor = 'bg-indigo-600';
?>
<tr class="border-b border-slate-100 hover:bg-amber-50/40 transition">
    <td class="p-4 pl-6 text-slate-500"><?= $i++ ?></td>
    <td class="p-4 font-bold text-slate-900"><?= htmlspecialchars($t['title']) ?></td>
    <td class="p-4 text-slate-600 max-w-xs truncate"><?= htmlspecialchars($t['description']) ?></td>
    <td class="p-4"><span class="px-3.5 py-1.5 rounded-full text-xs font-bold text-white shadow-sm <?= $statusColor ?>"><?= htmlspecialchars($t['status']) ?></span></td>
    <td class="p-4 pr-6 flex gap-2">
        <button onclick="openEdit('<?= $t['task_id'] ?>','<?= htmlspecialchars(addslashes($t['title'])) ?>','<?= htmlspecialchars(addslashes($t['description'])) ?>','<?= htmlspecialchars($t['status']) ?>')" class="bg-amber-500 text-white px-3.5 py-2 rounded-full hover:bg-amber-600 text-sm font-bold flex items-center gap-1 shadow-md shadow-amber-500/20 transition hover:scale-105"><i class="fa-solid fa-pen"></i> Edit</button>
        <a href="?delete=<?= $t['task_id'] ?>" onclick="return confirm('Are you sure you want to delete this task?')" class="bg-rose-500 text-white px-3.5 py-2 rounded-full hover:bg-rose-600 text-sm font-bold flex items-center gap-1 shadow-md shadow-rose-500/20 transition hover:scale-105"><i class="fa-solid fa-trash"></i> Delete</a>
    </td>
</tr>
<?php } if (count($tasks) == 0) { echo "<tr><td colspan='5' class='p-12 text-center text-slate-400 text-base'><i class='fa-solid fa-inbox text-3xl mb-2 block text-amber-400'></i>No tasks found. Create your first task above!</td></tr>"; } ?>
</tbody></table>
</div>
</div>

<!-- EDIT MODAL -->
<div id="editModal" class="hidden fixed inset-0 bg-slate-950/60 backdrop-blur-md flex items-center justify-center z-50 p-4">
<div class="glass bg-white w-full max-w-lg p-8 rounded-[2.5rem] shadow-2xl border border-amber-200">
<h2 class="text-2xl font-extrabold text-slate-900 mb-6 flex items-center gap-3"><span class="w-10 h-10 rounded-2xl bg-amber-500 text-white grid place-items-center shadow-md"><i class="fa-solid fa-pen-to-square"></i></span> Edit Task</h2>
<form method="POST" class="space-y-4">
<input type="hidden" name="task_id" id="e_id">
<div>
    <label class="block text-sm font-bold text-slate-600 mb-1">Task Title</label>
    <input name="title" id="e_title" class="w-full border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-amber-500 outline-none text-base font-semibold shadow-sm" required>
</div>
<div>
    <label class="block text-sm font-bold text-slate-600 mb-1">Status</label>
    <select name="status" id="e_status" class="w-full border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-amber-500 outline-none text-base font-semibold shadow-sm" required>
        <option value="Pending">Pending</option>
        <option value="In Progress">In Progress</option>
        <option value="Completed">Completed</option>
    </select>
</div>
<div>
    <label class="block text-sm font-bold text-slate-600 mb-1">Task Description</label>
    <textarea name="description" id="e_desc" class="w-full border border-slate-200 p-3.5 rounded-2xl bg-white/90 focus:ring-2 focus:ring-amber-500 outline-none text-base h-24 font-semibold shadow-sm" placeholder="Task Description..."></textarea>
</div>
<button name="update_task" class="bg-gradient-to-r from-amber-500 to-amber-600 text-white w-full py-4 rounded-full hover:from-amber-600 hover:to-amber-700 shadow-xl shadow-amber-500/25 flex items-center justify-center gap-2 text-base font-bold transition-all"><i class="fa-solid fa-check"></i> Update Task</button>
</form>
<button onclick="closeEdit()" class="mt-3 w-full text-slate-500 text-base font-bold hover:text-slate-700 py-2"><i class="fa-solid fa-xmark mr-1"></i> Close</button>
</div>
</div>

<script>
function openEdit(id, title, desc, status) {
    document.getElementById("editModal").classList.remove("hidden");
    document.getElementById("e_id").value = id;
    document.getElementById("e_title").value = title;
    document.getElementById("e_desc").value = desc;
    document.getElementById("e_status").value = status;
}

function closeEdit() {
    document.getElementById("editModal").classList.add("hidden");
}
</script>
</body>
</html>