<?php
session_start();
include "includes/header.php";
?>

<!-- GOOGLE FONT: PLAYFAIR DISPLAY INJECTION -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">

<style>
.font-playfair {
    font-family: "Playfair Display", serif;
    font-optical-sizing: auto;
}
</style>

<!-- AMBIENT BACKGROUND GLOW EFFECTS -->
<div class="absolute top-10 left-1/2 -translate-x-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-blue-400/20 via-indigo-400/15 to-purple-400/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>

<!-- UNIQUE LUXURY MARQUEE CAROUSEL -->
<div class="relative max-w-7xl mx-auto mb-16 pt-6">
<div class="relative rounded-[2.5rem] overflow-hidden border border-slate-200/60 shadow-2xl bg-white/80 backdrop-blur-2xl p-6">
<div class="flex items-center justify-between mb-5 px-3">
<div class="flex items-center gap-2.5 text-xs font-bold uppercase tracking-wider text-blue-600">
<span class="w-2.5 h-2.5 rounded-full bg-blue-600 animate-ping"></span> Curated Workflows
</div>
<span class="text-xs text-slate-400 font-medium tracking-wide">Explore Features & Capabilities</span>
</div>

<div class="relative overflow-hidden w-full">
<button id="marqueePrev" class="absolute left-3 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-2xl bg-white/95 border border-slate-200/80 shadow-2xl grid place-items-center text-slate-700 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all duration-300"><i class="fa-solid fa-chevron-left text-sm"></i></button>
<button id="marqueeNext" class="absolute right-3 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-2xl bg-white/95 border border-slate-200/80 shadow-2xl grid place-items-center text-slate-700 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all duration-300"><i class="fa-solid fa-chevron-right text-sm"></i></button>

<div id="marqueeWrapper" class="flex gap-6 overflow-x-auto hide-scrollbar scroll-smooth py-3 px-2">
<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-blue-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-code"></i></div> Clean Code Architecture
</div>
</div>

<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-indigo-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-users"></i></div> Team Synchronization
</div>
</div>

<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-emerald-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-chart-line"></i></div> Strategic Growth
</div>
</div>

<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-violet-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-laptop-code"></i></div> Remote Hubs
</div>
</div>

<div class="relative min-w-[360px] h-56 rounded-3xl overflow-hidden shrink-0 shadow-xl group/card border border-slate-100 bg-slate-900">
<img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800" class="w-full h-full object-cover group-hover/card:scale-110 transition duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent"></div>
<div class="absolute bottom-5 left-5 right-5 text-white font-bold text-lg font-playfair flex items-center gap-3">
<div class="w-9 h-9 rounded-xl bg-amber-600/90 backdrop-blur-md grid place-items-center text-sm shadow-md"><i class="fa-solid fa-bullseye"></i></div> Goal Achievement
</div>
</div>
</div>
</div>
</div>
</div>

<script>
const wrapper = document.getElementById('marqueeWrapper');
const cardWidth = 384; 
let autoScroll = setInterval(() => {
    wrapper.scrollBy({ left: 1.5, behavior: 'smooth' });
    if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) {
        wrapper.scrollTo({ left: 0, behavior: 'smooth' });
    }
}, 30);

document.getElementById('marqueePrev').onclick = () => wrapper.scrollBy({ left: -cardWidth, behavior: 'smooth' });
document.getElementById('marqueeNext').onclick = () => wrapper.scrollBy({ left: cardWidth, behavior: 'smooth' });

wrapper.addEventListener('mouseenter', () => clearInterval(autoScroll));
wrapper.addEventListener('mouseleave', () => {
    autoScroll = setInterval(() => {
        wrapper.scrollBy({ left: 1.5, behavior: 'smooth' });
        if (wrapper.scrollLeft + wrapper.clientWidth >= wrapper.scrollWidth - 5) {
            wrapper.scrollTo({ left: 0, behavior: 'smooth' });
        }
    }, 30);
});
</script>

<!-- HERO SECTION -->
<div class="grid md:grid-cols-2 gap-12 items-center py-10">
<div class="space-y-6">
<div class="inline-flex items-center gap-2.5 px-4 py-2 rounded-full bg-blue-50/80 border border-blue-200/60 text-blue-700 text-xs font-bold uppercase tracking-wider shadow-sm">
<i class="fa-solid fa-sparkles text-blue-600"></i> WorkWave Ecosystem
</div>
<h1 class="text-4xl md:text-6xl font-black text-slate-900 tracking-tight leading-[1.15] font-playfair">
Organize Your Day, <br><span class="bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 bg-clip-text text-transparent italic">Master Your Workflow.</span>
</h1>
<p class="text-slate-600 text-lg leading-relaxed font-normal">
WorkWave empowers modern teams and forward-thinking individuals to streamline daily tasks, track execution metrics, and accomplish extraordinary goals with luxury simplicity.
</p>
<div class="flex flex-wrap gap-4 pt-4">
<?php if(isset($_SESSION['user_id'])): ?>
<a href="dashboard.php" class="px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl shadow-xl shadow-blue-500/30 hover:opacity-95 font-bold text-base flex items-center gap-3 transition-all transform hover:-translate-y-1">
<i class="fa-solid fa-gauge-high"></i> Go to Dashboard
</a>
<?php else: ?>
<button onclick="openRegister()" class="px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl shadow-xl shadow-blue-500/30 hover:opacity-95 font-bold text-base flex items-center gap-3 transition-all transform hover:-translate-y-1">
<i class="fa-solid fa-rocket"></i> Get Started Free
</button>
<button onclick="openLogin()" class="px-8 py-4 bg-white/90 border border-slate-200 text-slate-800 rounded-2xl shadow-xl shadow-slate-200/50 hover:bg-slate-50 font-bold text-base flex items-center gap-3 transition-all transform hover:-translate-y-1">
<i class="fa-solid fa-right-to-bracket text-blue-600"></i> Sign In
</button>
<?php endif; ?>
</div>
</div>

<div class="relative">
<div class="absolute -inset-3 bg-gradient-to-r from-blue-600/30 to-indigo-600/30 rounded-[2.5rem] blur-2xl opacity-40"></div>
<div class="relative rounded-[2.5rem] p-6 shadow-2xl border border-white/90 bg-white/90 backdrop-blur-2xl">
<img src="https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&q=80&w=1000" alt="Workspace" class="w-full h-80 object-cover rounded-3xl shadow-lg border border-slate-100 bg-slate-900">
<div class="mt-6 grid grid-cols-3 gap-4 text-center">
<div class="bg-gradient-to-b from-slate-50 to-slate-100/80 p-4 rounded-2xl border border-slate-200/60 shadow-inner">
<h3 class="text-2xl font-black text-blue-600 font-playfair">100%</h3>
<p class="text-xs text-slate-500 font-semibold mt-1">Productivity</p>
</div>
<div class="bg-gradient-to-b from-slate-50 to-slate-100/80 p-4 rounded-2xl border border-slate-200/60 shadow-inner">
<h3 class="text-2xl font-black text-indigo-600 font-playfair">24/7</h3>
<p class="text-xs text-slate-500 font-semibold mt-1">Live Access</p>
</div>
<div class="bg-gradient-to-b from-slate-50 to-slate-100/80 p-4 rounded-2xl border border-slate-200/60 shadow-inner">
<h3 class="text-2xl font-black text-emerald-600 font-playfair">Secure</h3>
<p class="text-xs text-slate-500 font-semibold mt-1">Workspace</p>
</div>
</div>
</div>
</div>
</div>

<!-- FEATURES GRID -->
<div class="mt-28 mb-16">
<div class="text-center max-w-2xl mx-auto mb-16">
<div class="inline-block text-xs font-bold uppercase tracking-widest text-blue-600 bg-blue-50 border border-blue-100 px-4 py-1.5 rounded-full mb-3 shadow-sm">Core Capabilities</div>
<h2 class="text-3xl md:text-5xl font-black text-slate-900 tracking-tight font-playfair">Designed for Peak Performance</h2>
<p class="text-slate-600 text-base md:text-lg mt-4 font-normal">Everything you need to keep your daily projects completely organized, targeted, and under full control.</p>
</div>

<div class="grid md:grid-cols-3 gap-8">
<div class="p-8 rounded-[2.5rem] shadow-xl border border-slate-200/60 bg-white/90 backdrop-blur-2xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl group">
<div class="w-16 h-16 bg-blue-50 border border-blue-100 rounded-2xl grid place-items-center text-blue-600 text-2xl mb-6 shadow-md group-hover:scale-110 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300"><i class="fa-solid fa-bolt"></i></div>
<h3 class="text-2xl font-bold text-slate-900 mb-3 font-playfair">Lightning Fast Tasks</h3>
<p class="text-slate-600 text-base leading-relaxed">Add, modify, or strike through tasks instantly with our ultra-responsive state-of-the-art interface.</p>
</div>

<div class="p-8 rounded-[2.5rem] shadow-xl border border-slate-200/60 bg-white/90 backdrop-blur-2xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl group">
<div class="w-16 h-16 bg-indigo-50 border border-indigo-100 rounded-2xl grid place-items-center text-indigo-600 text-2xl mb-6 shadow-md group-hover:scale-110 group-hover:bg-indigo-600 group-hover:text-white transition-all duration-300"><i class="fa-solid fa-shield-halved"></i></div>
<h3 class="text-2xl font-bold text-slate-900 mb-3 font-playfair">Secure Encryption</h3>
<p class="text-slate-600 text-base leading-relaxed">Your personal schedules and company workflows are protected using robust, enterprise-grade safety protocols.</p>
</div>

<div class="p-8 rounded-[2.5rem] shadow-xl border border-slate-200/60 bg-white/90 backdrop-blur-2xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl group">
<div class="w-16 h-16 bg-emerald-50 border border-emerald-100 rounded-2xl grid place-items-center text-emerald-600 text-2xl mb-6 shadow-md group-hover:scale-110 group-hover:bg-emerald-600 group-hover:text-white transition-all duration-300"><i class="fa-solid fa-chart-pie"></i></div>
<h3 class="text-2xl font-bold text-slate-900 mb-3 font-playfair">Live Status Trackers</h3>
<p class="text-slate-600 text-base leading-relaxed">Monitor pending, active, and completed deliverables seamlessly from your centralized control dashboard.</p>
</div>
</div>
</div>

<?php include "includes/footer.php"; ?>