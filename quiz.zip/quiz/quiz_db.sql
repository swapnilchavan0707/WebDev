CREATE DATABASE IF NOT EXISTS quiz_portal_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE quiz_portal_db;

-- 1. Admins Table - from manage_admins.php, index.php
CREATE TABLE admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  mobile_number VARCHAR(20) NOT NULL,
  alt_mobile_number VARCHAR(20) DEFAULT NULL,
  email VARCHAR(150) NOT NULL,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. Exams Table - from manage_exams.php
CREATE TABLE exams (
  id INT AUTO_INCREMENT PRIMARY KEY,
  topic_name VARCHAR(255) NOT NULL,
  total_questions INT NOT NULL,
  duration INT NOT NULL COMMENT 'in minutes',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. Questions Table - from add_questions.php
CREATE TABLE questions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  exam_id INT NOT NULL,
  question_text TEXT NOT NULL,
  option_a VARCHAR(500) NOT NULL,
  option_b VARCHAR(500) NOT NULL,
  option_c VARCHAR(500) NOT NULL,
  option_d VARCHAR(500) NOT NULL,
  correct_option ENUM('A','B','C','D') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 4. Results Table - from process_quiz.php, results.php, verify.php
CREATE TABLE results (
  id INT AUTO_INCREMENT PRIMARY KEY,
  exam_id_string VARCHAR(100) NOT NULL UNIQUE COMMENT 'EXAM-uniqid()',
  candidate_name VARCHAR(150) NOT NULL,
  exam_id INT NOT NULL,
  score INT NOT NULL DEFAULT 0,
  total_score INT NOT NULL,
  email VARCHAR(150) DEFAULT NULL,
  attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 5. Result Details Table - for question-wise review - from result.php
CREATE TABLE result_details (
  id INT AUTO_INCREMENT PRIMARY KEY,
  result_string_id VARCHAR(100) NOT NULL,
  question_id INT NOT NULL,
  selected_option VARCHAR(5) DEFAULT NULL,
  is_correct TINYINT(1) NOT NULL DEFAULT 0,
  FOREIGN KEY (result_string_id) REFERENCES results(exam_id_string) ON DELETE CASCADE,
  FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Create default admin: username = sysadmin, password = admin123
INSERT INTO admins (first_name, last_name, mobile_number, email, username, password)
VALUES ('System', 'Admin', '9876543210', 'admin@quizora.com', 'sysadmin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');