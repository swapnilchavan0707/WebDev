<?php
$host = 'localhost';
$db   = 'quiz_portal_db';
$user = 'root';
$pass = 'manager'; // For live server use strong password
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
     $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
     // Don't show real error to user in production
     error_log("DB Connection Error: " . $e->getMessage());
     
     // For development you can see error, for live show generic message
     die("Database connection failed. Please check config/db.php");
}
?>