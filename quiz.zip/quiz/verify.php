<?php
include 'config/db.php';
include 'includes/header.php';
$resultData = null;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $exam_id_string = trim($_POST['exam_id']);
    if (!empty($exam_id_string)) {
        $stmt = $pdo->prepare("SELECT r.*, e.topic_name FROM results r JOIN exams e ON r.exam_id = e.id WHERE r.exam_id_string =?");
        $stmt->execute([$exam_id_string]);
        $resultData = $stmt->fetch();
    }
}
?>
<section class="bg-slate-900 text-white py-16 rounded-b- text-center"><h1 class="text-5xl">Verify Your Exam Result</h1><p class="text-slate-400 mt-3 text-">Enter your Exam ID to check your result</p></section>

<div class="max-w-xl mx-auto mt-10 glass rounded- p-10 border border-white/70 shadow-xl">
<form method="POST" class="space-y-5">
<div><label class="text- text-slate-500">Enter Exam ID</label><input type="text" name="exam_id" placeholder="Example: EXAM-20260621153025124" class="mt-3 w-full px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" required></div>
<button type="submit" class="w-full py-4 rounded-full bg-slate-900 text-white hover:bg-black shadow-lg text-"><i class="fa-solid fa-magnifying-glass mr-2"></i> Verify Result</button>
</form>
</div>

<?php if ($resultData): $percentage = ($resultData['score'] / $resultData['total_score']) * 100; $status = ($percentage>=40)?"PASS":"FAIL";?>
<div class="max-w-xl mx-auto mt-8 glass rounded- p-8 border border-white/70 shadow-xl">
<h2 class="text-3xl text-center text-emerald-600">Result Found <i class="fa-solid fa-circle-check ml-2"></i></h2>
<div class="mt-6 space-y-3 text- text-slate-600">
<p><b class="text-slate-800">Candidate Name:</b> <?= htmlspecialchars($resultData['candidate_name'])?></p>
<p><b class="text-slate-800">Exam:</b> <?= htmlspecialchars($resultData['topic_name'])?></p>
<p><b class="text-slate-800">Exam ID:</b> <?= $resultData['exam_id_string']?></p>
<?php if (!empty($resultData['email'])):?><p><b class="text-slate-800">Email:</b> <?= htmlspecialchars($resultData['email'])?></p><?php endif;?>
<p><b class="text-slate-800">Score:</b> <?= $resultData['score']?> / <?= $resultData['total_score']?></p>
<p><b class="text-slate-800">Percentage:</b> <?= round($percentage,2)?>%</p>
<div class="mt-4 p-4 rounded-full text-center font-bold <?= $status=="PASS"?"bg-emerald-100 text-emerald-700":"bg-red-100 text-red-700"?>"><?php if($status=="PASS"):?><i class="fa-solid fa-check mr-2"></i> Passed<?php else:?><i class="fa-solid fa-xmark mr-2"></i> Failed<?php endif;?></div>
</div>
</div>
<?php elseif ($_SERVER["REQUEST_METHOD"] == "POST"):?>
<div class="max-w-xl mx-auto mt-8 glass rounded- p-8 border border-white/70 shadow-xl text-center"><h2 class="text-red-600 text-2xl">No Result Found <i class="fa-solid fa-circle-xmark ml-2"></i></h2><p class="text-slate-400 mt-2 text-">Please check your Exam ID and try again.</p></div>
<?php endif;?>
<?php include 'includes/footer.php';?>