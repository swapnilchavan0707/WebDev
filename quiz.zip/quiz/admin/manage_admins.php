<?php
session_start();
require_once '../config/db.php';
if (!isset($_SESSION['admin_logged_in'])) { header("Location: index.php"); exit; }
$success = ""; $error = "";
if (isset($_POST['add_admin'])) {
    $first_name = trim($_POST['first_name']); $last_name = trim($_POST['last_name']);
    $mobile = trim($_POST['mobile_number']); $alt_mobile = trim($_POST['alt_mobile_number']);
    $email = trim($_POST['email']); $username = trim($_POST['username']); $password = trim($_POST['password']);
    if ($first_name && $last_name && $mobile && $email && $username && $password) {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("INSERT INTO admins (first_name, last_name, mobile_number, alt_mobile_number, email, username, password) VALUES (?,?,?,?,?,?,?)");
        $stmt->execute([$first_name, $last_name, $mobile, $alt_mobile, $email, $username, $hashedPassword]);
        $success = "Admin added successfully!";
    } else { $error = "Please fill all required fields!"; }
}
if (isset($_GET['delete'])) { $stmt = $pdo->prepare("DELETE FROM admins WHERE id =?"); $stmt->execute([$_GET['delete']]); header("Location: manage_admins.php"); exit; }
$editAdmin = null;
if (isset($_GET['edit'])) { $stmt = $pdo->prepare("SELECT * FROM admins WHERE id =?"); $stmt->execute([$_GET['edit']]); $editAdmin = $stmt->fetch(); }
if (isset($_POST['update_admin'])) {
    $id = $_POST['id']; $new_password = trim($_POST['password']);
    if ($new_password!= "") {
        $hashedPassword = password_hash($new_password, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("UPDATE admins SET first_name=?, last_name=?, mobile_number=?, alt_mobile_number=?, email=?, username=?, password=? WHERE id=?");
        $stmt->execute([$_POST['first_name'], $_POST['last_name'], $_POST['mobile_number'], $_POST['alt_mobile_number'], $_POST['email'], $_POST['username'], $hashedPassword, $id]);
    } else {
        $stmt = $pdo->prepare("UPDATE admins SET first_name=?, last_name=?, mobile_number=?, alt_mobile_number=?, email=?, username=? WHERE id=?");
        $stmt->execute([$_POST['first_name'], $_POST['last_name'], $_POST['mobile_number'], $_POST['alt_mobile_number'], $_POST['email'], $_POST['username'], $id]);
    }
    header("Location: manage_admins.php"); exit;
}
$admins = $pdo->query("SELECT * FROM admins ORDER BY id ASC")->fetchAll();
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Manage Admins - Quizora</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Petit+Formal+Script&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>body,input,button,textarea,select,label,div,h1,h2,p,th,td,a{font-family:"Petit Formal Script",cursive;}::placeholder{font-family:"Petit Formal Script",cursive;opacity:0.5;}.fa,.fa-solid{font-family:"Font Awesome 6 Free"!important;font-weight:900!important;}.glass{background:rgba(255,255,255,0.85);backdrop-filter:blur(20px);}</style>
</head><body class="min-h-screen bg-[#fdfbf7]"><div class="fixed inset-0 -z-10"><div class="absolute inset-0 bg-gradient-to-br from-[#fffaf0] via-[#fff8f0] to-[#f7f0ff]"></div><div class="absolute top-[-10%] left-[15%] w- h- bg-[#ffe4c4]/40 rounded-full blur-"></div><div class="absolute bottom-[-10%] right-[5%] w- h- bg-[#e0c3ff]/35 rounded-full blur-"></div></div>
<div class="max-w-7xl mx-auto p-5 md:p-10">
<div class="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-10"><div><h1 class="text-5xl md:text-6xl text-slate-800"><?= $editAdmin? "Edit Admin" : "Manage Admins"?></h1><p class="mt-4 text- text-slate-500">Crafting excellence in administration - Quizora</p></div><a href="dashboard.php" class="flex items-center gap-3 px-7 py-3.5 rounded-full bg-slate-900 text-white hover:bg-black shadow-lg"><i class="fa-solid fa-arrow-left"></i> Dashboard</a></div>
<?php if ($success):?><div class="mb-7 px-6 py-4 rounded- bg-white border shadow-sm flex gap-3 text-emerald-700 text-"><i class="fa-solid fa-check"></i> <?= htmlspecialchars($success)?></div><?php endif;?>
<?php if ($error):?><div class="mb-7 px-6 py-4 rounded- bg-white border shadow-sm flex gap-3 text-red-700 text-"><i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($error)?></div><?php endif;?>
<div class="glass rounded- shadow-[0_30px_90px_-25px_rgba(0,0,0,0.15)] border border-white/80 p-8 md:p-11 mb-14">
<h2 class="text-4xl text-slate-800 mb-3"><?= $editAdmin? "Refine the Profile" : "Add New Curator"?></h2><p class="text- text-slate-400 mb-9"><?= $editAdmin? "Leave password empty to preserve the existing key" : "All fields marked with * are essential"?></p>
<form method="POST" class="grid md:grid-cols-3 gap-7">
<?php if ($editAdmin):?><input type="hidden" name="id" value="<?= $editAdmin['id']?>"><?php endif;?>
<label><span class="text- text-slate-500">First Name *</span><input type="text" name="first_name" value="<?= htmlspecialchars($editAdmin['first_name']?? '')?>" class="mt-2.5 w-full px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" placeholder="Elara" required></label>
<label><span class="text- text-slate-500">Last Name *</span><input type="text" name="last_name" value="<?= htmlspecialchars($editAdmin['last_name']?? '')?>" class="mt-2.5 w-full px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" placeholder="Rose" required></label>
<label><span class="text- text-slate-500">Mobile *</span><input type="text" name="mobile_number" value="<?= htmlspecialchars($editAdmin['mobile_number']?? '')?>" class="mt-2.5 w-full px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" placeholder="+91..." required></label>
<label><span class="text- text-slate-500">Alt Mobile</span><input type="text" name="alt_mobile_number" value="<?= htmlspecialchars($editAdmin['alt_mobile_number']?? '')?>" class="mt-2.5 w-full px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" placeholder="Optional"></label>
<label><span class="text- text-slate-500">Email *</span><input type="email" name="email" value="<?= htmlspecialchars($editAdmin['email']?? '')?>" class="mt-2.5 w-full px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" placeholder="elara@quizora.com" required></label>
<label><span class="text- text-slate-500">Username *</span><input type="text" name="username" value="<?= htmlspecialchars($editAdmin['username']?? '')?>" class="mt-2.5 w-full px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" placeholder="elara_rose" required></label>
<label class="md:col-span-3"><span class="text- text-slate-500">Password <?= $editAdmin? '' : '*'?></span><div class="relative mt-2.5"><input type="password" id="pass" name="password" placeholder="<?= $editAdmin? 'Keep blank to retain old' : 'Create a secure password'?>" class="w-full px-5 py-4 pr-14 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" <?= $editAdmin? '' : 'required'?>><button type="button" onclick="let i=document.getElementById('pass'); i.type=i.type==='password'?'text':'password'; this.innerHTML=i.type==='password'?'<i class=\'fa-solid fa-eye\'></i>':'<i class=\'fa-solid fa-eye-slash\'></i>'" class="absolute right-2 top-1/2 -translate-y-1/2 w-11 h-11 rounded-xl bg-stone-50 grid place-items-center text-stone-500"><i class="fa-solid fa-eye"></i></button></div></label>
<div class="md:col-span-3 flex gap-4 mt-3"><button name="<?= $editAdmin? 'update_admin' : 'add_admin'?>" class="flex-1 py-4 rounded-2xl bg-slate-900 text-white text- hover:bg-black shadow-lg"><?= $editAdmin? "Update Admin" : "Add to Collection"?></button><?php if($editAdmin):?><a href="manage_admins.php" class="px-9 py-4 rounded-2xl bg-white border text-">Cancel</a><?php endif;?></div>
</form></div>
<div class="glass rounded- shadow-xl border border-white/80 overflow-hidden"><div class="p-8 md:p-10"><h2 class="text-4xl">Our Admins</h2><p class="text- text-slate-400 mt-3"><?= count($admins)?> curators</p></div><div class="overflow-x-auto px-3 md:px-5 pb-7"><table class="w-full"><thead><tr class="text- text-slate-400 border-b"><th class="py-4 px-6 text-left">No.</th><th class="py-4 px-6 text-left">Identity</th><th class="py-4 px-6 text-left">Username</th><th class="py-4 px-6 text-left">Mobile</th><th class="py-4 px-6 text-center">Actions</th></tr></thead><tbody><?php $sr=1; foreach($admins as $admin):?><tr class="border-b border-stone-50 hover:bg-white/70"><td class="py-6 px-6 text-"><?= $sr++?></td><td class="py-6 px-6"><div class="flex items-center gap-4"><div class="w-12 h-12 rounded-full bg-amber-100 grid place-items-center"><?= strtoupper(substr($admin['first_name'],0,1).substr($admin['last_name'],0,1))?></div><div><div class="text-"><?= htmlspecialchars($admin['first_name']." ".$admin['last_name'])?></div><div class="text- text-slate-400"><?= htmlspecialchars($admin['email'])?></div></div></div></td><td class="py-6 px-6 text-">@<?= htmlspecialchars($admin['username'])?></td><td class="py-6 px-6 text-"><?= htmlspecialchars($admin['mobile_number'])?></td><td class="py-6 px-6"><div class="flex justify-center gap-2"><a href="?edit=<?= $admin['id']?>" class="w-10 h-10 rounded-full bg-white border shadow-sm grid place-items-center hover:bg-slate-900 hover:text-white"><i class="fa-solid fa-pen"></i></a><a href="?delete=<?= $admin['id']?>" onclick="return confirm('Delete this admin?')" class="w-10 h-10 rounded-full bg-white border shadow-sm grid place-items-center hover:bg-red-500 hover:text-white"><i class="fa-solid fa-trash"></i></a></div></td></tr><?php endforeach;?></tbody></table></div></div></div></body></html>