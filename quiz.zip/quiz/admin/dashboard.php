<?php
session_start();
require_once '../config/db.php';
if (!isset($_SESSION['admin_logged_in'])) { header("Location: index.php"); exit; }
$totalAdmins = $pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();
$totalExams = $pdo->query("SELECT COUNT(*) FROM exams")->fetchColumn();
$totalQuestions = $pdo->query("SELECT COUNT(*) FROM questions")->fetchColumn();
$totalResults = $pdo->query("SELECT COUNT(*) FROM results")->fetchColumn();
$adminName = $_SESSION['admin_name']?? $_SESSION['admin_username']?? 'Admin';
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Dashboard - Quizora</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Petit+Formal+Script&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>body,div,h1,h2,h3,p,a,span{font-family:"Petit Formal Script",cursive;}.fa,.fa-solid{font-family:"Font Awesome 6 Free"!important;font-weight:900!important;}.glass{background:rgba(255,255,255,0.85);backdrop-filter:blur(20px);}</style>
</head><body class="min-h-screen bg-[#fdfbf7]"><div class="fixed inset-0 -z-10"><div class="absolute inset-0 bg-gradient-to-br from-[#fffaf0] via-[#fff8f0] to-[#f7f0ff]"></div><div class="absolute top-[-10%] left-[15%] w- h- bg-[#ffe4c4]/30 rounded-full blur-"></div><div class="absolute bottom-[-10%] right-[10%] w- h- bg-[#e0c3ff]/30 rounded-full blur-"></div></div>
<div class="max-w-7xl mx-auto p-5 md:p-10">
<div class="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-12"><div><h1 class="text-5xl md:text-6xl text-slate-800">Welcome Admin</h1><p class="text- text-slate-400 mt-3"><i class="fa-solid fa-circle-user mr-2"></i> <?= htmlspecialchars($adminName)?> — Quizora Dashboard</p></div><a href="logout.php" class="px-7 py-3 rounded-full bg-slate-900 text-white hover:bg-black shadow-lg text-"><i class="fa-solid fa-right-from-bracket mr-2"></i> Logout</a></div>
<div class="grid md:grid-cols-4 gap-6 mb-12">
<div class="glass rounded- p-8 shadow-xl border border-white/70 hover:-translate-y-1 transition-all"><div class="w-12 h-12 rounded-2xl bg-amber-100 text-amber-600 grid place-items-center"><i class="fa-solid fa-users"></i></div><h3 class="text-5xl mt-6"><?= $totalAdmins?></h3><p class="text- text-slate-400 mt-2">Total Admins</p></div>
<div class="glass rounded- p-8 shadow-xl border border-white/70 hover:-translate-y-1 transition-all"><div class="w-12 h-12 rounded-2xl bg-purple-100 text-purple-600 grid place-items-center"><i class="fa-solid fa-book-open"></i></div><h3 class="text-5xl mt-6"><?= $totalExams?></h3><p class="text- text-slate-400 mt-2">Total Exams</p></div>
<div class="glass rounded- p-8 shadow-xl border border-white/70 hover:-translate-y-1 transition-all"><div class="w-12 h-12 rounded-2xl bg-blue-100 text-blue-600 grid place-items-center"><i class="fa-solid fa-circle-question"></i></div><h3 class="text-5xl mt-6"><?= $totalQuestions?></h3><p class="text- text-slate-400 mt-2">Total Questions</p></div>
<div class="glass rounded- p-8 shadow-xl border border-white/70 hover:-translate-y-1 transition-all"><div class="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-600 grid place-items-center"><i class="fa-solid fa-award"></i></div><h3 class="text-5xl mt-6"><?= $totalResults?></h3><p class="text- text-slate-400 mt-2">Total Results</p></div>
</div>
<div class="grid md:grid-cols-4 gap-6">
<a href="manage_admins.php" class="glass rounded- p-7 border border-white/70 shadow-sm hover:bg-white hover:-translate-y-1 transition-all"><i class="fa-solid fa-users text-xl text-slate-700"></i><span class="text- ml-3">Manage Admins</span></a>
<a href="manage_exams.php" class="glass rounded- p-7 border border-white/70 shadow-sm hover:bg-white hover:-translate-y-1 transition-all"><i class="fa-solid fa-file-pen text-xl text-slate-700"></i><span class="text- ml-3">Manage Exams</span></a>
<a href="add_questions.php" class="glass rounded- p-7 border border-white/70 shadow-sm hover:bg-white hover:-translate-y-1 transition-all"><i class="fa-solid fa-circle-plus text-xl text-slate-700"></i><span class="text- ml-3">Add Questions</span></a>
<a href="results.php" class="glass rounded- p-7 border border-white/70 shadow-sm hover:bg-white hover:-translate-y-1 transition-all"><i class="fa-solid fa-chart-line text-xl text-slate-700"></i><span class="text- ml-3">View Results</span></a>
</div>
</div></body></html>