<?php
session_start();
require_once '../config/db.php';
if (!isset($_SESSION['admin_logged_in'])) { header("Location: index.php"); exit; }
$search = ""; $results = [];
if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
    $stmt = $pdo->prepare("SELECT * FROM results WHERE exam_id_string LIKE? OR candidate_name LIKE? OR email LIKE? ORDER BY id ASC");
    $stmt->execute(["%$search%","%$search%","%$search%"]); $results = $stmt->fetchAll();
} else { $results = $pdo->query("SELECT * FROM results ORDER BY id ASC")->fetchAll(); }
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Results - Quizora</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Petit+Formal+Script&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>body,input,button,div,h1,p,th,td,a{font-family:"Petit Formal Script",cursive;}.fa,.fa-solid{font-family:"Font Awesome 6 Free"!important;font-weight:900!important;}.glass{background:rgba(255,255,255,0.85);backdrop-filter:blur(20px);}</style>
</head><body class="min-h-screen bg-[#fdfbf7]"><div class="fixed inset-0 -z-10"><div class="absolute inset-0 bg-gradient-to-br from-[#fffaf0] to-[#f7f0ff]"></div></div>
<div class="max-w-7xl mx-auto p-5 md:p-10">
<div class="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-10"><div><h1 class="text-5xl md:text-6xl">Exam Results</h1><p class="text- text-slate-400 mt-3"><?= count($results)?> records</p></div><a href="dashboard.php" class="px-7 py-3 rounded-full bg-slate-900 text-white hover:bg-black"><i class="fa-solid fa-arrow-left mr-2"></i> Dashboard</a></div>
<div class="glass rounded- p-6 shadow-lg border border-white/70 mb-8">
<form method="GET" class="flex gap-3"><input type="text" name="search" value="<?= htmlspecialchars($search)?>" placeholder="Search by Exam ID / Name / Email" class="flex-1 px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-"><button type="submit" class="px-8 py-4 rounded-2xl bg-slate-900 text-white hover:bg-black"><i class="fa-solid fa-search mr-2"></i> Search</button></form>
</div>
<div class="glass rounded- shadow-xl border border-white/80 overflow-hidden"><div class="overflow-x-auto"><table class="w-full"><thead><tr class="text- text-slate-400 border-b"><th class="p-4 text-left">Exam ID</th><th class="p-4 text-left">Candidate</th><th class="p-4 text-center">Score</th><th class="p-4 text-center">Total</th><th class="p-4 text-center">%</th><th class="p-4 text-center">Status</th><th class="p-4 text-left">Date</th></tr></thead><tbody>
<?php if(count($results)>0): foreach($results as $row): $percentage = $row['total_score']>0?($row['score']/$row['total_score'])*100:0;?>
<tr class="border-b border-stone-50 hover:bg-white/70"><td class="p-4 font-bold text-"><?= htmlspecialchars($row['exam_id_string'])?></td><td class="p-4 text-"><?= htmlspecialchars($row['candidate_name'])?></td><td class="p-4 text-center"><?= $row['score']?></td><td class="p-4 text-center"><?= $row['total_score']?></td><td class="p-4 text-center font-bold"><?= round($percentage,2)?>%</td><td class="p-4 text-center"><?php if($percentage>=40):?><span class="px-3 py-1 rounded-full bg-emerald-100 text-emerald-700 text-">Passed</span><?php else:?><span class="px-3 py-1 rounded-full bg-red-100 text-red-700 text-">Failed</span><?php endif;?></td><td class="p-4 text- text-slate-400"><?= $row['attempted_at']?></td></tr>
<?php endforeach; else:?><tr><td colspan="7" class="text-center p-10 text-slate-400 text-">No results found</td></tr><?php endif;?>
</tbody></table></div></div></div></body></html>