<?php
session_start();
require_once '../config/db.php';
if (!isset($_SESSION['admin_logged_in'])) { header("Location: index.php"); exit; }
if (isset($_POST['add_exam'])) {
    $topic_name = trim($_POST['topic_name']); $total_questions = intval($_POST['total_questions']); $duration = intval($_POST['duration']);
    if ($topic_name!= "" && $total_questions > 0) {
        $stmt = $pdo->prepare("INSERT INTO exams (topic_name, total_questions, duration) VALUES (?,?,?)");
        $stmt->execute([$topic_name, $total_questions, $duration]);
        echo "<script>alert('Exam Added Successfully');window.location.href='manage_exams.php';</script>"; exit;
    }
}
if (isset($_GET['delete'])) { $stmt = $pdo->prepare("DELETE FROM exams WHERE id =?"); $stmt->execute([$_GET['delete']]); echo "<script>alert('Exam Deleted');window.location.href='manage_exams.php';</script>"; exit; }
$exams = $pdo->query("SELECT * FROM exams ORDER BY id ASC")->fetchAll();
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Manage Exams - Quizora</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Petit+Formal+Script&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>body,input,button,div,h1,h2,p,th,td,a{font-family:"Petit Formal Script",cursive;}.fa,.fa-solid{font-family:"Font Awesome 6 Free"!important;font-weight:900!important;}.glass{background:rgba(255,255,255,0.85);backdrop-filter:blur(20px);}</style>
</head><body class="min-h-screen bg-[#fdfbf7]"><div class="fixed inset-0 -z-10"><div class="absolute inset-0 bg-gradient-to-br from-[#fffaf0] via-[#fff8f0] to-[#f7f0ff]"></div><div class="absolute top-[-10%] left-[15%] w- h- bg-[#ffe4c4]/40 rounded-full blur-"></div></div>
<div class="max-w-7xl mx-auto p-5 md:p-10">
<div class="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-10"><div><h1 class="text-5xl md:text-6xl text-slate-800">Manage Exams</h1><p class="text- text-slate-400 mt-3"><?= count($exams)?> exams crafted</p></div><a href="dashboard.php" class="flex items-center gap-3 px-7 py-3.5 rounded-full bg-slate-900 text-white hover:bg-black shadow-lg"><i class="fa-solid fa-arrow-left"></i> Dashboard</a></div>
<div class="glass rounded- p-8 md:p-10 shadow-xl border border-white/80 mb-12">
<h2 class="text-4xl mb-8">Add New Exam</h2>
<form method="POST" class="grid md:grid-cols-3 gap-6">
<input type="text" name="topic_name" placeholder="Topic Name" class="px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" required>
<input type="number" name="total_questions" placeholder="Total Questions" class="px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" required>
<input type="number" name="duration" placeholder="Duration (minutes)" class="px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" required>
<button type="submit" name="add_exam" class="md:col-span-3 py-4 rounded-2xl bg-slate-900 text-white text- hover:bg-black shadow-lg"><i class="fa-solid fa-plus mr-2"></i> Add Exam</button>
</form></div>
<div class="glass rounded- shadow-xl border border-white/80 overflow-hidden"><div class="p-8 md:p-10"><h2 class="text-4xl">All Exams</h2></div><div class="overflow-x-auto px-3 md:px-5 pb-7"><table class="w-full"><thead><tr class="text- text-slate-400 border-b"><th class="py-4 px-6 text-left">Topic</th><th class="py-4 px-6 text-center">Questions</th><th class="py-4 px-6 text-center">Duration</th><th class="py-4 px-6 text-center">Actions</th></tr></thead><tbody>
<?php foreach($exams as $exam):?><tr class="border-b border-stone-50 hover:bg-white/70"><td class="py-6 px-6 text- font-bold"><?= htmlspecialchars($exam['topic_name'])?></td><td class="py-6 px-6 text-center text-"><?= $exam['total_questions']?></td><td class="py-6 px-6 text-center text-"><?= $exam['duration']?> min</td><td class="py-6 px-6 flex justify-center gap-2"><a href="add_questions.php?exam_id=<?= $exam['id']?>" class="w-10 h-10 rounded-full bg-white border shadow-sm grid place-items-center hover:bg-slate-900 hover:text-white"><i class="fa-solid fa-plus"></i></a><a href="edit_exam.php?id=<?= $exam['id']?>" class="w-10 h-10 rounded-full bg-white border shadow-sm grid place-items-center hover:bg-slate-900 hover:text-white"><i class="fa-solid fa-pen"></i></a><a href="?delete=<?= $exam['id']?>" onclick="return confirm('Are you sure?')" class="w-10 h-10 rounded-full bg-white border shadow-sm grid place-items-center hover:bg-red-500 hover:text-white"><i class="fa-solid fa-trash"></i></a></td></tr><?php endforeach;?>
</tbody></table></div></div></div></body></html>