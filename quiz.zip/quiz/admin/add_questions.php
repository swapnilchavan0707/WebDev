<?php
session_start();
require_once '../config/db.php';
if (!isset($_SESSION['admin_logged_in'])) { header("Location: index.php"); exit; }
$selected_exam = $_GET['exam_id']?? null;
$edit_question = null;
if (isset($_GET['edit'])) { $stmt = $pdo->prepare("SELECT * FROM questions WHERE id =?"); $stmt->execute([$_GET['edit']]); $edit_question = $stmt->fetch(); }
if (isset($_POST['add_question'])) {
    $exam_id = $_POST['exam_id']; $question_text = trim($_POST['question_text']); $option_a = trim($_POST['option_a']); $option_b = trim($_POST['option_b']); $option_c = trim($_POST['option_c']); $option_d = trim($_POST['option_d']); $correct_option = $_POST['correct_option'];
    if ($exam_id && $question_text!= "") { $stmt = $pdo->prepare("INSERT INTO questions (exam_id, question_text, option_a, option_b, option_c, option_d, correct_option) VALUES (?,?,?,?,?,?,?)"); $stmt->execute([$exam_id,$question_text,$option_a,$option_b,$option_c,$option_d,$correct_option]); echo "<script>alert('Question Added Successfully');window.location.href='add_questions.php?exam_id=$exam_id';</script>"; exit; }
}
if (isset($_POST['update_question'])) {
    $exam_id = $_POST['exam_id']; $id = $_POST['question_id']; $question_text = trim($_POST['question_text']); $option_a = trim($_POST['option_a']); $option_b = trim($_POST['option_b']); $option_c = trim($_POST['option_c']); $option_d = trim($_POST['option_d']); $correct_option = $_POST['correct_option'];
    $stmt = $pdo->prepare("UPDATE questions SET question_text=?, option_a=?, option_b=?, option_c=?, option_d=?, correct_option=? WHERE id=?"); $stmt->execute([$question_text,$option_a,$option_b,$option_c,$option_d,$correct_option,$id]);
    echo "<script>alert('Question Updated Successfully');window.location.href='add_questions.php?exam_id=$exam_id';</script>"; exit;
}
if (isset($_GET['delete'])) { $id = $_GET['delete']; $exam_id = $_GET['exam_id']; $stmt = $pdo->prepare("DELETE FROM questions WHERE id =?"); $stmt->execute([$id]); echo "<script>alert('Question Deleted');window.location.href='add_questions.php?exam_id=$exam_id';</script>"; exit; }
$exams = $pdo->query("SELECT * FROM exams ORDER BY id ASC")->fetchAll();
$questions = []; if ($selected_exam) { $stmt = $pdo->prepare("SELECT * FROM questions WHERE exam_id =? ORDER BY id ASC"); $stmt->execute([$selected_exam]); $questions = $stmt->fetchAll(); }
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Add Questions - Quizora</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Petit+Formal+Script&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>body,input,button,textarea,select,div,h1,h2,h3,p,a,ul,li{font-family:"Petit Formal Script",cursive;}.fa,.fa-solid{font-family:"Font Awesome 6 Free"!important;font-weight:900!important;}.glass{background:rgba(255,255,255,0.85);backdrop-filter:blur(20px);}</style>
</head><body class="min-h-screen bg-[#fdfbf7]"><div class="fixed inset-0 -z-10"><div class="absolute inset-0 bg-gradient-to-br from-[#fffaf0] to-[#f7f0ff]"></div></div>
<div class="max-w-6xl mx-auto p-5 md:p-10">
<div class="flex justify-between items-end mb-10"><div><h1 class="text-5xl md:text-6xl">Add Questions</h1><p class="text- text-slate-400 mt-3">Craft questions with elegance</p></div><a href="manage_exams.php" class="px-7 py-3 rounded-full bg-slate-900 text-white hover:bg-black"><i class="fa-solid fa-arrow-left mr-2"></i> Back</a></div>
<div class="glass rounded- p-8 shadow-lg border border-white/70 mb-8">
<form method="GET"><label class="text- text-slate-500">Select Exam</label><select name="exam_id" class="w-full mt-3 px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" onchange="this.form.submit()" required><option value="">-- Select Exam --</option><?php foreach($exams as $exam):?><option value="<?= $exam['id']?>" <?= ($selected_exam==$exam['id'])?'selected':''?>><?= htmlspecialchars($exam['topic_name'])?></option><?php endforeach;?></select></form>
</div>
<?php if($selected_exam):?>
<div class="glass rounded- p-8 md:p-10 shadow-xl border border-white/70 mb-10">
<h2 class="text-3xl mb-6"><?= $edit_question? "Edit Question" : "Add New Question"?></h2>
<form method="POST" class="space-y-6">
<input type="hidden" name="exam_id" value="<?= $selected_exam?>"><?php if($edit_question):?><input type="hidden" name="question_id" value="<?= $edit_question['id']?>"><?php endif;?>
<textarea name="question_text" class="w-full px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text- min-h-" placeholder="Enter your question here..." required><?= $edit_question['question_text']?? ''?></textarea>
<div class="grid md:grid-cols-2 gap-5">
<input type="text" name="option_a" placeholder="Option A" class="px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" value="<?= htmlspecialchars($edit_question['option_a']?? '')?>" required>
<input type="text" name="option_b" placeholder="Option B" class="px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" value="<?= htmlspecialchars($edit_question['option_b']?? '')?>" required>
<input type="text" name="option_c" placeholder="Option C" class="px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" value="<?= htmlspecialchars($edit_question['option_c']?? '')?>" required>
<input type="text" name="option_d" placeholder="Option D" class="px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" value="<?= htmlspecialchars($edit_question['option_d']?? '')?>" required>
</div>
<select name="correct_option" class="w-full px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" required><option value="">Select Correct Answer</option><option value="A" <?= (($edit_question['correct_option']?? '')=='A')?'selected':''?>>Option A</option><option value="B" <?= (($edit_question['correct_option']?? '')=='B')?'selected':''?>>Option B</option><option value="C" <?= (($edit_question['correct_option']?? '')=='C')?'selected':''?>>Option C</option><option value="D" <?= (($edit_question['correct_option']?? '')=='D')?'selected':''?>>Option D</option></select>
<button type="submit" name="<?= $edit_question? 'update_question' : 'add_question'?>" class="w-full py-4 rounded-2xl bg-slate-900 text-white text- hover:bg-black shadow-lg"><?= $edit_question? "Update Question" : "Add Question"?></button>
</form></div>
<div class="glass rounded- p-8 shadow-lg border border-white/70">
<h2 class="text-3xl mb-6">Questions List - <?= count($questions)?></h2>
<?php if(count($questions)>0): foreach($questions as $index=>$q):?>
<div class="border border-stone-100 p-6 mb-5 rounded- bg-white/60 hover:bg-white transition-all">
<h3 class="text- font-bold mb-3">Q<?= $index+1?>. <?= htmlspecialchars($q['question_text'])?></h3>
<ul class="ml-4 text- text-slate-600 space-y-1"><li>A: <?= htmlspecialchars($q['option_a'])?></li><li>B: <?= htmlspecialchars($q['option_b'])?></li><li>C: <?= htmlspecialchars($q['option_c'])?></li><li>D: <?= htmlspecialchars($q['option_d'])?></li></ul>
<p class="mt-3 text-emerald-600 text-"><i class="fa-solid fa-check mr-2"></i> Correct: <?= $q['correct_option']?></p>
<div class="mt-4 flex gap-2"><a href="add_questions.php?exam_id=<?= $selected_exam?>&edit=<?= $q['id']?>" class="px-4 py-2 rounded-full bg-white border shadow-sm text- hover:bg-slate-900 hover:text-white"><i class="fa-solid fa-pen mr-1"></i> Edit</a><a href="?delete=<?= $q['id']?>&exam_id=<?= $selected_exam?>" onclick="return confirm('Delete this question?')" class="px-4 py-2 rounded-full bg-white border shadow-sm text- hover:bg-red-500 hover:text-white"><i class="fa-solid fa-trash mr-1"></i> Delete</a></div>
</div>
<?php endforeach; else:?><p class="text-slate-400 text-">No questions added yet.</p><?php endif;?>
</div>
<?php endif;?>
</div></body></html>