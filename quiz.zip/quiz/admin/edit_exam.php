<?php
session_start();
require_once '../config/db.php';
if (!isset($_SESSION['admin_logged_in'])) { header("Location: index.php"); exit; }
$id = $_GET['id']?? null;
if (!$id) { echo "<script>alert('Invalid Exam ID');window.location.href='manage_exams.php';</script>"; exit; }
$stmt = $pdo->prepare("SELECT * FROM exams WHERE id =?"); $stmt->execute([$id]); $exam = $stmt->fetch();
if (!$exam) { echo "<script>alert('Exam not found');window.location.href='manage_exams.php';</script>"; exit; }
if (isset($_POST['update_exam'])) {
    $topic_name = trim($_POST['topic_name']); $total_questions = intval($_POST['total_questions']); $duration = intval($_POST['duration']);
    if ($topic_name!= "" && $total_questions > 0) {
        $stmt = $pdo->prepare("UPDATE exams SET topic_name =?, total_questions =?, duration =? WHERE id =?");
        $stmt->execute([$topic_name, $total_questions, $duration, $id]);
        echo "<script>alert('Exam Updated Successfully');window.location.href='manage_exams.php';</script>"; exit;
    }
}
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Edit Exam - Quizora</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Petit+Formal+Script&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>body,input,button,div,h1,label,a{font-family:"Petit Formal Script",cursive;}.fa,.fa-solid{font-family:"Font Awesome 6 Free"!important;font-weight:900!important;}.glass{background:rgba(255,255,255,0.85);backdrop-filter:blur(20px);}</style>
</head><body class="min-h-screen bg-[#fdfbf7]"><div class="fixed inset-0 -z-10"><div class="absolute inset-0 bg-gradient-to-br from-[#fffaf0] to-[#f7f0ff]"></div></div>
<div class="max-w-3xl mx-auto p-6 md:p-10"><h1 class="text-5xl md:text-6xl mb-10">Edit Exam</h1>
<div class="glass rounded- p-8 md:p-10 shadow-xl border border-white/80">
<form method="POST" class="space-y-7">
<div><label class="text- text-slate-500">Topic Name</label><input type="text" name="topic_name" value="<?= htmlspecialchars($exam['topic_name'])?>" class="mt-3 w-full px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" required></div>
<div><label class="text- text-slate-500">Total Questions</label><input type="number" name="total_questions" value="<?= $exam['total_questions']?>" class="mt-3 w-full px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" required></div>
<div><label class="text- text-slate-500">Duration (Minutes)</label><input type="number" name="duration" value="<?= $exam['duration']?>" class="mt-3 w-full px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" required></div>
<div class="flex gap-3 pt-3"><button type="submit" name="update_exam" class="flex-1 py-4 rounded-2xl bg-slate-900 text-white text- hover:bg-black shadow-lg"><i class="fa-solid fa-check mr-2"></i> Update Exam</button><a href="manage_exams.php" class="px-8 py-4 rounded-2xl bg-white border text-">Cancel</a></div>
</form></div></div></body></html>