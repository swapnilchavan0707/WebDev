<?php
session_start();
require_once '../config/db.php';
$error = "";
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: dashboard.php"); exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    if ($username!== "" && $password!== "") {
        $stmt = $pdo->prepare("SELECT * FROM admins WHERE username =? LIMIT 1");
        $stmt->execute([$username]);
        $admin = $stmt->fetch();
        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            $_SESSION['admin_name'] = $admin['first_name']." ".$admin['last_name'];
            header("Location: dashboard.php"); exit;
        } else { $error = "Invalid username or password!"; }
    } else { $error = "Please fill in all fields!"; }
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><title>Quizora Admin Login</title><meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Petit+Formal+Script&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
  body, input, button, h1, p, a, div, label { font-family: "Petit Formal Script", cursive; }
  ::placeholder { font-family: "Petit Formal Script", cursive; opacity:0.5; }
 .fa,.fa-solid,.fa-regular{font-family:"Font Awesome 6 Free"!important;}.fa-solid{font-weight:900!important;}.fa-regular{font-weight:400!important;}
 .glass{background:rgba(255,255,255,0.85);backdrop-filter:blur(20px);}
</style></head>
<body class="min-h-screen bg-[#fdfbf7] flex items-center justify-center p-6">
<div class="fixed inset-0 -z-10"><div class="absolute inset-0 bg-gradient-to-br from-[#fffaf0] via-[#fff8f0] to-[#f7f0ff]"></div><div class="absolute top-[-10%] left-[15%] w- h- bg-[#ffe4c4]/40 rounded-full blur-"></div><div class="absolute bottom-[-10%] right-[5%] w- h- bg-[#e0c3ff]/35 rounded-full blur-"></div></div>
<div class="glass w-full max-w-md p-10 rounded- shadow-[0_30px_90px_-25px_rgba(0,0,0,0.15)] border border-white/80">
<div class="text-center mb-8"><div class="bg-slate-900 text-white w-14 h-14 mx-auto flex items-center justify-center rounded-2xl shadow-lg"><i class="fa-solid fa-user-shield text-xl"></i></div><h1 class="text-4xl mt-6">Quizora Admin</h1><p class="text-slate-400 mt-2 text-">Secure Login Panel</p></div>
<?php if (!empty($error)):?><div class="bg-red-50 text-red-600 border border-red-100 p-4 rounded-2xl mb-6 text-center text-"><?= htmlspecialchars($error)?></div><?php endif;?>
<form method="POST" class="space-y-6"><div><label class="text- text-slate-500">Username</label><input type="text" name="username" required class="mt-2 w-full px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-"></div><div><label class="text- text-slate-500">Password</label><input type="password" name="password" required class="mt-2 w-full px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-"></div><button type="submit" class="w-full py-4 rounded-2xl bg-slate-900 text-white text- hover:bg-black shadow-lg"><i class="fa-solid fa-right-to-bracket mr-2"></i> Login</button></form>
<p class="text-center mt-8 text- text-slate-400"><a href="../index.php" class="hover:text-slate-600"><i class="fa-solid fa-arrow-left mr-1"></i> Back to Website</a></p>
</div></body></html>