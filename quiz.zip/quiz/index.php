<?php include 'includes/header.php';?>

<style>
  @keyframes marquee {
    0% { transform: translateX(0); }
    100% { transform: translateX(-50%); }
  }
 .marquee-track {
    display: flex;
    width: max-content;
    animation: marquee 35s linear infinite;
  }
 .marquee-track:hover {
    animation-play-state: paused;
  }
</style>

<!-- MARQUEE SLIDER JUST BELOW NAVBAR WITH FANCY BUTTONS -->
<div class="relative max-w-7xl mx-auto px-6 mt-6 group">
<div class="relative rounded- overflow-hidden border border-white/70 shadow-[0_20px_60px_-20px_rgba(0,0,0,0.15)] bg-white h-">

<!-- FANCY LEFT BUTTON -->
<button id="marqueePrev" class="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-full glass bg-white/90 border border-white/70 shadow-xl grid place-items-center hover:bg-slate-900 hover:text-white transition-all duration-300 hover:scale-110">
<i class="fa-solid fa-chevron-left text-"></i>
</button>

<!-- FANCY RIGHT BUTTON -->
<button id="marqueeNext" class="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-full glass bg-white/90 border border-white/70 shadow-xl grid place-items-center hover:bg-slate-900 hover:text-white transition-all duration-300 hover:scale-110">
<i class="fa-solid fa-chevron-right text-"></i>
</button>

<!-- GRADIENT FADE EDGES -->
<div class="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"></div>
<div class="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"></div>

<div id="marqueeWrapper" class="overflow-hidden h-full">
<div id="marqueeTrack" class="marquee-track h-full gap-4 p-3">

<!-- Slide 1 -->
<div class="relative min-w- h-full rounded- overflow-hidden shrink-0 group/card">
<img src="https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=600&q=80" class="w-full h-full object-cover group-hover/card:scale-110 transition-transform duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent"></div>
<div class="absolute bottom-3 left-3 right-3"><p class="text-white text- flex items-center gap-2"><span class="w-7 h-7 rounded-full bg-white/20 backdrop-blur grid place-items-center"><i class="fa-solid fa-book-open text-"></i></span> Learn & Practice Quizzes</p></div>
</div>

<!-- Slide 2 -->
<div class="relative min-w- h-full rounded- overflow-hidden shrink-0 group/card">
<img src="https://images.unsplash.com/photo-1606326608606-aa0b62935f2b?auto=format&fit=crop&w=600&q=80" class="w-full h-full object-cover group-hover/card:scale-110 transition-transform duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent"></div>
<div class="absolute bottom-3 left-3 right-3"><p class="text-white text- flex items-center gap-2"><span class="w-7 h-7 rounded-full bg-white/20 backdrop-blur grid place-items-center"><i class="fa-solid fa-clock text-"></i></span> Timed Online Exams</p></div>
</div>

<!-- Slide 3 -->
<div class="relative min-w- h-full rounded- overflow-hidden shrink-0 group/card">
<img src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=600&q=80" class="w-full h-full object-cover group-hover/card:scale-110 transition-transform duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent"></div>
<div class="absolute bottom-3 left-3 right-3"><p class="text-white text- flex items-center gap-2"><span class="w-7 h-7 rounded-full bg-white/20 backdrop-blur grid place-items-center"><i class="fa-solid fa-certificate text-"></i></span> Instant Verified Results</p></div>
</div>

<!-- Slide 4 -->
<div class="relative min-w- h-full rounded- overflow-hidden shrink-0 group/card">
<img src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=600&q=80" class="w-full h-full object-cover group-hover/card:scale-110 transition-transform duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent"></div>
<div class="absolute bottom-3 left-3 right-3"><p class="text-white text- flex items-center gap-2"><span class="w-7 h-7 rounded-full bg-white/20 backdrop-blur grid place-items-center"><i class="fa-solid fa-graduation-cap text-"></i></span> Smart Learning System</p></div>
</div>

<!-- Slide 5 -->
<div class="relative min-w- h-full rounded- overflow-hidden shrink-0 group/card">
<img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=600&q=80" class="w-full h-full object-cover group-hover/card:scale-110 transition-transform duration-700">
<div class="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent"></div>
<div class="absolute bottom-3 left-3 right-3"><p class="text-white text- flex items-center gap-2"><span class="w-7 h-7 rounded-full bg-white/20 backdrop-blur grid place-items-center"><i class="fa-solid fa-users text-"></i></span> 1000+ Trusted Students</p></div>
</div>

<!-- DUPLICATE FOR SEAMLESS LOOP -->
<div class="relative min-w- h-full rounded- overflow-hidden shrink-0 group/card">
<img src="https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=600&q=80" class="w-full h-full object-cover">
<div class="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent"></div>
<div class="absolute bottom-3 left-3 right-3"><p class="text-white text- flex items-center gap-2"><span class="w-7 h-7 rounded-full bg-white/20 backdrop-blur grid place-items-center"><i class="fa-solid fa-book-open text-"></i></span> Learn & Practice Quizzes</p></div>
</div>
<div class="relative min-w- h-full rounded- overflow-hidden shrink-0 group/card">
<img src="https://images.unsplash.com/photo-1606326608606-aa0b62935f2b?auto=format&fit=crop&w=600&q=80" class="w-full h-full object-cover">
<div class="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent"></div>
<div class="absolute bottom-3 left-3 right-3"><p class="text-white text- flex items-center gap-2"><span class="w-7 h-7 rounded-full bg-white/20 backdrop-blur grid place-items-center"><i class="fa-solid fa-clock text-"></i></span> Timed Online Exams</p></div>
</div>
<div class="relative min-w- h-full rounded- overflow-hidden shrink-0 group/card">
<img src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=600&q=80" class="w-full h-full object-cover">
<div class="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent"></div>
<div class="absolute bottom-3 left-3 right-3"><p class="text-white text- flex items-center gap-2"><span class="w-7 h-7 rounded-full bg-white/20 backdrop-blur grid place-items-center"><i class="fa-solid fa-certificate text-"></i></span> Instant Verified Results</p></div>
</div>

</div>
</div>
</div>
</div>

<script>
const track = document.getElementById('marqueeTrack');
const wrapper = document.getElementById('marqueeWrapper');
let isPaused = false;
let scrollPos = 0;

document.getElementById('marqueePrev').addEventListener('click', () => {
  track.style.animation = 'none';
  wrapper.scrollBy({left: -340, behavior: 'smooth'});
  setTimeout(()=>{ track.style.animation = 'marquee 35s linear infinite'; }, 2000);
});

document.getElementById('marqueeNext').addEventListener('click', () => {
  track.style.animation = 'none';
  wrapper.scrollBy({left: 340, behavior: 'smooth'});
  setTimeout(()=>{ track.style.animation = 'marquee 35s linear infinite'; }, 2000);
});

// Pause on hover fancy buttons
wrapper.addEventListener('mouseenter', () => { track.style.animationPlayState = 'paused'; });
wrapper.addEventListener('mouseleave', () => { track.style.animationPlayState = 'running'; });
</script>

<!-- HERO SECTION -->
<section class="max-w-7xl mx-auto px-6 py-12 md:py-16">
<div class="grid md:grid-cols-2 gap-12 items-center">
<div>
<span class="px-6 py-2.5 rounded-full bg-white border border-white/70 shadow-[0_10px_30px_-10px_rgba(0,0,0,0.1)] text- tracking-[0.2em] uppercase text-slate-500">Smart Online Examination System</span>
<h1 class="text-5xl md:text- text-slate-800 mt-8 leading-[0.92]">Test Your<br><span class="text-slate-400">Knowledge,</span><br>Improve Your<br>Skills,<br>Achieve<br>Success.</h1>
<p class="text- text-slate-500 mt-8 leading-relaxed max-w-xl">Welcome to our Quiz Portal, a modern online examination platform that helps students assess their knowledge, improve learning outcomes, and verify examination results with complete transparency.</p>
<div class="mt-10 flex flex-wrap gap-4">
<a href="quizzes.php" class="px-9 py-4 rounded-full bg-slate-900 text-white hover:bg-black shadow-[0_15px_30px_rgba(0,0,0,0.15)] text- flex items-center gap-2"><i class="fa-solid fa-book-open"></i> Explore Quizzes</a>
<a href="verify.php" class="px-9 py-4 rounded-full bg-white border border-stone-200 hover:bg-stone-50 shadow-sm text- flex items-center gap-2"><i class="fa-solid fa-circle-check"></i> Verify Result</a>
</div>

<!-- PROFESSIONAL TRUST BADGE - ONLINE IMAGES ONLY -->
<div class="mt-12 flex items-center gap-4 glass rounded-full pl-2 pr-6 py-2 border border-white/70 shadow-sm w-fit hover:shadow-md transition-all">
<div class="flex -space-x-3">
<img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&h=100&q=80" class="w-11 h-11 rounded-full border-2 border-white object-cover shadow-sm">
<img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&h=100&q=80" class="w-11 h-11 rounded-full border-2 border-white object-cover shadow-sm">
<img src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=100&h=100&q=80" class="w-11 h-11 rounded-full border-2 border-white object-cover shadow-sm">
</div>
<div class="text- text-slate-600"><b class="text-slate-900 text-">1000+</b> Students <span class="text-slate-400">trust</span> Quizora <span class="ml-2 text-amber-500"><i class="fa-solid fa-star"></i> 4.9/5</span></div>
</div>

</div>

<div class="relative">
<div class="absolute inset-0 bg-gradient-to-br from-amber-200/40 to-purple-200/40 rounded- blur- -z-10 translate-x-4 translate-y-4"></div>
<div class="absolute -top-6 -right-6 w-24 h-24 bg-white rounded- shadow-xl border border-white/70 grid place-items-center rotate-3"><i class="fa-solid fa-trophy text-3xl text-amber-500"></i></div>
<img src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=900&q=80" alt="Online Examination" class="rounded- shadow-[0_30px_90px_-20px_rgba(0,0,0,0.25)] w-full object-cover">
<div class="absolute -bottom-8 -left-8 glass rounded- p-5 border border-white/70 shadow-xl flex items-center gap-4 backdrop-blur-xl">
<div class="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 grid place-items-center"><i class="fa-solid fa-check"></i></div>
<div><p class="text- text-slate-400">Success Rate</p><p class="text- font-bold">98% Results Verified</p></div>
</div>
</div>
</div>
</section>

<!-- FEATURES -->
<section class="py-20 bg-white/60 backdrop-blur rounded- max-w-7xl mx-auto px-6 md:px-10 my-10 border border-white/60">
<div class="text-center max-w-2xl mx-auto"><h2 class="text-5xl">Why Choose Our Quiz Portal?</h2><p class="text-slate-400 text- mt-4">A complete online examination solution designed for learners, educators, and institutions.</p></div>
<div class="grid md:grid-cols-4 gap-8 mt-14">
<div class="glass rounded- p-8 border border-white/70 shadow-sm hover:-translate-y-2 hover:shadow-xl transition-all duration-300 group"><div class="w-14 h-14 rounded-2xl bg-blue-100 text-blue-600 grid place-items-center text-xl group-hover:scale-110 transition-transform"><i class="fa-solid fa-book-open"></i></div><h3 class="text-2xl mt-6">Multiple Quizzes</h3><p class="text-slate-400 text- mt-3">Access quizzes from different subjects and topics.</p></div>
<div class="glass rounded- p-8 border border-white/70 shadow-sm hover:-translate-y-2 hover:shadow-xl transition-all duration-300 group"><div class="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-600 grid place-items-center text-xl group-hover:scale-110 transition-transform"><i class="fa-solid fa-clock"></i></div><h3 class="text-2xl mt-6">Timed Exams</h3><p class="text-slate-400 text- mt-3">Automatic countdown timer and auto-submission support.</p></div>
<div class="glass rounded- p-8 border border-white/70 shadow-sm hover:-translate-y-2 hover:shadow-xl transition-all duration-300 group"><div class="w-14 h-14 rounded-2xl bg-purple-100 text-purple-600 grid place-items-center text-xl group-hover:scale-110 transition-transform"><i class="fa-solid fa-chart-column"></i></div><h3 class="text-2xl mt-6">Instant Results</h3><p class="text-slate-400 text- mt-3">Get immediate feedback and detailed performance reports.</p></div>
<div class="glass rounded- p-8 border border-white/70 shadow-sm hover:-translate-y-2 hover:shadow-xl transition-all duration-300 group"><div class="w-14 h-14 rounded-2xl bg-orange-100 text-orange-600 grid place-items-center text-xl group-hover:scale-110 transition-transform"><i class="fa-solid fa-shield-halved"></i></div><h3 class="text-2xl mt-6">Verification</h3><p class="text-slate-400 text- mt-3">Verify examination records using a unique Exam ID.</p></div>
</div>
</section>

<section class="py-24 bg-slate-900 text-white rounded- max-w-7xl mx-auto my-10 px-10 text-center relative overflow-hidden">
<div class="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-amber-500/10 to-purple-500/10"></div>
<div class="relative"><i class="fa-solid fa-graduation-cap text-7xl text-amber-200"></i><h2 class="text-5xl mt-6">Learning Never Ends</h2><p class="text- text-slate-400 mt-4 max-w-3xl mx-auto">Success is achieved through continuous learning. Every quiz you attempt is an opportunity to gain knowledge.</p><div class="mt-10 flex flex-wrap justify-center gap-4"><a href="quizzes.php" class="px-9 py-4 rounded-full bg-white text-slate-900 hover:bg-slate-100 text- shadow-xl"><i class="fa-solid fa-book-open mr-2"></i> Browse Quizzes</a><a href="verify.php" class="px-9 py-4 rounded-full border border-white/20 hover:bg-white/10 text-"><i class="fa-solid fa-circle-check mr-2"></i> Verify Result</a></div></div>
</section>
<?php include 'includes/footer.php';?>