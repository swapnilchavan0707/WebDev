<?php include 'includes/header.php';?>
<section class="bg-slate-900 text-white py-20 rounded-b- text-center relative overflow-hidden">
<div class="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20"></div>
<div class="relative max-w-6xl mx-auto px-6"><i class="fa-solid fa-circle-question text-6xl text-amber-200 mb-6"></i><h1 class="text-5xl">Help & Support</h1><p class="text- text-slate-400 mt-4">Find answers to frequently asked questions about using Quizora.</p></div>
</section>

<section class="py-16 max-w-5xl mx-auto px-6">
<h2 class="text-4xl text-center mb-10">Frequently Asked Questions</h2>
<div class="space-y-5">
<div class="glass rounded- p-8 border border-white/70 shadow-sm"><h3 class="text-xl font-bold">1. How to give exam?</h3><p class="text-slate-500 mt-2 text-">Go to the Quizzes page, select any exam topic, enter your name, and start the quiz. Answer questions within the time limit and submit.</p></div>
<div class="glass rounded- p-8 border border-white/70 shadow-sm"><h3 class="text-xl font-bold">2. Is the quiz free?</h3><p class="text-slate-500 mt-2 text-">Yes, all quizzes available on Quizora are completely free for all users.</p></div>
<div class="glass rounded- p-8 border border-white/70 shadow-sm"><h3 class="text-xl font-bold">3. What is the time duration of quiz?</h3><p class="text-slate-500 mt-2 text-">Each exam has its own duration. The quiz auto-submits when time ends.</p></div>
<div class="glass rounded- p-8 border border-white/70 shadow-sm"><h3 class="text-xl font-bold">4. How to submit the quiz?</h3><p class="text-slate-500 mt-2 text-">You can either submit manually using the Submit button or it will be automatically submitted when time is over.</p></div>
<div class="glass rounded- p-8 border border-white/70 shadow-sm"><h3 class="text-xl font-bold">5. How to verify my result?</h3><p class="text-slate-500 mt-2 text-">Go to Verify page, enter your Exam ID, and you will see your result instantly.</p></div>
</div>
</section>

<section class="py-16">
<div class="max-w-3xl mx-auto px-6 text-center glass rounded- p-10 border shadow-xl"><h2 class="text-3xl">Need More Help?</h2><p class="text-slate-400 mt-3">Contact our support team for any technical issues or queries.</p><div class="mt-6 inline-block bg-white border rounded-2xl p-6 text-left"><p class="text-"><i class="fa-solid fa-envelope text-blue-600 mr-2"></i> support@quizora.com</p><p class="text- mt-2"><i class="fa-solid fa-phone text-green-600 mr-2"></i> +91 98765 43210</p></div></div>
</section>
<?php include 'includes/footer.php';?>