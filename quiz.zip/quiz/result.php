<?php
session_start();
include 'config/db.php';
if (!isset($_GET['id'])) { header("Location: quizzes.php"); exit; }
$exam_id_string = $_GET['id'];
$stmt = $pdo->prepare("SELECT r.*, e.topic_name FROM results r JOIN exams e ON r.exam_id = e.id WHERE r.exam_id_string =?");
$stmt->execute([$exam_id_string]);
$result = $stmt->fetch();
if (!$result) { echo "<h2>Result not found</h2>"; exit; }
$stmt = $pdo->prepare("SELECT rd.*, q.question_text, q.correct_option, q.option_a, q.option_b, q.option_c, q.option_d FROM result_details rd JOIN questions q ON rd.question_id = q.id WHERE rd.result_string_id =? ORDER BY q.id ASC");
$stmt->execute([$exam_id_string]);
$details = $stmt->fetchAll();
$percentage = $result['total_score']>0?($result['score']/$result['total_score'])*100:0;
$correct = $result['score'];
$wrong = $result['total_score']-$result['score'];
function getOptionText($row,$option){
    switch($option){
        case 'A': return $row['option_a'];
        case 'B': return $row['option_b'];
        case 'C': return $row['option_c'];
        case 'D': return $row['option_d'];
        default: return 'Not Answered';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Quizora - Result</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Petit+Formal+Script&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
  body, div, h1, h2, h3, p, b, span, a { font-family: "Petit Formal Script", cursive; }
  ::placeholder{font-family:"Petit Formal Script",cursive;}
.fa,.fa-solid,.fa-regular{font-family:"Font Awesome 6 Free"!important;}
.fa-solid{font-weight:900!important;}
.fa-regular{font-weight:400!important;}
.glass{background:rgba(255,255,255,0.85);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);}
</style>
</head>
<body class="bg-[#fdfbf7] min-h-screen">
<div class="fixed inset-0 -z-10">
    <div class="absolute inset-0 bg-gradient-to-br from-[#fffaf0] via-[#fff8f0] to-[#f7f0ff]"></div>
    <div class="absolute top-[-10%] left-[15%] w- h- bg-[#ffe4c4]/30 rounded-full blur-"></div>
    <div class="absolute bottom-[-10%] right-[5%] w- h- bg-[#e0c3ff]/25 rounded-full blur-"></div>
</div>

<div class="bg-slate-900 text-white p-6 text-center rounded-b- shadow-xl">
    <h1 class="text-3xl"><i class="fa-solid fa-award mr-3 text-amber-300"></i> Quizora Exam Result</h1>
</div>

<div class="max-w-4xl mx-auto mt-10 glass rounded- p-10 border border-white/70 shadow-xl">
    <h2 class="text-3xl">Candidate: <?= htmlspecialchars($result['candidate_name'])?></h2>
    <div class="mt-6 space-y-3 text- text-slate-600">
        <p><b class="text-slate-800">Exam:</b> <?= htmlspecialchars($result['topic_name'])?></p>
        <p><b class="text-slate-800">Exam ID:</b> <?= $result['exam_id_string']?></p>
        <?php if(!empty($result['email'])):?><p><b class="text-slate-800">Email:</b> <?= htmlspecialchars($result['email'])?></p><?php endif;?>
        <p><b class="text-slate-800">Score:</b> <?= $result['score']?> / <?= $result['total_score']?></p>
        <p><b class="text-slate-800">Correct Answers:</b> <?= $correct?></p>
        <p><b class="text-slate-800">Wrong Answers:</b> <?= $wrong?></p>
        <p><b class="text-slate-800">Percentage:</b> <?= round($percentage,2)?>%</p>
        <?php if($percentage>=40):?>
            <div class="mt-6 p-4 rounded-full bg-emerald-100 text-emerald-700 text-center font-bold text-"><i class="fa-solid fa-circle-check mr-2"></i> Passed</div>
        <?php else:?>
            <div class="mt-6 p-4 rounded-full bg-red-100 text-red-700 text-center font-bold text-"><i class="fa-solid fa-circle-xmark mr-2"></i> Failed</div>
        <?php endif;?>
    </div>
</div>

<div class="max-w-4xl mx-auto mt-10 px-6">
    <h2 class="text-4xl mb-6">Answer Review</h2>
    <?php foreach($details as $index=>$row):?>
    <div class="glass rounded- p-7 border border-white/70 shadow-sm mb-5 hover:bg-white/90 transition-all">
        <h3 class="font-bold text-">Q<?= $index+1?>. <?= htmlspecialchars($row['question_text'])?></h3>
        <p class="mt-3 text-"><b>Your Answer:</b> <?= htmlspecialchars(getOptionText($row,$row['selected_option']))?> (<?= $row['selected_option']?? '-'?>)</p>
        <p class="text- mt-1"><b>Correct Answer:</b> <?= htmlspecialchars(getOptionText($row,$row['correct_option']))?> (<?= $row['correct_option']?>)</p>
        <?php if($row['is_correct']==1):?>
            <p class="text-emerald-600 font-bold mt-3 text-"><i class="fa-solid fa-check mr-1"></i> Correct</p>
        <?php else:?>
            <p class="text-red-600 font-bold mt-3 text-"><i class="fa-solid fa-xmark mr-1"></i> Wrong</p>
        <?php endif;?>
    </div>
    <?php endforeach;?>
</div>

<div class="text-center mt-10 pb-16">
    <a href="quizzes.php" class="px-8 py-4 rounded-full bg-slate-900 text-white hover:bg-black shadow-lg text-"><i class="fa-solid fa-arrow-left mr-2"></i> Back to Quizzes</a>
</div>

</body>
</html>