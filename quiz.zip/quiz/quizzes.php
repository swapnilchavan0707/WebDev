<?php
include 'config/db.php';
include 'includes/header.php';
try {
    $stmt = $pdo->prepare("SELECT * FROM exams ORDER BY id ASC");
    $stmt->execute();
    $exams = $stmt->fetchAll();
} catch (Exception $e) { die("Error fetching exams: ". $e->getMessage()); }
?>
<section class="bg-slate-900 text-white py-20 rounded-b- text-center relative overflow-hidden">
<div class="absolute inset-0 bg-gradient-to-br from-amber-500/10 via-transparent to-purple-500/10"></div>
<div class="relative"><h1 class="text-5xl md:text-6xl">Available Quizzes</h1><p class="text-slate-400 text- mt-4">Select a quiz topic and start your exam instantly.</p></div>
</section>

<section class="py-16 max-w-7xl mx-auto px-6">
<?php if (count($exams) > 0):?>
<div class="grid md:grid-cols-3 gap-8">
<?php foreach ($exams as $row): $duration = $row['duration']?? 0;?>
<div class="glass rounded- border border-white/70 shadow-xl overflow-hidden hover:-translate-y-1 transition-all">
<div class="bg-slate-900 text-white p-6"><h2 class="text-2xl"><i class="fa-solid fa-book-open mr-2"></i> <?= htmlspecialchars($row['topic_name'])?></h2></div>
<div class="p-7">
<p class="text- text-slate-500"><i class="fa-solid fa-list mr-2 text-blue-600"></i> Total Questions: <b class="text-slate-800"><?= $row['total_questions']?></b></p>
<p class="text- text-slate-500 mt-2"><i class="fa-solid fa-clock mr-2 text-green-600"></i> Time: <b class="text-slate-800"><?= $duration?> Minutes</b></p>
<a href="start_quiz.php?exam_id=<?= $row['id']?>" class="mt-6 block text-center py-4 rounded-full bg-slate-900 text-white hover:bg-black shadow-lg text-"><i class="fa-solid fa-play mr-2"></i> Start Test</a>
</div>
</div>
<?php endforeach;?>
</div>
<?php else:?>
<div class="text-center py-20 glass rounded- border p-10"><i class="fa-solid fa-circle-exclamation text-6xl text-slate-300"></i><h2 class="text-3xl mt-4">No Quizzes Available</h2><p class="text-slate-400 mt-2">Please check back later.</p></div>
<?php endif;?>
</section>
<?php include 'includes/footer.php';?>