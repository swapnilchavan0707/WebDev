<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Quizora - Online Examination System</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Petit+Formal+Script&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
  body, input, button, textarea, select, label, div, h1, h2, h3, h4, p, th, td, a, li, span, ul { font-family: "Petit Formal Script", cursive; }
  ::placeholder { font-family: "Petit Formal Script", cursive; opacity:0.5; }
.fa,.fas,.fa-solid,.far,.fa-regular,.fab,.fa-brands{font-family:"Font Awesome 6 Free","Font Awesome 6 Brands"!important;}
.fa-solid{font-weight:900!important;}.fa-regular{font-weight:400!important;}
.glass{background:rgba(255,255,255,0.82);backdrop-filter:blur(20px);}
</style>
</head>
<body class="bg-[#fdfbf7] min-h-screen relative">
<div class="fixed inset-0 -z-10">
<div class="absolute inset-0 bg-gradient-to-br from-[#fffaf0] via-[#fff8f0] to-[#f7f0ff]"></div>
<div class="absolute top-[-10%] left-[15%] w- h- bg-[#ffe4c4]/30 rounded-full blur-"></div>
<div class="absolute bottom-[-10%] right-[5%] w- h- bg-[#e0c3ff]/25 rounded-full blur-"></div>
</div>

<!-- NAVBAR HEIGHT INCREASED TO 100px AND CENTERED -->
<nav class="glass border-b border-white/60 sticky top-0 z-50 shadow-[0_10px_40px_-15px_rgba(0,0,0,0.08)]">
<div class="max-w-7xl mx-auto px-6 h- flex justify-between items-center">

<a href="index.php" class="flex items-center gap-3">
<div class="w-12 h-12 rounded-2xl bg-slate-900 text-white grid place-items-center shadow-lg"><i class="fa-solid fa-graduation-cap"></i></div>
<div><h1 class="text- leading-none text-slate-800">Quizora</h1><p class="text- text-slate-400 mt-1">Learn. Test. Improve.</p></div>
</a>

<div class="hidden md:flex items-center gap-10 text-">
<a href="index.php" class="<?= ($currentPage=='index.php')?'text-slate-900 font-bold border-b-2 border-slate-900 pb-1':'text-slate-500 hover:text-slate-900'?>">Home</a>
<a href="quizzes.php" class="<?= ($currentPage=='quizzes.php')?'text-slate-900 font-bold border-b-2 border-slate-900 pb-1':'text-slate-500 hover:text-slate-900'?>">Quizzes</a>
<a href="verify.php" class="<?= ($currentPage=='verify.php')?'text-slate-900 font-bold border-b-2 border-slate-900 pb-1':'text-slate-500 hover:text-slate-900'?>">Verify</a>
<a href="help.php" class="<?= ($currentPage=='help.php')?'text-slate-900 font-bold border-b-2 border-slate-900 pb-1':'text-slate-500 hover:text-slate-900'?>">Help</a>

<!-- BUTTON NOW CENTERED WITH PROPER TOP/BOTTOM SPACE -->
<a href="admin/index.php" class="ml-2 px-7 py-3 rounded-full bg-slate-900 text-white hover:bg-black shadow-[0_10px_20px_rgba(0,0,0,0.15)] text- flex items-center gap-2 h-"><i class="fa-solid fa-user-shield"></i> Admin Login</a>
</div>

<button id="menu-btn" class="md:hidden w-11 h-11 rounded-full bg-white border grid place-items-center shadow-sm"><i class="fa-solid fa-bars"></i></button>
</div>

<div id="mobile-menu" class="hidden md:hidden bg-white/95 backdrop-blur-xl border-t p-6 space-y-4 text-"><a href="index.php" class="block py-2">Home</a><a href="quizzes.php" class="block py-2">Quizzes</a><a href="verify.php" class="block py-2">Verify Result</a><a href="help.php" class="block py-2">Help</a><a href="admin/index.php" class="block py-3.5 rounded-full bg-slate-900 text-white text-center">Admin Login</a></div>
</div>
</nav>
<script>document.getElementById('menu-btn')?.addEventListener('click',()=>{document.getElementById('mobile-menu').classList.toggle('hidden')})</script>