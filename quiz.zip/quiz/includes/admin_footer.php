</main>
</div>

<footer class="bg-white/80 backdrop-blur-xl border-t border-white/60 mt-10 py-6">
<div class="text-center text-slate-400 text-">
<p>© <?= date("Y")?> Quizora Admin Panel. All Rights Reserved.</p>
<p class="mt-1 text-">Smart Online Examination System | Made in India</p>
</div>
</footer>

</body>
</html>