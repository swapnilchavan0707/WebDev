<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<aside class="w-64 bg-white/80 backdrop-blur-xl shadow-md min-h-screen border-r border-white/60">
<div class="p-6">
<h2 class="text- tracking-[0.2em] text-slate-400 mb-5">MENU</h2>
<ul class="space-y-2 text- text-slate-600">
<li><a href="dashboard.php" class="block p-3.5 rounded-2xl hover:bg-stone-100 transition-all <?= ($currentPage=='dashboard.php')?'bg-slate-900 text-white shadow-lg':''?>"><i class="fa-solid fa-gauge mr-3"></i> Dashboard</a></li>
<li><a href="manage_admins.php" class="block p-3.5 rounded-2xl hover:bg-stone-100 transition-all <?= ($currentPage=='manage_admins.php')?'bg-slate-900 text-white shadow-lg':''?>"><i class="fa-solid fa-users mr-3"></i> Manage Admins</a></li>
<li><a href="manage_exams.php" class="block p-3.5 rounded-2xl hover:bg-stone-100 transition-all <?= ($currentPage=='manage_exams.php')?'bg-slate-900 text-white shadow-lg':''?>"><i class="fa-solid fa-file-pen mr-3"></i> Manage Exams</a></li>
<li><a href="add_questions.php" class="block p-3.5 rounded-2xl hover:bg-stone-100 transition-all <?= ($currentPage=='add_questions.php')?'bg-slate-900 text-white shadow-lg':''?>"><i class="fa-solid fa-circle-plus mr-3"></i> Add Questions</a></li>
<li><a href="results.php" class="block p-3.5 rounded-2xl hover:bg-stone-100 transition-all <?= ($currentPage=='results.php')?'bg-slate-900 text-white shadow-lg':''?>"><i class="fa-solid fa-chart-line mr-3"></i> Results</a></li>
</ul>
</div>
</aside>