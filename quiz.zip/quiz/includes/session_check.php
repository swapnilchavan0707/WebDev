<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in']!== true) {
    $_SESSION['login_error'] = "Please login to access admin panel.";
    header("Location:../admin/index.php");
    exit();
}
$admin_id = $_SESSION['admin_id']?? null;
$admin_name = $_SESSION['admin_name']?? $_SESSION['admin_username']?? 'Administrator';
?>