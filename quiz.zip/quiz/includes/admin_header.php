<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['admin_logged_in']) &&!isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit;
}
$currentPage = basename($_SERVER['PHP_SELF']);
$adminName = $_SESSION['admin_name']?? $_SESSION['admin_username']?? 'Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Quizora Admin Panel</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Petit+Formal+Script&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
  body, input, button, textarea, select, div, h1, h2, p, th, td, a, li, span {
    font-family: "Petit Formal Script", cursive;
  }
  ::placeholder{font-family:"Petit Formal Script",cursive;opacity:0.5;}
 .fa,.fas,.fa-solid,.far,.fa-regular,.fab,.fa-brands{font-family:"Font Awesome 6 Free","Font Awesome 6 Brands"!important;}
 .fa-solid{font-weight:900!important;}
 .fa-regular{font-weight:400!important;}
 .glass{background:rgba(255,255,255,0.85);backdrop-filter:blur(20px);}
 .active-link{background:#111827!important;color:white!important;box-shadow:0 10px 20px rgba(0,0,0,0.15);}
</style>
</head>
<body class="bg-[#fdfbf7] min-h-screen">
<div class="fixed inset-0 -z-10">
<div class="absolute inset-0 bg-gradient-to-br from-[#fffaf0] via-[#fff8f0] to-[#f7f0ff]"></div>
<div class="absolute top-[-10%] left-[15%] w- h- bg-[#ffe4c4]/30 rounded-full blur-"></div>
<div class="absolute bottom-[-10%] right-[10%] w- h- bg-[#e0c3ff]/30 rounded-full blur-"></div>
</div>

<nav class="bg-slate-900 text-white shadow-xl sticky top-0 z-50">
<div class="flex justify-between items-center px-6 py-4">
<div class="flex items-center gap-3">
<div class="w-10 h-10 rounded-xl bg-white text-slate-900 grid place-items-center shadow-lg"><i class="fa-solid fa-user-shield"></i></div>
<div><h1 class="text- leading-none">Quizora Admin</h1><p class="text- text-slate-400">Control Panel</p></div>
</div>
<div class="flex items-center gap-6">
<span class="hidden md:block text- text-slate-300"><i class="fa-solid fa-circle-user mr-2"></i> <?= htmlspecialchars($adminName)?></span>
<a href="logout.php" class="px-5 py-2 rounded-full bg-white text-slate-900 hover:bg-slate-100 text- shadow-sm"><i class="fa-solid fa-right-from-bracket mr-1"></i> Logout</a>
</div>
</div>
</nav>

<div class="flex">
<aside class="w-64 bg-white/80 backdrop-blur-xl shadow-md min-h-screen border-r border-white/60">
<div class="p-6">
<h2 class="text- tracking-[0.2em] text-slate-400 mb-5">MENU</h2>
<ul class="space-y-2 text-">
<li><a href="dashboard.php" class="block p-3.5 rounded-2xl hover:bg-stone-100 transition-all <?= ($currentPage=='dashboard.php')?'active-link':''?>"><i class="fa-solid fa-gauge mr-3"></i> Dashboard</a></li>
<li><a href="manage_admins.php" class="block p-3.5 rounded-2xl hover:bg-stone-100 transition-all <?= ($currentPage=='manage_admins.php')?'active-link':''?>"><i class="fa-solid fa-users mr-3"></i> Manage Admins</a></li>
<li><a href="manage_exams.php" class="block p-3.5 rounded-2xl hover:bg-stone-100 transition-all <?= ($currentPage=='manage_exams.php')?'active-link':''?>"><i class="fa-solid fa-file-pen mr-3"></i> Manage Exams</a></li>
<li><a href="add_questions.php" class="block p-3.5 rounded-2xl hover:bg-stone-100 transition-all <?= ($currentPage=='add_questions.php')?'active-link':''?>"><i class="fa-solid fa-circle-plus mr-3"></i> Add Questions</a></li>
<li><a href="results.php" class="block p-3.5 rounded-2xl hover:bg-stone-100 transition-all <?= ($currentPage=='results.php')?'active-link':''?>"><i class="fa-solid fa-chart-line mr-3"></i> Results</a></li>
</ul>
</div>
</aside>

<main class="flex-1 p-6 md:p-10">