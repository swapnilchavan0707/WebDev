<footer class="mt-20 bg-slate-900 text-white rounded-t- overflow-hidden">
<div class="max-w-7xl mx-auto px-6 md:px-10 py-16">
<div class="grid md:grid-cols-4 gap-10">
<div>
<h2 class="text-3xl">Quizora</h2>
<p class="text- text-slate-400 mt-4 leading-relaxed">
Quizora is a smart online examination platform designed to help students learn, practice, and evaluate their knowledge through interactive quizzes and instant result analysis.
</p>
</div>
<div>
<h3 class="text-">Quick Links</h3>
<ul class="mt-4 space-y-2 text- text-slate-400">
<li><a href="index.php" class="hover:text-white transition-colors"><i class="fa-solid fa-house mr-2"></i> Home</a></li>
<li><a href="quizzes.php" class="hover:text-white transition-colors"><i class="fa-solid fa-book-open mr-2"></i> Quizzes</a></li>
<li><a href="verify.php" class="hover:text-white transition-colors"><i class="fa-solid fa-circle-check mr-2"></i> Verify Result</a></li>
<li><a href="help.php" class="hover:text-white transition-colors"><i class="fa-solid fa-circle-question mr-2"></i> Help</a></li>
</ul>
</div>
<div>
<h3 class="text-">Contact Us</h3>
<ul class="mt-4 space-y-3 text- text-slate-400">
<li><i class="fa-solid fa-envelope mr-2 text-amber-300"></i> support@quizora.com</li>
<li><i class="fa-solid fa-phone mr-2 text-emerald-300"></i> +91 98765 43210</li>
<li><i class="fa-solid fa-location-dot mr-2 text-red-300"></i> Pune, Maharashtra, Bharat</li>
</ul>
</div>
<div>
<h3 class="text-">Company</h3>
<p class="text- text-slate-400 mt-4 leading-relaxed">
Developed and maintained by <span class="text-white">Quizora Technologies Pvt. Ltd.</span> focused on delivering modern educational solutions.
</p>
<div class="mt-5 flex gap-3 text-lg">
<a href="#" class="w-9 h-9 rounded-full bg-white/10 grid place-items-center hover:bg-white hover:text-slate-900 transition-all"><i class="fa-brands fa-facebook"></i></a>
<a href="#" class="w-9 h-9 rounded-full bg-white/10 grid place-items-center hover:bg-white hover:text-slate-900 transition-all"><i class="fa-brands fa-instagram"></i></a>
<a href="#" class="w-9 h-9 rounded-full bg-white/10 grid place-items-center hover:bg-white hover:text-slate-900 transition-all"><i class="fa-brands fa-linkedin"></i></a>
<a href="#" class="w-9 h-9 rounded-full bg-white/10 grid place-items-center hover:bg-white hover:text-slate-900 transition-all"><i class="fa-brands fa-github"></i></a>
</div>
</div>
</div>
<div class="border-t border-white/10 mt-10 pt-6 text-center text-slate-500 text-">
<p>© <?= date("Y")?> Quizora Technologies Pvt. Ltd. | All Rights Reserved.</p>
<p class="text- mt-1">Learn. Test. Improve.</p>
</div>
</div>
</footer>
</body>
</html>