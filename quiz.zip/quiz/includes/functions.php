<?php
function cleanInput($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}
function generateExamId() {
    return "EXAM-". strtoupper(uniqid());
}
function calculatePercentage($score, $total) {
    if ($total == 0) return 0;
    return round(($score / $total) * 100, 2);
}
function isCorrectAnswer($correct, $selected) {
    return strtoupper($correct) === strtoupper($selected);
}
function formatDateTime($datetime) {
    return date("d M Y, h:i A", strtotime($datetime));
}
function redirect($url) {
    header("Location: $url");
    exit();
}
function setFlash($key, $message) {
    $_SESSION['flash'][$key] = $message;
}
function getFlash($key) {
    if (isset($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return null;
}
?>