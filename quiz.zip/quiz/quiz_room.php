<?php
session_start();
include 'config/db.php';
if (!isset($_SESSION['exam_id']) ||!isset($_SESSION['candidate_name'])) { header("Location: quizzes.php"); exit; }
$exam_id = $_SESSION['exam_id'];
$candidate_name = $_SESSION['candidate_name'];
$stmt = $pdo->prepare("SELECT * FROM exams WHERE id =?"); $stmt->execute([$exam_id]); $exam = $stmt->fetch();
if (!$exam) { die("Invalid Exam"); }
$stmt = $pdo->prepare("SELECT * FROM questions WHERE exam_id =? ORDER BY id ASC"); $stmt->execute([$exam_id]); $questions = $stmt->fetchAll();
$total_questions = count($questions);
$total_time = $exam['duration'] * 60;
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Quizora - Quiz Room</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Petit+Formal+Script&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>body,input,button,div,h2,h3,label{font-family:"Petit Formal Script",cursive;}.fa,.fa-solid{font-family:"Font Awesome 6 Free"!important;font-weight:900!important;}.glass{background:rgba(255,255,255,0.85);backdrop-filter:blur(20px);}</style>
</head><body class="bg-[#fdfbf7] min-h-screen">
<div class="fixed inset-0 -z-10"><div class="absolute inset-0 bg-gradient-to-br from-[#fffaf0] to-[#f7f0ff]"></div></div>
<div class="bg-slate-900 text-white p-5 flex justify-between items-center"><h2 class="text-xl">Quizora Exam Portal</h2><div class="text-">Candidate: <b><?= htmlspecialchars($candidate_name)?></b> | <?= htmlspecialchars($exam['topic_name'])?></div></div>
<div class="max-w-4xl mx-auto mt-8 glass rounded-full border border-white/70 shadow-sm p-3 text-center"><h3 class="text-2xl text-red-600"><i class="fa-solid fa-stopwatch mr-2"></i> Time Left: <span id="timer" class="font-bold"></span></h3></div>
<form id="quizForm" action="process_quiz.php" method="POST" class="max-w-4xl mx-auto mt-8 px-6">
<input type="hidden" name="exam_id" value="<?= $exam_id?>"><input type="hidden" name="candidate_name" value="<?= htmlspecialchars($candidate_name)?>">
<?php foreach ($questions as $index=>$q):?>
<div class="question-box glass rounded- p-8 border border-white/70 shadow-xl mb-8" data-index="<?= $index?>" style="<?= $index==0?'':'display:none;'?>">
<h3 class="text-2xl font-bold mb-6">Q<?= $index+1?>. <?= htmlspecialchars($q['question_text'])?></h3>
<div class="space-y-4 text-">
<label class="flex gap-3 p-4 rounded-2xl bg-white/60 border hover:bg-white cursor-pointer transition-all"><input type="radio" name="answers[<?= $q['id']?>]" value="A" class="mt-1"> <?= htmlspecialchars($q['option_a'])?></label>
<label class="flex gap-3 p-4 rounded-2xl bg-white/60 border hover:bg-white cursor-pointer transition-all"><input type="radio" name="answers[<?= $q['id']?>]" value="B" class="mt-1"> <?= htmlspecialchars($q['option_b'])?></label>
<label class="flex gap-3 p-4 rounded-2xl bg-white/60 border hover:bg-white cursor-pointer transition-all"><input type="radio" name="answers[<?= $q['id']?>]" value="C" class="mt-1"> <?= htmlspecialchars($q['option_c'])?></label>
<label class="flex gap-3 p-4 rounded-2xl bg-white/60 border hover:bg-white cursor-pointer transition-all"><input type="radio" name="answers[<?= $q['id']?>]" value="D" class="mt-1"> <?= htmlspecialchars($q['option_d'])?></label>
</div>
</div>
<?php endforeach;?>
<div class="flex justify-between mt-8 pb-16"><button type="button" id="prevBtn" class="px-8 py-3 rounded-full bg-white border shadow-sm hover:bg-stone-50"><i class="fa-solid fa-arrow-left mr-2"></i> Previous</button><div class="flex gap-3"><button type="button" id="nextBtn" class="px-8 py-3 rounded-full bg-slate-900 text-white hover:bg-black shadow-lg">Next <i class="fa-solid fa-arrow-right ml-2"></i></button><button type="submit" class="px-8 py-3 rounded-full bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg"><i class="fa-solid fa-check mr-2"></i> Submit Quiz</button></div></div>
</form>
<script>
let current = 0;
let questions = document.querySelectorAll(".question-box");
function showQuestion(index) { questions.forEach((q,i)=>{q.style.display=(i===index)?'block':'none';}); }
function nextQuestion(){ if(current < questions.length-1){ current++; showQuestion(current);} }
document.getElementById('prevBtn').addEventListener('click',()=>{ if(current>0){ current--; showQuestion(current);} });
document.getElementById('nextBtn').addEventListener('click',()=>{ nextQuestion(); });
let timeLeft = <?= $total_time?>;
let timerDisplay = document.getElementById("timer");
function updateTimer(){
    let minutes = Math.floor(timeLeft/60); let seconds = timeLeft%60;
    timerDisplay.innerHTML = (minutes<10?'0'+minutes:minutes)+":"+(seconds<10?'0'+seconds:seconds);
    if(timeLeft<=0){ clearInterval(timerInterval); document.getElementById("quizForm").submit(); }
    timeLeft--;
}
let timerInterval = setInterval(updateTimer,1000); updateTimer();
</script>
<script src="assets/js/main.js"></script>
<script src="assets/js/quiz.js"></script>
</body></html>