<?php
session_start();
include 'config/db.php';
if (!isset($_GET['exam_id'])) { header("Location: quizzes.php"); exit; }
$exam_id = $_GET['exam_id'];
$stmt = $pdo->prepare("SELECT * FROM exams WHERE id =?"); $stmt->execute([$exam_id]); $exam = $stmt->fetch();
if (!$exam) { die("Invalid Exam Selected"); }
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $candidate_name = trim($_POST['candidate_name']);
    if ($candidate_name == "") { echo "<script>alert('Enter your name');</script>"; }
    else {
        if (strlen($candidate_name) > 100) { die("Name too long"); }
        $_SESSION['exam_id'] = $exam_id;
        $_SESSION['candidate_name'] = $candidate_name;
        header("Location: quiz_room.php"); exit;
    }
}
include 'includes/header.php';
?>
<section class="bg-slate-900 text-white py-12 rounded-b- text-center"><h1 class="text-4xl">Start Your Quiz</h1></section>
<div class="max-w-2xl mx-auto mt-10 glass rounded- p-10 border border-white/70 shadow-xl">
<h2 class="text-4xl text-center"><?= htmlspecialchars($exam['topic_name'])?></h2>
<p class="text-center text-slate-400 mt-3 text-">Total Questions: <b class="text-slate-800"><?= $exam['total_questions']?></b> | Time: <b class="text-slate-800"><?= $exam['duration']?> Minutes</b></p>
<div class="bg-amber-50 border border-amber-100 p-6 rounded-2xl mt-8">
<h3 class="font-bold text-"><i class="fa-solid fa-circle-info mr-2"></i> Instructions</h3>
<ul class="list-disc ml-5 text- text-slate-600 mt-3 space-y-1"><li>Each question carries equal marks.</li><li>Timer will run continuously for full exam.</li><li>Do not refresh the page during exam.</li><li>Exam will auto-submit when time ends.</li></ul>
</div>
<form method="POST" class="mt-8 space-y-6">
<div><label class="text- text-slate-500">Enter Your Name</label><input type="text" name="candidate_name" placeholder="Your Full Name" class="mt-3 w-full px-5 py-4 bg-white/80 border border-stone-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-200 text-" required></div>
<button type="submit" class="w-full py-4 rounded-full bg-slate-900 text-white hover:bg-black shadow-lg text-"><i class="fa-solid fa-play mr-2"></i> Start Exam</button>
</form>
</div>
<?php include 'includes/footer.php';?>