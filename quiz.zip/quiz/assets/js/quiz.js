let timerElement = document.getElementById('time-display') || document.getElementById('timer');
let quizForm = document.getElementById('quizForm');
let countdownInterval;
let totalAnswered = 0;

// Progress Bar Creation - Luxury Style
function createProgressBar() {
    if (!document.querySelector('.quiz-progress')) {
        const progressContainer = document.createElement('div');
        progressContainer.className = 'quiz-progress max-w-4xl mx-auto mt-6 px-6';
        progressContainer.innerHTML = `
            <div class="glass rounded-full p-2 border border-white/60 shadow-sm">
                <div class="flex justify-between items-center mb-2 px-2">
                    <span style="font-family: 'Petit Formal Script', cursive;" class="text- text-slate-500">Progress</span>
                    <span id="progress-text" style="font-family: 'Petit Formal Script', cursive;" class="text- text-slate-600">0 / 0 Answered</span>
                </div>
                <div class="w-full bg-stone-100 rounded-full h-2.5 overflow-hidden">
                    <div id="progress-bar" class="h-2.5 rounded-full bg-gradient-to-r from-amber-400 to-orange-400 transition-all duration-500 ease-out" style="width:0%"></div>
                </div>
            </div>
        `;
        if (quizForm) {
            quizForm.parentNode.insertBefore(progressContainer, quizForm);
        }
    }
}

function updateProgress() {
    const allQuestions = document.getElementsByClassName('question-block').length || document.querySelectorAll('.question-box').length;
    const answered = document.querySelectorAll('input[type="radio"]:checked').length;
    const percent = allQuestions > 0? (answered / allQuestions) * 100 : 0;

    const bar = document.getElementById('progress-bar');
    const text = document.getElementById('progress-text');
    if (bar) bar.style.width = percent + '%';
    if (text) text.textContent = `${answered} / ${allQuestions} Answered`;
}

// Timer with Luxury UI
function updateTimer() {
    if (!timerElement ||!quizForm) return;

    let minutes = Math.floor(totalSeconds / 60);
    let seconds = totalSeconds % 60;

    minutes = minutes < 10? '0' + minutes : minutes;
    seconds = seconds < 10? '0' + seconds : seconds;

    timerElement.textContent = minutes + ':' + seconds;

    // Color change when time is low
    if (totalSeconds <= 60) {
        timerElement.classList.add('text-red-600');
        timerElement.parentElement.classList.add('animate-pulse');
    } else if (totalSeconds <= 300) {
        timerElement.classList.add('text-amber-600');
    }

    if (totalSeconds <= 0) {
        clearInterval(countdownInterval);
        showLuxuryAlert('Time is up! Submitting automatically...', 'error');
        setTimeout(() => {
            quizForm.submit();
        }, 1000);
        return;
    }
    totalSeconds--;
}

function showLuxuryAlert(msg, type) {
    if (typeof showAlert === 'function') {
        showAlert(msg, type === 'error'? 'error' : 'success');
    } else {
        alert(msg);
    }
}

// Start timer only if elements exist
if (timerElement && quizForm) {
    createProgressBar();
    updateProgress();
    countdownInterval = setInterval(updateTimer, 1000);
    updateTimer();
}

// Listen for answer selection to update progress
document.addEventListener('change', function(e) {
    if (e.target.type === 'radio') {
        updateProgress();
        // Subtle selection feedback
        e.target.closest('label')?.animate([
            { transform: 'scale(1)' },
            { transform: 'scale(1.02)' },
            { transform: 'scale(1)' }
        ], { duration: 200 });
    }
});

// QUESTION SWITCH with Fade Animation - Same Functionality
function changeQuestion(targetIndex) {
    let blocks = document.getElementsByClassName('question-block');
    if (blocks.length === 0) blocks = document.getElementsByClassName('question-box');

    for (let i = 0; i < blocks.length; i++) {
        blocks[i].style.display = 'none';
        blocks[i].style.opacity = '0';
    }

    let target = document.getElementById('q-block-' + targetIndex) || document.querySelector(`[data-index="${targetIndex}"]`);

    if (target) {
        target.style.display = 'block';
        target.animate([
            { opacity: 0, transform: 'translateY(20px)' },
            { opacity: 1, transform: 'translateY(0)' }
        ], { duration: 400, easing: 'ease-out' });
        target.style.opacity = '1';
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

// Enhanced Navigation Logic
let current = 0;
let questions = document.querySelectorAll(".question-block");
if (questions.length === 0) questions = document.querySelectorAll(".question-box");

function showQuestion(index) {
    questions.forEach((q, i) => {
        if (i === index) {
            q.style.display = 'block';
            q.animate([
                { opacity: 0, transform: 'translateX(30px)' },
                { opacity: 1, transform: 'translateX(0)' }
            ], { duration: 350, easing: 'ease-out' });
        } else {
            q.style.display = 'none';
        }
    });
    // Update nav buttons state
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    if (prevBtn) prevBtn.style.opacity = index === 0? '0.5' : '1';
    if (nextBtn) nextBtn.style.opacity = index === questions.length - 1? '0.5' : '1';
}

function nextQuestion() {
    if (current < questions.length - 1) {
        current++;
        showQuestion(current);
    }
}

document.getElementById('prevBtn')?.addEventListener('click', function () {
    if (current > 0) {
        current--;
        showQuestion(current);
    }
});

document.getElementById('nextBtn')?.addEventListener('click', function () {
    nextQuestion();
});

// Initialize first question
if (questions.length > 0) showQuestion(0);

// MANUAL SUBMIT with Luxury Confirm - Same Functionality
function confirmManualSubmit(event) {
    event.preventDefault();

    const confirmBox = document.createElement('div');
    confirmBox.className = 'fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm grid place-items-center p-6';
    confirmBox.innerHTML = `
        <div class="glass bg-white/90 rounded- p-8 md:p-10 shadow-[0_30px_90px_-20px_rgba(0,0,0,0.3)] border border-white/70 max-w-md w-full text-center" style="font-family: 'Petit Formal Script', cursive;">
            <div class="w-16 h-16 rounded-full bg-amber-100 text-amber-600 mx-auto grid place-items-center text-2xl mb-5">
                <i class="fa-solid fa-triangle-exclamation"></i>
            </div>
            <h3 class="text-2xl text-slate-800">Submit Quiz?</h3>
            <p class="text- text-slate-500 mt-3">Are you sure you want to finish and submit your answers? This cannot be undone.</p>
            <div class="flex gap-3 mt-8">
                <button id="cancel-submit" class="flex-1 py-3.5 rounded-full bg-white border border-stone-200 text- hover:bg-stone-50">Cancel</button>
                <button id="confirm-submit" class="flex-1 py-3.5 rounded-full bg-slate-900 text-white text- hover:bg-black">Yes, Submit</button>
            </div>
        </div>
    `;
    document.body.appendChild(confirmBox);

    confirmBox.querySelector('#cancel-submit').onclick = () => confirmBox.remove();
    confirmBox.querySelector('#confirm-submit').onclick = () => {
        clearInterval(countdownInterval);
        quizForm.submit();
    };
    confirmBox.onclick = (e) => { if (e.target === confirmBox) confirmBox.remove(); };
}

// Keyboard Navigation - New Luxury Feature
document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowRight') nextQuestion();
    if (e.key === 'ArrowLeft' && current > 0) {
        current--; showQuestion(current);
    }
});

console.log("Quizora Quiz JS Loaded");