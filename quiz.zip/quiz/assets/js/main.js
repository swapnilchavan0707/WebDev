"use strict";

document.addEventListener("DOMContentLoaded", function () {

    // Mobile Menu with Smooth Animation
    const menuBtn = document.getElementById("menu-btn");
    const mobileMenu = document.getElementById("mobile-menu");

    if (menuBtn && mobileMenu) {
        menuBtn.addEventListener("click", function () {
            mobileMenu.classList.toggle("hidden");
            if (!mobileMenu.classList.contains("hidden")) {
                mobileMenu.animate([
                    { opacity: 0, transform: 'translateY(-10px)' },
                    { opacity: 1, transform: 'translateY(0)' }
                ], { duration: 300, easing: 'ease-out' });
            }
        });
    }

    // Add subtle hover lift to all glass cards
    document.querySelectorAll('.glass').forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-2px)';
            card.style.transition = 'all 0.3s ease';
        });
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0)';
        });
    });

    // Auto fade-in animation for page
    document.body.animate([
        { opacity: 0 },
        { opacity: 1 }
    ], { duration: 600, easing: 'ease-out' });

});

// Smooth Scroll with Petit Style
function smoothScrollTo(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
}

// Luxury Alert - Petit Font + Glass Effect
function showAlert(message, type = "success") {
    const alertBox = document.createElement("div");

    alertBox.style.fontFamily = '"Petit Formal Script", cursive';
    alertBox.style.backdropFilter = 'blur(20px)';

    alertBox.className = `
        fixed top-8 right-5 md:right-8 px-8 py-5 rounded- text- shadow-[0_20px_60px_-15px_rgba(0,0,0,0.2)] z-50 border border-white/60
        ${type === "success"? "bg-white/90 text-emerald-700 border-emerald-100" : "bg-white/90 text-red-700 border-red-100"}
    `;

    alertBox.innerHTML = `
        <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded-full ${type === "success"? "bg-emerald-100" : "bg-red-100"} grid place-items-center">
                <i class="fa-solid ${type === "success"? "fa-check" : "fa-triangle-exclamation"} text-sm"></i>
            </div>
            <span>${message}</span>
        </div>
    `;

    document.body.appendChild(alertBox);

    // Entry animation
    alertBox.animate([
        { opacity: 0, transform: 'translateX(100px) scale(0.9)' },
        { opacity: 1, transform: 'translateX(0) scale(1)' }
    ], { duration: 400, easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)' });

    setTimeout(() => {
        alertBox.animate([
            { opacity: 1, transform: 'translateX(0)' },
            { opacity: 0, transform: 'translateX(100px)' }
        ], { duration: 300 }).onfinish = () => alertBox.remove();
    }, 3500);
}

// Protect Content - Optional
document.addEventListener("contextmenu", function (e) {
    // Uncomment to disable right click
    // e.preventDefault();
});

document.addEventListener("copy", function (e) {
    // Uncomment to disable copy
    // e.preventDefault();
});

// Input Focus Glow Effect
document.addEventListener('focusin', (e) => {
    if (e.target.matches('input, textarea, select')) {
        e.target.style.boxShadow = '0 0 0 4px rgba(251, 191, 36, 0.15)';
        e.target.style.transition = 'all 0.3s ease';
    }
});
document.addEventListener('focusout', (e) => {
    if (e.target.matches('input, textarea, select')) {
        e.target.style.boxShadow = 'none';
    }
});

console.log("Quizora JS Loaded Successfully!");