document.addEventListener('DOMContentLoaded', () => {
  const mapEl = document.getElementById('samsungMap');
  if (!mapEl || typeof L === 'undefined') return;

  // WORLDWIDE CITIES - All continents
  const CITIES = [
    // North America
    { name: 'New York', country: 'USA', lat: 40.7128, lon: -74.006, time: '2:20 PM' },
    { name: 'Los Angeles', country: 'USA', lat: 34.0522, lon: -118.2437, time: '11:20 AM' },
    { name: 'Toronto', country: 'Canada', lat: 43.6532, lon: -79.3832, time: '2:20 PM' },
    // South America
    { name: 'São Paulo', country: 'Brazil', lat: -23.5505, lon: -46.6333, time: '3:20 PM' },
    { name: 'Buenos Aires', country: 'Argentina', lat: -34.6118, lon: -58.396, time: '3:20 PM' },
    // Europe
    { name: 'London', country: 'UK', lat: 51.5074, lon: -0.1278, time: '7:20 PM' },
    { name: 'Berlin', country: 'Germany', lat: 52.52, lon: 13.405, time: '8:20 PM' },
    { name: 'Moscow', country: 'Russia', lat: 55.7558, lon: 37.6173, time: '10:20 PM' },
    { name: 'Paris', country: 'France', lat: 48.8566, lon: 2.3522, time: '8:20 PM' },
    // Middle East & Africa
    { name: 'Dubai', country: 'UAE', lat: 25.2048, lon: 55.2708, time: '11:20 PM' },
    { name: 'Tel Aviv', country: 'Israel', lat: 32.0853, lon: 34.7818, time: '9:20 PM' },
    { name: 'Johannesburg', country: 'South Africa', lat: -26.2041, lon: 28.0473, time: '9:20 PM' },
    { name: 'Cairo', country: 'Egypt', lat: 30.0444, lon: 31.2357, time: '9:20 PM' },
    // Asia Pacific - Original
    { name: 'Mumbai', country: 'India', lat: 19.076, lon: 72.8777, time: '3:50 PM', isHQ: true },
    { name: 'Singapore', country: 'Singapore', lat: 1.3521, lon: 103.8198, time: '6:20 PM' },
    { name: 'Beijing', country: 'China', lat: 39.9042, lon: 116.4074, time: '6:20 PM' },
    { name: 'Seoul', country: 'South Korea', lat: 37.5665, lon: 126.978, time: '7:20 PM', active: true },
    { name: 'Tokyo', country: 'Japan', lat: 35.6762, lon: 139.6503, time: '7:20 PM' },
    { name: 'Sydney', country: 'Australia', lat: -33.8688, lon: 151.2093, time: '5:20 AM' },
    { name: 'Manila', country: 'Philippines', lat: 14.5995, lon: 120.9842, time: '6:20 PM' },
  ];

  // WORLD VIEW - Center at 20,0 with zoom 2
  const map = L.map('samsungMap', { 
    center: [20, 0], 
    zoom: 2, 
    zoomControl:false, 
    attributionControl:false, 
    minZoom:2, 
    maxZoom:7,
    worldCopyJump: true
  });

  // FIX: No API KEY required - Esri Light Gray (free, no key)
  L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 16,
    attribution: ''
  }).addTo(map);

  CITIES.forEach(c=>{
    const html = `<div class="city-label"><span class="name">${c.name}</span><span class="time">${c.time}</span><div class="city-dot ${c.active?'active':''} ${c.isHQ?'hq':''}" style="margin:5px auto 0;"></div></div>`;
    L.marker([c.lat,c.lon], { icon: L.divIcon({ html, className:'custom-city-icon', iconSize:[90,50], iconAnchor:[45,45] }) }).addTo(map);
  });

  let attacks=[];
  const TYPES = ['DDoS Amplification','SQL Injection','Brute Force','Malware C2','Phishing Kit','XSS Exploit','Ransomware','Botnet'];

  function createCurve(src,dst){
    const latlngs=[]; 
    for(let i=0;i<=60;i++){ 
      const t=i/60; 
      const lat=(1-t)*src.lat+t*dst.lat; 
      const lon=(1-t)*src.lon+t*dst.lon; 
      const arch=Math.sin(Math.PI*t)*15; 
      latlngs.push([lat+arch*0.2, lon]); 
    } 
    return latlngs;
  }

  function spawn(){
    const src=CITIES[Math.floor(Math.random()*CITIES.length)];
    let dst=CITIES[Math.floor(Math.random()*CITIES.length)]; 
    while(dst===src) dst=CITIES[Math.floor(Math.random()*CITIES.length)];
    
    const type=TYPES[Math.floor(Math.random()*TYPES.length)];
    const sev=Math.random()>0.65?'CRITICAL':Math.random()>0.35?'HIGH':'MEDIUM';
    const ip=`${50+Math.floor(Math.random()*200)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}`;
    const isBlue=Math.random()>0.5;
    const color=sev==='CRITICAL'?'#ef4444':isBlue?'#0e73d8':'#eab308';

    const line = L.polyline(createCurve(src,dst), { color, weight:sev==='CRITICAL'?3:2, opacity:0.8, dashArray:'8,10' }).addTo(map);
    let off=0; 
    const iv=setInterval(()=>{ 
      try{ off=(off+2)%20; line.setStyle({dashOffset:off}); }catch(e){ clearInterval(iv); }
    },60);

    const dotIcon = L.divIcon({ 
      html:`<div style="width:11px;height:11px;background:${color};border:2px solid #fff;border-radius:50%;box-shadow:0 0 0 4px ${color}33,0 0 12px ${color}"></div>`, 
      className:'', iconSize:[11,11] 
    });
    const dot = L.marker([src.lat,src.lon],{icon:dotIcon}).addTo(map);
    let p=0; 
    const dots=setInterval(()=>{ 
      try{
        p+=0.012; if(p>1)p=0; 
        const pts=line.getLatLngs();
        const idx=Math.floor(p*(pts.length-1));
        dot.setLatLng(pts[idx]); 
      }catch(e){ clearInterval(dots); }
    },35);

    attacks.push({src,dst,type,sev,ip,color}); if(attacks.length>20) attacks.shift();
    updateUI({src,dst,type,sev,ip}); 
    addFeed({src,dst,type,sev,ip,color});
    
    setTimeout(()=>{ 
      try{ map.removeLayer(line); map.removeLayer(dot); }catch(e){}
      clearInterval(iv); clearInterval(dots); 
    },6500);
  }

  function updateUI(a){
    const $=id=>document.getElementById(id);
    if($('detailSrc')) $('detailSrc').textContent=`${a.src.name}, ${a.src.country}`;
    if($('detailDst')) $('detailDst').textContent=`${a.dst.name}, ${a.dst.country}`;
    if($('detailType')) $('detailType').textContent=a.type;
    if($('detailIp')) $('detailIp').textContent=a.ip;
    if($('detailSev')){ $('detailSev').textContent=a.sev; $('detailSev').style.background=a.sev==='CRITICAL'?'#ef4444':a.sev==='HIGH'?'#f59e0b':'#0e73d8'; }
    const popup=document.getElementById('attackPopup');
    if(popup){ 
      document.getElementById('popupSrc').textContent=`${a.src.name}`; 
      document.getElementById('popupDst').textContent=`${a.dst.name}`; 
      document.getElementById('popupSeverity').textContent=a.sev; 
      document.getElementById('popupType').textContent=a.type; 
      document.getElementById('popupIp').textContent=a.ip; 
      popup.classList.add('show'); 
      setTimeout(()=>popup.classList.remove('show'),3500); 
    }
  }
  
  function addFeed(a){
    const left=document.getElementById('attackFeedLeft'); 
    const right=document.getElementById('attackFeedRight');
    if(!left||!right) return;
    const html=`<div class="attack-feed-item"><div style="width:30px;height:30px;border-radius:9px;background:${a.color}18;color:${a.color};display:grid;place-items:center;flex-shrink:0;flex-grow:0;"><i class="ri-shield-flash-line"></i></div><div style="flex:1;min-width:0;overflow:visible;"><div style="font-weight:700;line-height:1.3;">${a.src.country} → ${a.dst.country}</div><div style="color:#64748b;font-size:11px;line-height:1.4;margin-top:2px;">${a.src.name} → ${a.dst.name} • ${a.type}</div><div style="color:${a.color};font-weight:800;font-size:10px;margin-top:4px;letter-spacing:0.02em;">${a.sev} • ${a.ip} • now</div></div></div>`;
    const target=Math.random()>0.5?left:right; 
    target.insertAdjacentHTML('afterbegin', html); 
    if(target.children.length>7) target.removeChild(target.lastChild);
  }

  // Clock
  setInterval(()=>{ 
    const el=document.getElementById('liveClock'); 
    if(!el) return; 
    const ist=new Date(new Date().toLocaleString('en-US',{timeZone:'Asia/Kolkata'})); 
    el.textContent=ist.toLocaleTimeString('en-IN',{hour12:true})+' IST'; 
  },1000);
  
  document.getElementById('mapSearchBtn')?.addEventListener('click',()=>map.zoomIn());
  document.getElementById('mapLocateBtn')?.addEventListener('click',()=>map.setView([20,0],2));
  
  // Spawn faster for worldwide effect
  spawn(); 
  setInterval(spawn, 1400);
});